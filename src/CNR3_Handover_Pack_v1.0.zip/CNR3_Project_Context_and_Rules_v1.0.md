# CNR3 Project Context and Rules

**Document:** A of CNR3 handover pack  
**Version:** v1.0  
**Date:** 2026-06-03  
**Status:** Stable context document; update rarely.  
**Companion design authority:** CMS06, or any later cache design spec that explicitly supersedes CMS06.

---

## A1. Purpose of this document

This document gives a new AI chat or human maintainer the project context needed to safely continue CNR3 development.

A new chat must assume it remembers nothing from earlier chats. This document explains:

- what CNR3 is;
- why the project exists;
- what VapourSynth scheduling behaviour makes CNR3 difficult;
- why the CMS cache manager is correctness-critical rather than a performance convenience;
- what safety rules must not be violated;
- what coding and patch-instruction rules must be followed.

This document is part of a three-document handover pack:

1. `CNR3_Project_Context_and_Rules_v1.0.md`
2. `CNR3_Decision_Log_v1.0.md`
3. `CNR3_Current_Session_Handover_v1.0.md`

Companion documents should be uploaded with this pack when relevant:

- the latest CMS06 or later cache design specification;
- current relevant `.h` and `.cpp` files;
- latest build/test logs where the next task depends on them.

The handover pack is designed to let a new chat safely resume development without re-opening settled decisions or making unsafe suggestions about recursion, cache ownership, mutex locking, `VSFrame` reference counts, pruning, or VapourSynth frame scheduling.

---

## A2. Project identity

CNR3 is a VapourSynth API4-only chroma stabiliser inspired by the CNR2/vscnr2 temporal chroma-stabilisation algorithm.

The project aims to:

- redevelop the old CNR2/vscnr2-style behaviour in modern C++;
- target VapourSynth API4 only;
- avoid API3-era types, assumptions, and scheduling shortcuts;
- preserve recursive chroma-stabilisation correctness before pursuing parallel performance;
- support integer YUV formats only;
- operate safely under modern VapourSynth frame-request patterns;
- provide strong diagnostics for cache, threading, memory, and reference-count behaviour.

CNR3 is intended especially for analogue/video-capture material where chroma shimmer, dot crawl-like instability, or temporal chroma noise can be reduced by reusing controlled amounts of previous filtered chroma.

---

## A3. Algorithmic core

CNR3 is a recursive temporal chroma filter.

The load-bearing fact is:

```text
output[N] depends on source[N] and output[N - 1]
```

It does not merely depend on `source[N - 1]`. It depends on the already-filtered previous output frame.

This matters because a correct frame `N` cannot normally be produced unless the correct filtered output for frame `N - 1` is available.

At a high level:

```text
For Y:
    copy source luma unchanged.

For U/V:
    compare current source chroma against previous filtered chroma.
    compare current downsampled luma against previous downsampled luma.
    use signed-difference response tables for Y and chroma.
    blend current source chroma with previous filtered chroma according to the combined response.
```

A simplified conceptual form is:

```text
weight = response_y(diff_y) * response_chroma(diff_chroma)

output_chroma[N] =
    weighted blend of:
        previous filtered output_chroma[N - 1]
        current source_chroma[N]
```

Scene-change detection matters because carrying previous filtered chroma across a true scene cut can smear or contaminate the new scene. When scene-change detection fires, the current design copies current source chroma and skips recursive chroma blending for that frame.

---

## A4. Why VapourSynth scheduling is central

VapourSynth does not necessarily request frames in display order.

A recursive algorithm naturally wants:

```text
0, 1, 2, 3, 4, ...
```

But a VapourSynth scheduler may request:

```text
0, 3, 1, 2, 4, ...
```

or may have multiple frame requests in flight depending on the filter mode and graph.

A simple "remember only the previous frame" implementation is therefore unsafe unless the scheduler is forced to request frames strictly in order. That is not acceptable as the final design for an API4 plugin.

---

## A5. VapourSynth filter modes relevant to CNR3

### A5.1 `fmUnordered`

Current CNR3 uses `fmUnordered`.

In `fmUnordered`:

- only one `getFrame` call enters a given filter instance at a time;
- this protects per-instance state from concurrent `getFrame` entry;
- it does not guarantee in-order frame numbers.

Example:

```text
Requested order:
    0, 1, 2, 3

Strict recursive processing works.

Requested order:
    0, 3, 1, 2

A naive recursive filter fails at frame 3 because output[2] does not yet exist.
```

This is why current strict-streaming behaviour is only a temporary correctness bridge.

### A5.2 `fmParallelRequests`

In `fmParallelRequests`:

- multiple frame requests may be in flight;
- request and readiness order may interleave;
- frame `N + 1` may need output `N` while output `N` is still being computed;
- cache metadata, pins, active zones, ownership, and reference counts become more important.

Example:

```text
Request 100 begins.
Request 101 begins.
Request 100 has not completed.
Request 101 needs output[100].

The cache manager must not allow output[100] to be pruned, lost,
observed through a dangling pointer, or double-owned.
```

CMS06 must be followed before attempting future `fmParallelRequests` support.

### A5.3 `fmParallel`

Full `fmParallel` is explicitly out of scope for the current iteration. It would require stronger reasoning about fully concurrent readers and writers, active computation state, dependency waits, and recovery ownership. Do not assume that mutex-protected cache metadata alone makes full `fmParallel` safe.

---

## A6. Why the cache manager exists

The cache manager is not an optional optimisation. It is a correctness mechanism.

It exists because:

- CNR3 is recursive;
- output frame `N` depends on output frame `N - 1`;
- VapourSynth may request frames out of order;
- the current strict-streaming bridge rejects out-of-order requests;
- a production-quality recursive API4 filter needs safe cache hit reuse, checkpoint recovery, bounded warm-up recovery, hot-zone pruning, and eventually safe parallel-request behaviour.

Unsafe cache changes can cause:

- incorrect recursive output;
- use-after-free;
- dangling cached frame pointers;
- leaked `VSFrame` references;
- double frees;
- silent chroma corruption;
- deadlocks;
- failures that only appear under different request schedules.

---

## A7. Current high-level architecture

Current naming direction:

```text
vapoursynth-Cnr3.cpp:
    Main VapourSynth lifecycle, parameters, getFrame path, diagnostics, pixel processing.

cnr3_common.h:
    Shared data structures, including Cnr3Data and old/new cache members.

cnr3_response_tables.h/.cpp:
    Response table building and table diagnostics.

cnr3_output_cache_manager.h/.cpp:
    CMS06 output-cache manager.

old_cnr3_strict_cache_*:
    Old strict-streaming cache functions retained while output_cache is not yet output-authoritative.
```

Current source of returned output:

```text
old_strict_cache remains output-authoritative.
output_cache stores/prunes real produced frames for proving only.
```

---

## A8. Safety-critical rules

The following rules are load-bearing:

```text
- All mutable output-cache state must be protected by cache.cache_mutex.
- Public output-cache helpers lock internally unless documented otherwise.
- Helpers ending in _externally_locked must only be called while the caller already holds cache.cache_mutex.
- cache_index is non-owning.
- non_checkpoint_pool and checkpoint_pool own retained VSFrame references.
- Every cache-owned addFrameRef must be balanced by exactly one freeFrame.
- Lookup helpers returning a frame outside the mutex must return a caller-owned addFrameRef.
- The caller must free caller-owned lookup references on every exit path.
- Duplicate store is first-in-best-dressed: the first stored frame is the source of truth.
- Duplicate store must not take another addFrameRef.
- All pruning/removal must preserve ordered frame-number semantics.
- No dangling frames or dangling slots are acceptable.
```

---

## A9. Diagnostic philosophy

CNR3 must be exceptionally well instrumented.

Diagnostics must prove:

- store attempts/successes/failures;
- prune attempts/successes/failures;
- checkpoint pin/unpin behaviour;
- cache-owned add/free reference balance;
- validation success/failure;
- integrity errors;
- hot-zone behaviour;
- hard-ceiling aborts;
- teardown clear behaviour;
- memory snapshots where relevant.

Diagnostic output must never go to stdout. Debug/status output goes to stderr. VapourSynth user-facing errors use `mapSetError()` or `setFilterError()`.

Current diagnostic policy after the latest work:

```text
Compact output-cache trace:
    every processed frame.

Full output-cache summary:
    after create;
    frame 0;
    frame 1;
    every 100th frame;
    one frame before final;
    final frame;
    before free;
    after output_cache clear;
    any store/prune failure.
```

Future option, not yet implemented:

```text
Add compact/full diagnostic modes later if long logs become impractical.
```

---

## A10. Coding Rule 1 — Code comments

Comments should be concise, relevant, and informative for future maintainers.

Avoid undue blank lines, repeated wording, excessive prose, and design-history prose inside code.

Do not over-compress safety-critical comments. Any comment that, if misread or removed, could lead a future maintainer to make an unsafe edit, must retain enough detail to preserve its exact meaning. This applies especially to:

- locking and threading invariants;
- ownership and lifetime rules;
- reference-count discipline;
- non-obvious preconditions and postconditions;
- invariants whose violation would cause silent bugs rather than immediate crashes.

Compress freely where code is self-explanatory. Preserve detail wherever a future edit guided by an incomplete comment could introduce a hard-to-find bug.

---

## A11. Coding Rule 2 — Code update instructions

When producing code changes for a human to apply:

- Each phase or set of changes, and each individual change within them, must be uniquely identifiable.
- State the file and function/location explicitly before each block.
- Use before/after blocks showing exact existing code and exact replacement.
- Include enough surrounding context to make the before block uniquely findable.
- The before block must match exactly one location in the named file.
- If a snippet would match multiple locations, extend the context until unique.
- The after block must be the exact intended replacement.
- Avoid abstract "insert near" instructions unless backed by actual file context.
- When adding a new function, show the insertion point using the end of the preceding function and the start of the following function.

---

## A12. New-chat boot sequence

At the start of a new chat, upload/read in this order:

1. `CNR3_Project_Context_and_Rules_v1.0.md`
2. `CNR3_Decision_Log_v1.0.md`
3. `CNR3_Current_Session_Handover_v1.0.md`
4. latest CMS06 or later cache design spec
5. current relevant source files
6. latest logs if the next task depends on test evidence

Instruction to the new chat:

```text
Treat the Current Session Handover as the source of truth for current status.
Treat the Decision Log as the source of truth for settled decisions.
Treat CMS06 or later as the detailed cache-manager design authority.
If the design spec and current code appear to conflict, stop and ask for clarification.
Do not re-litigate settled decisions unless current code or logs prove a real problem.
```
