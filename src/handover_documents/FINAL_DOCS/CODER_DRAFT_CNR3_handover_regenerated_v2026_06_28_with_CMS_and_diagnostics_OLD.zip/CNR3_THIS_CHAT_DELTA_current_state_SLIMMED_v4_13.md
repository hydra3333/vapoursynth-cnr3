# CNR3 — THIS-CHAT DELTA: current-state companion (SLIMMED, through P.11C.5)

**Version:** v4.13 (SLIMMED). Supersedes v4.12/v4.12.4 (P.11C-closed handover checkpoint). This is the live
per-phase ledger: a one-line committed-phase INDEX, the one don't-re-derive technical finding kept in
full, the ACTIVE/NEXT phase in full, and the open owed-items. Full per-phase detail (golden chains,
proof records, prior-phase briefs) lives in the `dev_cache_manager` branch git history (prior DELTA
versions v4.0-v4.12 + the test-artifact harnesses/derivation scripts) and Document A's build-state note;
it is committed to main at project end. Nothing durable is lost — it is migrated, not truncated.
**Date:** 2026-06-28

---

## 1. CURRENT BASELINE (confirm from repo)

```text
Committed/pushed through:  CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof (P.11C ARC CLOSED; .1-.5 all PROVEN)
Selftest count:            53/53 PASS  (forced-fail 52/53 exit 1; verbose 53/53)
Controlling CMS:           CMS07.13  (cnr3_cache_manager_design_v7_13.md)
Production Spec:           v2.13
Document A:                v3.7   (project context + standing rules; generated from Spec v2.13)
Document B:                v3.7   (current-state work plan; top UPDATE block is authoritative)
Branch:                    dev_cache_manager
```
The repository is the authority — confirm CNR3_EDIT_VERSION and the selftest count from committed source.

## 2. COMMITTED-PHASE INDEX (one line per phase; full detail in dev-branch git history)

The live getFrame dispatch is FEATURE-COMPLETE across all four branches; the branch-(d) recovery arc is
COMPLETE. Per-phase golden chains and proof records are in the dev-branch git history (prior DELTA
versions + test-artifacts) and reproducible from the `D*_golden_chain_derivation.py` scripts.

```text
K.1A-K.1D    request-plan structures + KDT trace -> first REAL output frame (copyFrame fresh-start)   [git]
K.1E.2/.3    live predecessor-present compute; CLOSES R-ARCH-06 (recursive filtered-pred, 163/93)      [git]
K.1F         live direct cached-output return (branch-b cache-hit; Option-C lifecycle trigger)         [git; §3 below]
K.1G         plugin source split (no behaviour change)                                                 [git]
Recovery-Step-0  AS4 single-lock batch discharge (discharge_all takes cache_mutex once; 48->49)        [git; CMS §8.7]
D.1          exact-anchor SINGLE-hole recovery (plugin-only) — DONE                                    [git; Doc A]
D.2          exact-anchor MULTI-hole (k>=2) + bounded-window refusal (plugin-only) — DONE              [git; Doc A]
             (RUN C bounded-window refusal is TRANSITIONAL — superseded by D.3 floor-fresh-start)
D.3          floor-fresh-start recovery (plugin-only) — DONE                                           [git; Doc A]
             (materialized-floor-is-the-foundation invariant recorded in CMS §9.5 / CMS07.13)
D.4          pre-compute adopt-skip + first-in-best-dressed PRIMITIVES (selftest; 49->51) — DONE       [git; Doc A]
D.5          recovery-pin-survives-real-prune-pass (selftest, paired control; 51->52) — DONE           [git; Doc A]
             >>> branch-(d) RECOVERY ARC COMPLETE (D.1-D.5). Only deferred confidence: real concurrent
             >>> (fmParallel) scheduling, bounded to the fmParallel validation phase.
P.11C.2      live scene-change config + scdthr->threshold helper + central store-request/checkpoint   [git]
             skeleton + not-applicable KDT (frame-0/floor). Detection NOT enabled (branch-c/d deferred
             to P.11C.3/.4/.5). Threshold uses verified vsCnr2 full-frame shape + P.2A-style proportional
             round-to-nearest depth scaling (NOT vsCnr2 <<(depth-8)). 52/52 unchanged. COMMITTED.
P.11C.3      branch-c (predecessor-present) scene detection ENABLED: live _with_scene_change call +    [git]
             force_checkpoint=scene_change_detected. Proven via external .vpy (live default scdthr=10.0,
             threshold=1402): C-control diff_total=64/samples=16/detected=0/blend (byte 109 between
             100..160); C-cut diff_total=2040/samples=2/detected=1/reset (byte ==current 160/80)/
             store_as_checkpoint=1. Four-way 52/52. frame-0 not_applicable boundary confirmed. COMMITTED.
P.11C.4      branch-d (RECOVERY) scene detection ENABLED: per-hole + target _with_scene_change +         [git]
             grid-OR-detected checkpoint store; floor store + floor anchor-record LEFT grid-only
             (classified-site patch, not pattern-replace). Holes report ACTUAL resulting_slot_is_checkpoint;
             target reports _expected (status-only wrapper); adopted-skip reports not_run. Atomicity
             inherited (one-lock store+flag+pin, D.5 composition). Four-way 52/52. Proven via recovery
             .vpy adapted from D3 floor-fresh-start trigger (threshold=5606, 16x16): D-control all
             detected=0 (256/64); D-cut-at-hole hole2 detected=1/6160/10/reset/checkpoint=1(actual),
             target no-cut blend byte 255/151/83 (degeneracy fix proven); D-cut-at-target target
             detected=1/6120/10/reset/checkpoint_expected=1, reset byte 255/160/80. Both Debug+Release.
             COMMITTED.
P.11C.5      scene-cut checkpoint FOUND AS RECOVERY ANCHOR (arc finale). KDT-only: print            [git]
             anchor_is_checkpoint=%d in the live exact-anchor recovery trace (from already-populated
             recovery_plan.anchor_is_checkpoint); trace-only, no behavioural change. New cache-core
             composition selftest (52->53) proves the CACHE HALF: an UNPINNED NON-GRID frame stored as
             the sole checkpoint (frame 165) survives a real bounded prune by CHECKPOINT CLASS while an
             ordinary non-checkpoint (frame 1) is evicted (total_pin_count=0 throughout -> survival by
             class, NOT pin), then read-only bounded recovery for frame 167 anchors exactly on 165 with
             anchor_is_checkpoint=true and holes={166} (166 absent by construction). Composes with
             P.11C.4 (live scene detection feeds the checkpoint store route). Four-way 53/53 / 53/53 /
             52/53 forced-fail / 53/53, both Debug+Release. COMMITTED. >>> P.11C SCENE-CHANGE ARC CLOSED (.1 layout, .2 skeleton, .3 branch-c, .4 branch-d, .5 scene-cut
checkpoint recovery-anchor). Scene detection is now wired uniformly across branch-a/c/d, proven on
synthetic harnesses both Debug+Release, committed through CMS07-P.11C.5. The live getFrame dispatch is
feature-complete across all four branches WITH scene-change handling.

NEXT PHASE = STEP 0 CMS HOT-ZONE/PRUNE SENSIBILITY REVIEW. Do not jump straight to implementation.
The cache-core hot-zone and prune componentry is built and proven, but the live getFrame path has no
live cache-pressure callers yet. Step 0 reviews the CMS itself for sensibility and gaps before any wiring
patch: what hot zones should mean live, exactly where observation occurs, exactly when prune runs after
stores, how that composes with the active pin_list and arInitial->arAllFramesReady gap, and which
diagnostics are required before first real clips can be interpreted.

Provisional sequence after Step 0, subject to review outcome:
```text
CMS Step 0 review -> hot-zone observation/retirement wiring -> live prune-trigger wiring ->
diagnostics/telemetry placement + first real-footage validation in approved order -> fmParallel.
```

--- historical detail of the now-closed P.11C arc follows ---

P.11C was required before any real footage because scene cuts must reset the recursive chroma blend and
promote the cut frame to a checkpoint. It is now complete. P.11C.3 proved branch-c scene detection/reset/
checkpoint routing; P.11C.4 proved branch-d recovery per-hole and target scene detection/reset/checkpoint
routing; P.11C.5 proved the cache-half effect that an unpinned non-grid checkpoint survives prune by
checkpoint class and later serves as a recovery anchor. Real-footage validation remains pending, but it
should not precede the Step 0 CMS review of live cache-pressure wiring.

## 5. OWED-ITEMS LEDGER (P.11C closed; Step 0 hot-zone/prune review owns next functionality)

- **CANDIDATE (not actioned) — production helper for adopt-or-compute outcome plumbing.** Surfaced
  during D.4 scoping: the floor and hole live paths duplicate the adopt-or-compute DECISION choreography
  inline, though the ownership-critical PRIMITIVES are already shared (lookup_frame_and_record_pin;
  AS2 store summary duplicate_existing_slot). A helper consolidating the decision is a POSSIBLE future
  cleanup — to be decided ON ITS OWN MERITS (R-PROCESS-21: proven-code change needs proposal + approval
  + selftest), justified by single-source-of-truth / fmParallel-readiness, NOT by testability, and only
  if the floor/hole logic drifts or fmParallel review shows a need. The floor/hole compute/store bodies
  differ enough (fresh-start vs predecessor-blend; generic store vs planned-hole wrapper; scalar vs
  indexed outcome) that a premature helper risks a parameter-heavy abstraction obscuring the D.3 safety
  story. NOT actioned now; recorded so it is neither lost nor rushed.

- **CANDIDATE (not actioned) — Document B deep tidy (option 2), timed BEFORE the fmParallel arc.** Document
  B v3.5.1 currently uses the layered convention: the v3.5.1 UPDATE block at the top is the authoritative
  current state (D.5 / recovery complete / P.11C next), and the older body (restart-era §5 next-phase=H.2A,
  the .txt-rename transition state, the §11 CMS07.2/28-selftest snapshot, the pixel-arc §8 work plan) is
  retained under explicit SUPERSEDED banners as history of record. This is correct and complete for
  handover (option 1, chosen). The deeper tidy (option 2) — promote the durable scaffolding (working
  method, invariant disciplines, do-not-implement) into clean current sections and move the genuinely-dead
  restart-era instances into a single consolidated "Historical / superseded restart-era record" appendix,
  so live state and archive are cleanly separated rather than banner-interleaved — is DEFERRED to the
  P.11C -> fmParallel seam. Rationale: the fmParallel arc is a major new concern (the deferred concurrent-
  scheduling confidence from D.4/D.5) and deserves a clean current-state Document B to start from; the
  recovery+pixel era closes at P.11C/first-real-footage, which is the natural boundary for the restructure.
  Do it as its own focused pass (like this handover refresh), NOT mid-handover and NOT during fmParallel.

- **FULL DOC-SET REFRESH — timed at the P.11C-closed / FIRST-REAL-FOOTAGE-PROVEN seam (coordinator: "must
  happen soon").** When P.11C.5 commits and first real-footage validation passes, do ONE focused
  documentation pass that: (a) refreshes the whole handover set (CMS, Production Spec, Documents A/B,
  DELTA, Reviewer/Role/Coder-Restart intros, Future Investigations) to the "P.11C arc CLOSED + real footage
  PROVEN" state; (b) folds in the FORWARD PLAN for the diagnostics arc -- the condensed 4-phase plan in
  CNR3_Diagnostics_Arc_Condensed_Plan_v1_2.txt (DIAG.1 framework+D-SUM-01+observe-only proof; DIAG.2
  cache-core family batch; DIAG.3 getFrame/recovery/return batch; DIAG.4 memory + close) so the next arc
  has a recorded entry point; (c) executes the Document B deep tidy (option 2, above) as part of the same
  pass since it shares this exact seam. This is the natural boundary: recovery+pixel+scene era closes, the
  diagnostics + fmParallel eras begin from a clean current-state doc set. Do it as its own focused pass,
  NOT mid-arc. NOTE: diagnostics could optionally run PARTLY before real footage (D-SUM-01/03/14 aid
  first-footage debug; observe-only so it blocks nothing) -- placement is a coordinator decision at the seam.

- **LIVE CACHE-PRESSURE WIRING — the last missing FUNCTIONALITY (verified against the P.11C.5 src.zip,
  this session).** AUDIT FINDING (ground truth, not reconstruction): in the committed P.11C.5 live getFrame
  path (arInitial.cpp + arAllFramesReady.cpp), the cache-pressure capabilities have ZERO live callers:
  execute_bounded_prune_pass=0, record_hot_zone_observation=0, retire_decay_eligible_hot_zones=0,
  merge_closest_active_hot_zones=0, remove_unpinned_noncheckpoint_frames_bounded=0,
  calculate_cache_prune_trigger_decision=0. store_owned_frame_locked APPENDS without consulting the prune
  trigger (grows unbounded; only returns capacity_exceeded at the vector hard max). So the live cache
  currently NEVER prunes and NEVER records hot-zone observations. The LOGIC is fully built + proven
  (selftests: prune hysteresis/victim/composite, D.5, P.11C.5; hot-zone lifecycle tests) -- but the WIRING
  into the live path is the last functional gap. Everything else audited is wired or test/diag-only by
  design (lookup/store/recovery/pin-discharge all WIRED; total_pin_count/hot_zone_count/slot_count are
  diagnostic observers; non-pinning plan_bounded_recovery_search is the selftest variant). NOTHING ELSE
  functional appears missing. Coordinator/designer/coder decision (this session): first perform a CMS sensibility/gap review for hot-zone/prune live wiring; only then wire hot zones/pruning if confirmed. The prune componentry is proven, but the CMS plan itself must be reviewed before coding.

- **CMS SENSIBILITY FOR THE WIRING — policy must be jointly reviewed before coding; live-trigger contract is one load-bearing part (this session).** Assessment before coding: do not assume the CMS is reliable as-is merely because the componentry exists. Review these CMS areas first: hot-zone OBSERVATION wiring point is specified -- CMS §5.7 "Hot-zone update at arInitial,
  not arAllFramesReady"; hot-zone lifecycle §5.3-5.6 (slide/spawn/merge, decay sequence, exact-cheap
  retirement test); prune RETENTION policy §6.3 (candidate iff frame!=0 AND pin_count==0 AND outside every
  hot zone; evict greatest-hot-zone-distance first; soft MIN/MAX_RETAIN; frame 0 never pruned) -- which is
  exactly what execute_bounded_prune_pass already implements; prune SAFETY (§5.5 decay-makes-prune-safe;
  store-and-pin one atomic so a gap cannot let prune evict the just-stored frame). NOT YET PINNED DOWN AT
  WIRING LEVEL: the live PRUNE-TRIGGER TIMING -- exactly WHEN the live store path invokes
  execute_bounded_prune_pass (after each over-ceiling store? batched? at request classification?) and how
  that composes safely with the active pin_list and the arInitial->arAllFramesReady gap. The CMS describes
  prune firing "by capacity pressure / count-based soft trigger" but does not nail the live call-site at
  implementation level. Much of the policy is written FOR fmParallel ("once multiple requests are in flight",
  "under fmParallel scatter") -- so the SINGLE-ACTIVATION regime now is SIMPLER than the eventual concurrent
  case. RECOMMENDED FIRST STEP (when resumed): a focused designer+coder review (CMS-clarification + approach
  analysis, like the P.11C.5 read-first) on the live prune-trigger contract -- confirm trigger point, confirm
  single-activation safety, and EXPLICITLY scope it as "single-activation wiring now; concurrent prune
  revisited in the fmParallel arc." Hot-zone observation wiring needs less review (§5.7 already specifies it).
  Sequence now banked: Step 0 CMS sensibility review -> hot-zone observation wiring -> prune wiring -> diagnostics/telemetry placement + real-clip validation in the approved order -> fmParallel. "Proven componentry" != "proven wiring": the
  prune PASS is proven; the live TRIGGER and its lifecycle safety are the actual wiring work (same
  component-vs-wiring distinction as the K-phases).

- **TEST ARTIFACTS / GOLDEN PROVENANCE (housekeeping; add to repo alongside the existing harnesses).**
  The recovery harnesses and their golden-derivation scripts should live in the repo test area as
  regression bases for later phases (D.3+ must keep D.1 and D.2 green):
    * test_D1_once_only_harness_AB.vpy/.bat (D.1 single-hole), test_D2_once_only_harness_AB.vpy/.bat
      (D.2 multi-hole + bounded-window refusal), and test_D3_once_only_harness_AB.vpy/.bat (D.3
      floor-fresh-start RUN A + floor-byte/hole cache-hit RUN B + D.2 exact-anchor regression RUN C +
      D.1 regression RUN D + negative control RUN E + passthrough RUN G). All reuse
      test_K1F_check_y4m_constant_plane.py.
    * D.4 and D.5 have NO separate harness or golden script: their proofs are cache-core selftest cases
      shipping in the selftest target itself. D.4 = two cases (present-frame adopt-skip primitive +
      first-in-best-dressed duplicate; 49->51). D.5 = one case (recovery-pin-survives-bounded-prune,
      paired control/protected; 51->52). Status/ownership/identity proofs, not pixels.
    * D1_golden_chain_derivation.py, D2_golden_chain_derivation.py, and D3_golden_chain_derivation.py
      are the GOLDENS PROVENANCE:
      small Python that INDEPENDENTLY re-derives the expected pixel values (D.1 147/109; D.2 anchor
      72/184 -> holes 148/96, 149/95 -> target 148/100) from the response-table + P.11B blend maths,
      (D.3 floor 56/176 -> holes 144/111, 145/109 -> target 144/113), and self-check by reproducing the
      known K.1E.3 161/95 & 163/93. They are the "answer key with its working shown" that proves the
      harness goldens are independently correct, not circular.
      Keep them with the harnesses; extend the same way for D.3-D.5 chains. NOT in the coder pack /
      not controlling design; they are test provenance.

- **D.2 BOUNDED-WINDOW REFUSAL — code reports only what the bounded search observed (decided, scope v2).**
  D.2's recovery refusal emits a SINGLE honest reason: **no-in-window-anchor** (anchor_found==false for
  the bounded interval [max(0,N-B), N-1], B=50). The code does NOT distinguish "an older anchor exists
  beyond the window" from "no prior output exists at all" — both are identical to a bounded search, and
  telling them apart would require an UNBOUNDED out-of-window search, defeating the purpose of bounding.
  The HARNESS proves the bounded-window-exceeded case BY CONSTRUCTION (Run C: establish output[0], then
  request output[52]; nearest anchor is 52 back > B=50). No cache-core helper or out-of-window search is
  added merely to enrich a reason string. (If an EXISTING primitive distinguishes the two for free, the
  richer label may be emitted, but nothing is to be added for it.) Rationale: diagnostic honesty (a label
  means only what the code knows) + avoid an unbounded scan in a refusal path. Decided designer+coder
  2026-06-27 (D.2 scope v2, coder review correction 2).

- **CMS-GAP RESOLVED (into CMS07.12) — bounded-search reporting semantics now explicit in the CMS.**
  STATUS: DONE. The clarification was added to CMS §9.5 Phase 1 (the search reports only within
  [max(0,N-B), N-1]; no-in-window-anchor does not distinguish out-of-window-anchor from no-prior-output;
  refusal reports no-in-window-anchor only) and the interval upper bound corrected to N-1. No behaviour
  change (D.2 already ships it). Relevant to D.3 (same no-in-window-anchor boundary). Original candidate:** The D.2 refusal decision above rests on a principle that recurs in D.3 (floor-
  fresh-start) and D.5 (prune pressure): *the bounded recovery search reports presence/absence only
  within [max(0,N-B), N-1]; absence within the window is not distinguished from absence of any prior
  output, and no out-of-window search is performed.* This is arguably ENTAILED by "bounded search" and
  may need no CMS text — OR a one-line clarification in CMS §9.1/§9.5 would make the boundary's semantics
  explicit for every recovery phase and would have prevented the D.2 scope's initial over-specification.
  RAISED as a CMS-GAP candidate (charter case b, low bar) for coordinator decision: add the clarifying
  line at the next CMS edit (e.g. bundled with the Doc A regeneration session), defer, or judge it
  already-implied and skip. NOT blocking D.2 (scope v2 stands regardless). Recorded so the principle is
  not silently re-introduced as an overreach in a later phase.

- **DOC-SET REGENERATION — Document A and Document B (deferred to a near-future dedicated session).**
  The current-era handover docs are refreshed (Production Spec v2.10, Role Handover v1.9, Reviewer
  Introduction v3.2, Coder Restart Introduction v6.0, this DELTA) and all carry the new Design
  Alignment and Escalation Charter (full text in Production Spec §3A.5.0 and Role Handover Part 3 §D0).
  STILL OWED:
    * **Document A** is at **v3.4 on the stale K.1D / CMS07.8 / 47-47 baseline** (it self-describes as
      "only a version number bump"; the Production Spec long noted "until Document A is regenerated").
      Needs a full STATE regeneration to **v3.5**: CMS07.8 -> CMS07.10, committed-through K.1D -> D.1,
      47/47 -> 49/49, K.1E-branch-(c)-in-flight -> all-four-branches-live, AND it must faithfully
      reproduce the Production Spec §3A register INCLUDING the charter at §3A.5.0 (per R-PACK-02:
      Document A reproduces §3A; on mismatch §3A wins).
    * **Document B** — confirm the committed current version (a v3.5 with the K.1F update block was
      produced; verify it is the repo's latest and bump to carry the D.1 + K.1G state + charter
      pointer if not already present). Target **v3.5** (or higher).
  ACTION TRIGGER: the **Coder Restart Introduction v6.0 already forward-references Document A v3.5 and
  Document B v3.5** as expected current versions (with a built-in warning that an older Doc A is stale).
  Do this in a near-future dedicated session — it is a large rewrite, deliberately NOT rushed at the
  tail of a long chat (the lesson from prior sudden chat deaths). NOT blocking D.2.

- **SCENE-CHANGE / P.11C deferral (shared across ALL live branches — record kept here so it is
  actioned, not lost).** The live getFrame keystones (branch-c K.1E.3, and branch-d D.1 onward)
  compute via P.11B and DEFER the P.11C scene-change/reset check, emitting
  `p11c_called=0 scene_change_deferred=1`. CMS §9.2 / §6.4 specify the COMPLETE recovery+compute as
  scene-change-aware: a cut detected during compute makes that output a fresh-start (copy source
  chroma, skip the recursive blend) and stores it WITH the checkpoint flag set (a cut frame is the
  ideal recovery anchor, §9.5/§12B). Deferring P.11C is correctness-safe ONLY while inputs contain no
  cuts (true for the synthetic constant-plane harnesses); on real footage a missed cut would blend
  across a scene boundary (wrong output) AND fail to establish the cut-checkpoint that recovery relies
  on. ACTION TRIGGER (action reasonably as soon as safe): wire P.11C UNIFORMLY across branch-a/c/d as
  its own keystone — NOT folded into any single branch — at the FIRST of: (i) before any real-footage /
  non-synthetic test; (ii) before branch-(d) is exercised on content where cuts can occur; (iii) once
  the live dispatch is otherwise complete (post-D.1..D.5) and before the keystone series is declared
  done. It must not be deferred past the point where real video is processed. Owning: CMS §9.2 (compute
  scene-change-aware), §6.4 (cut frame -> checkpoint), §A4 (in-compute accumulation/threshold), P.11C
  (proven in cache-core selftest, awaiting live wiring).
- branch-(d) isolated-pin causal proof.
- K.1E.2/E.3/K.1F proof-default response-table config -> real instance-config option parsing.
- **CLIP-TEST HARNESS depends on the diagnostics (confirmed 2026-06-27).** The real-footage clip-test
  harness (e.g. test_000_Example_576p50.vpy/.bat — runs 576p50 through the live plugin to NUL/encode) is
  of little verification value WITHOUT the D-SUM end-of-run summaries + selectively-gated concise per-frame
  telemetry in place: a bare run only shows it did not crash, not whether pin balance held, recovery fired
  correctly, integrity stayed clean, or scene-change/checkpoint-promotion behaved across thousands of real
  frames. Therefore the large clip-test CAMPAIGN is sequenced AFTER the diagnostics arc. P.11C's proof does
  NOT use this harness — P.11C is proven on SYNTHETIC footage with constructed cuts (KDT-observable: cut ->
  reset-used -> output[K] stored WITH checkpoint flag -> a later recovery finds it as an anchor), exactly as
  D.1-D.5 were proven on synthetic footage; the REAL-FOOTAGE validation of P.11C folds into the later
  campaign once diagnostics exist.

- **DIAGNOSTICS ARC — sequenced AFTER P.11C, BEFORE the real-footage campaign (decided 2026-06-27).**
  The D-SUM diagnostics framework is fully DESIGNED (cnr3_diagnostics_specification_v1_5.md: §2.3 the
  per-summary COMPUTE/PRINT compile-time gate pattern with the paired #error "cannot print without
  compute" cross-check, print-subordinate-to-compute; §4 the 14-family catalogue D-SUM-01..14; R-PROCESS-19
  compute-disabled observe-only proof obligation; the FAIL/WARN/INFO severity model) and
  cnr3_memory_diagnostics_spec_v2.md (D-SUM-02). What is OWED is the IMPLEMENTATION: the src.zip shells
  carry only the D-SUM-11 hot-zone COUNTER MODEL (Cnr3CacheHotZoneDiagnosticStats + observers) and NO
  end-of-run formatting/printing for any family; memory-diag is an explicit placeholder.
  SEQUENCE (big-picture aligned): (1) P.11C scene-change calc FIRST (synthetic-proven, like D.1-D.5;
  its real-footage validation folds into the later campaign). (2) THEN the diagnostics arc — implement the
  D-SUM families with their compute/print gates + per-family R-PROCESS-19 observe-only proofs, including
  D-SUM-14 (scene-change/recursive-reset/checkpoint-promotion telemetry — NOT bundled into P.11C) and
  D-SUM-02 (memory, via salvage from the archived deprecated memory-diag code in GitHub). The diagnostics
  give BOTH the verifiable real-run telemetry (ownership/pin-balance D-SUM-04, integrity D-SUM-05, prune
  D-SUM-10, recovery D-SUM-12) AND the selectively-gated concise per-frame watch telemetry (hot-zone D-SUM-11,
  prune, hole-filling) needed to observe behaviour under fmParallel. (3) THEN first verifiable real-footage
  run + the large 576p50 campaign. (4) THEN the fmParallel arc.
  FIRST STEP of the diagnostics arc (Claude-owed): produce a concise 2-line summary of EACH of the 14
  D-SUM families (purpose + what it gates/observes) so the coordinator can choose the core implementation
  subset vs deferred. The end-of-run integrity report + abort_on_error (default False) + warn-vs-hard-fail
  severity policy (below) are PART OF this diagnostics arc, not separate.
  CODER PREP (recorded; action at diagnostics-arc kickoff, NOT during P.11C): the diagnostics-arc coder
  package includes cnr3_diagnostics_specification_v1_5.md + cnr3_memory_diagnostics_spec_v2.md + a pointer
  to the ARCHIVED deprecated memory-diag code, framed as ORIENTATION + SALVAGE REFERENCE — the memory-diag
  is mostly salvageable but is DEPRECATED (predates CMS07 / the D-SUM gate framework / R-PROCESS-19), so it
  is adapt-to-the-current-gate-pattern-and-prove-observe-only, NOT paste-in, and per R-PROCESS-08 /
  R-ARCH-05/07 the coder reads early but does NOT implement until the diagnostics phase is scoped+approved.

- longer sequential run beyond N==2; end-of-run integrity report + abort_on_error (default False)
  + warn-vs-hard-fail severity policy.
- full CMS fmParallel implications review (the CMS07.9 skim was non-exhaustive; FI-05 two-instance
  resource model likely genuine gap).
- fmParallel-phase (companion FI register): FI-05/06/07/08; operational two-instance diagnostics;
  test-tunable hot-zone/prune thresholds; cache-hit fast-path (Option A/B) revisit only if the one
  trigger-fetch on cache-hit is ever measured as significant AND confirmed from quotable core source.

---

## 6. DOCUMENT SET (current versions — new-chat reading order)

```text
CMS (design authority)     cnr3_cache_manager_design_v7_13.md             (CMS07.13)
Production Spec            CNR3_Handover_Pack_Production_Spec_v2_11.md     (§3.2 context master; §3A register + charter §3A.5.0)
Document A                Document_A_CNR3_Project_Context_and_Standing_Rules_v3_5.md   (context + standing rules)
Document B                Document_B_..._Current_State_v3_5_1.md          (current-state; top UPDATE block authoritative)
Diagnostics spec          cnr3_diagnostics_specification_v1_5.md          (subordinate)
Role/Reviewer Handover    CNR3_Designer_Reviewer_Role_Handover_v<current>.md
Reviewer Intro            CNR3_Handover_Introduction_to_new_reviewer_chat_v<current>.md
Coder Restart Intro       CNR3_Coder_Restart_Introduction_to_CMS07_RESUME_v<current>.md
Current-state (this)      THIS slimmed DELTA (live per-phase ledger)
```
**Authority:** CMS -> Production Spec §3A -> diagnostics -> handover pack. Repository wins over any
document on build state. **Reading order:** Reviewer/Coder intro -> CMS07.13 -> Document A v3.5 ->
Document B v3.5.1 (top block) -> this DELTA.
*(Intro/Role-Handover versions are swept to current as the final step of the doc refresh.)*

— End of CNR3 THIS-CHAT DELTA (slimmed), v4.12.
