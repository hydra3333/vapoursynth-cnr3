# CNR3 — Development RESUME on the CMS07.13 cache + pixel + scene-change architecture
*(Coder restart introduction (v6.3) — paste this at the start of a new memoryless chat,
ahead of the attached handover pack files. This is a RESUME of an in-progress, proven build
that is past its cache-core milestone, through its entire real-frame pixel path on
caller-supplied frames, and through the cache↔pixel / getFrame KEYSTONE — whose live dispatch
is now COMPLETE for all four branches (cache-hit, fresh-start, predecessor-present, recovery),
and the **branch-(d) recovery arc is COMPLETE (D.1-D.5)**, AND the **P.11C SCENE-CHANGE ARC is CLOSED
(.1-.5)** — scene detection is wired+proven across branch-a/c/d, committed through CMS07-P.11C.5. It is
NOT a fresh start, it is NOT "early cache-core work," it is NOT pixel-path work, and neither the keystone
dispatch, the recovery arc, nor the scene-change arc is un-started or partial — read the state below
carefully. The immediate live work starts with **Step 0: joint CMS sensibility review for hot-zone/pruning live wiring**. Only after that review should live cache-pressure wiring be scoped: hot-zone observation (CMS §5.7: at arInitial, if confirmed) then pruning into the live getFrame path. The prune logic + hot-zone machinery are
already built and selftest-proven but have ZERO live callers in the committed source; the live prune-TRIGGER contract and the CMS's big-picture sensibility need a focused designer+coder review before any coding (single-activation wiring now; concurrent prune revisited in the fmParallel arc). It is NOT a new algorithm — it is deciding how to wire proven componentry safely into the live path.
v6.3 supersedes v6.2. v6.2 advanced the state to P.11C-arc-CLOSED / CMS07.13 (unchanged) / live-cache-pressure-wiring-next; v6.3 adds the handover-safety correction that the next action is Step 0 CMS sensibility review before any hot-zone/prune wiring patch. The Design Alignment and
Escalation Charter (section 0.0) is retained.)*

This chat **resumes** CNR3 development on the CMS07.13 architecture. The build is far advanced
and proven phase-by-phase: the cache core is complete and proven, the entire scalar pixel
decision pipeline is complete and proven, the native byte-buffer access/bridge layer is complete
and proven, the real-VapourSynth-frame pixel path is complete and proven on caller-supplied
frames, AND the getFrame/cache keystone live dispatch is COMPLETE for all four branches —
cache-hit (K.1F), fresh-start (K.1D), predecessor-present (K.1E.2/E.3), and recovery (the full
branch-(d) arc D.1-D.5). Your job is **Step 0 CMS hot-zone/prune sensibility review**, then — only if that review confirms the CMS plan — live cache-pressure wiring, after first confirming the build state from the repository.

Do not treat older CNR3 memories, prior chats, or old source layout as active implementation
authority unless the attached pack says so. In particular, do **not** treat any "first
milestone / rename to .txt / propose the file layout / next phase is H.2A" framing from older
introductions as current — that is many phases out of date. Equally, do **not** treat
"the keystone is next / not yet proposed" framing (true in the v4.x introductions) as current
— the keystone is under way and committed through K.1D.

CNR3 is a VapourSynth **API4-only**, **integer-YUV-only** recursive temporal chroma stabiliser
(VHS/analogue chroma restoration). Its load-bearing difficulty is:
```text
output[N] depends on source[N] and already-filtered output[N - 1]
```
The predecessor is the already-filtered **output**, not merely `source[N - 1]`. Modern
VapourSynth scheduling may request frames out of display order, so CNR3 needs a correct
cache/recovery architecture before any parallel-performance work can be trusted. That
architecture is the CMS07.13 design, and it **completely supersedes** the previous CMS06.x
cache design and proof path. The eventual end-goal is `fmParallel` (a correctness phase).

---
## 0. WHERE THE BUILD ACTUALLY IS (read this before anything else)
**This is the single most important orientation point, because this introduction has
historically been pasted while badly out of date.** Confirm the live state from the
repository (section 2), but the expected state is:
```text
Cache core:          COMPLETE and proven through the C.14A aggregate milestone.
Scalar pixel chain:  COMPLETE and proven — P.1A (response tables) -> P.2A (config/geometry)
                     -> P.3A (int64 weighted blend) -> P.4A (downsampled-luma) -> P.5A
                     (signed-difference/lookup/blend bridge) -> P.6A (chroma-plane traversal).
Scalar->native:      COMPLETE and proven — P.7A (source-luma downsample traversal) -> P.8A
                     (native byte-plane access) -> P.9A (native luma downsample bridge).
Real-frame path:     COMPLETE and proven ON CALLER-SUPPLIED FRAMES — P.10A (VapourSynth
                     plane-view adapter) -> P.11A (caller-supplied frame-triplet validation)
                     -> P.11B (caller-supplied real-frame pixel composition) -> P.11C
                     (caller-supplied scene-change/reset).
KEYSTONE+RECOVERY+SCENE: LIVE DISPATCH FEATURE-COMPLETE (all four branches) WITH SCENE HANDLING; recovery arc COMPLETE + P.11C arc CLOSED, committed through P.11C.5:
                       K.1A request-plan structures + temporary KDT dev-trace   (count -> 46)
                       K.1B direct cached-output-return ownership (synthetic)    (count -> 47)
                       K.1C live getFrame passthrough scaffold                   (plugin-only)
                       K.1D live frame-0 fresh-start store/return (copyFrame)    (FIRST real output)
                       K.1E.2/E.3 live predecessor-present compute (N==1,2)      (branch-c; R-ARCH-06)
                       Recovery-Step-0  AS4 single-lock batch discharge          (count 48 -> 49)
                       K.1F  live direct cached-output return (cache hit)         (branch-b; count 49)
                       K.1G  plugin source split (no behaviour change)           (cnr3_arInitial.cpp /
                             cnr3_arAllFramesReady.cpp / cnr3_plugin_internal.h)
                       D.1   exact-anchor SINGLE-hole recovery                    (plugin-only; first live recovery)
                       D.2   exact-anchor MULTI-hole + bounded-window refusal      (plugin-only)
                       D.3   floor-fresh-start recovery                            (plugin-only; materialized-floor invariant)
                       D.4   adopt-skip + first-in-best-dressed primitives         (selftest; count 49 -> 51)
                       D.5   recovery-pin-survives-real-prune-pass                 (selftest; count 51 -> 52)
                       P.11C.1 scene-change uniform-wiring layout                  (plugin-only)
                       P.11C.2 scene-config + scdthr->threshold helper + store-req  (plugin-only)
                       P.11C.3 branch-c (predecessor-present) scene detection       (plugin-only; .vpy-proven)
                       P.11C.4 branch-d (recovery) per-hole+target scene detection  (plugin-only; .vpy-proven)
                       P.11C.5 scene-cut-checkpoint found as recovery anchor        (selftest; count 52 -> 53)
Latest committed:    CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof  (P.11C SCENE-CHANGE ARC CLOSED .1-.5)
Controlling CMS:     CMS07.13 (§0A charter; §9.5 materialized-floor invariant — clarifications, no rule/behaviour change;
                     R-LIFECYCLE / pre-compute adopt-and-skip carried forward from CMS07.9/.10)
Selftest count:      53/53 PASS (forced-fail 52/53 exit 1; verbose 53/53).
Next phase:          live cache-pressure WIRING — hot-zone obs (CMS §5.7 @arInitial) then prune into live getFrame.
                     Prune/hot-zone LOGIC built+proven but ZERO live callers; prune-trigger contract needs designer+coder
                     review first (single-activation now; concurrent prune in fmParallel). THEN diagnostics/telemetry placement + real-footage validation in the approved order ->                      (condensed 4-phase) -> fmParallel.
Branch:              dev_cache_manager
```
So: the cache core is done, the pixel maths is done, the scalar->native bridge is done, the
real-VS-frame pixel path is done on caller-supplied frames, AND the keystone live dispatch is
COMPLETE — all four getFrame branches (cache-hit, fresh-start, predecessor-present, recovery)
are live and proven both Debug+Release. The plugin produces correct recursive output through live
getFrame, and the entire branch-(d) recovery arc is proven: single-hole (D.1), multi-hole + bounded-
window refusal (D.2), floor-fresh-start (D.3), adopt-skip / first-in-best-dressed primitives (D.4), and
recovery-pin-survives-real-prune (D.5). The P.11C SCENE-CHANGE ARC is now also CLOSED (.1-.5): scene
detection runs uniformly across branch-a/c/d (predecessor-present .3, recovery holes+target .4), a detected
cut resets chroma + promotes the frame to a checkpoint, and such a scene-cut checkpoint survives prune and
serves as a later recovery anchor (.5) — all proven both configs. What is NOT yet done, and is your
immediate forward work, is **live cache-pressure WIRING** — the prune logic and hot-zone machinery are
built and selftest-proven but are NOT called from the live getFrame path; wire hot-zone observation (CMS
§5.7: at arInitial) then pruning, after a designer+coder review of the live prune-TRIGGER contract. (The
only deferred confidence remains real concurrent fmParallel scheduling, bounded to the fmParallel phase;
the concurrent prune case is explicitly part of that arc.)

## 0.0 THE DESIGN ALIGNMENT AND ESCALATION CHARTER (read before any work — it governs HOW you work)
This is the standing three-way governance model (designer/reviewer, coder, coordinator). It governs
how all three treat the CMS, escalate problems, and cross-check each other. The full text is also in
the Production Spec section 3A.5.0 and the Role Handover Part 3 (D0); it is reproduced here so a fresh
coder internalises it before touching anything.

```text
(Three-way working charter: designer/reviewer, coder, coordinator. The coordinator holds final
authority on scope, sequencing, and commits.)

1. CMS is the controlling guide; strict alignment is the default. Two distinct issue types license
   departing from "follow the CMS as written," and both are surfaced rather than handled silently:
   - RULE-DEVIATION issue (case a): a NAMED, SPECIFIC CMS rule, if followed, would produce a
     demonstrably wrong, inconsistent, or unsafe result. This bar is HIGH: comparable to the
     evidence that produced the CMS07.10 correction (analysis/source-level proof, not a hunch), and
     never invoked for convenience, brevity, or preference.
   - CMS-GAP issue (case b): a bigger-picture concern (emergent risk, missing abstraction,
     fmParallel/reliability/safety implication) with little or no correspondence to any specific
     existing rule, which may call for a NEW or REVISED rule or approach. This is NOT gated behind
     the high deviation bar; identifying that the CMS is silent or under-specified on something that
     matters is encouraged, and lands as a surfaced critical issue or proposed rule even when no
     single existing rule is in conflict.
   - Issues are classified RULE-DEVIATION or CMS-GAP when raised; the classification may be
     corrected as evidence develops (a gap that turns out to conflict with a specific rule, or
     vice versa).

2. On either issue type: stop and raise -- never route around silently. Work ON THE AFFECTED CHANGE
   pauses (unrelated, clearly out-of-scope work may continue); the issue surfaces as an explicit
   decision, resolved by designer+coder agreement with coordinator approval before proceeding. For
   RULE-DEVIATION the resolution amends or excepts the named rule; for CMS-GAP it produces a
   new/updated rule, a recorded approach, or an owed-items entry. No party implements a deviation,
   or quietly works around a gap, unilaterally or with deferred mention. Local experiments to
   UNDERSTAND an issue are allowed, but must be labelled exploratory and must not be committed or
   treated as accepted design until the issue is resolved.

3. Cross-checking is bidirectional and substantive, into each other's domain. The designer
   read-firsts the coder's diffs against design intent and independently computes/verifies golden
   values; the coder checks the designer's scope against code and primitive reality. Each verifies
   the other's home turf rather than deferring to it. The coordinator arbitrates and holds final
   authority on scope, sequencing, and commits.

4. Weight scales to risk. Full review ceremony for changes to proven code, lifecycle/concurrency,
   anything bearing on the long-term fmParallel goal, or anything where a gap would be silent and
   costly; lighter touch for mechanical steps. For the fmParallel goal specifically, concurrency
   reasoning is recorded at design time, not deferred to "it passed single-threaded."

5. Agreed deviations, new/updated rules, and discovered gaps are recorded durably -- CMS correction
   block, new/revised CMS rule, owed-items ledger, or DELTA/handover note as appropriate -- so the
   reasoning persists across chats and is neither lost nor re-litigated. For behaviour, lifecycle,
   ownership, concurrency, or proven-code changes, the agreed resolution is recorded BEFORE OR AS
   PART OF the commit that implements it -- not deferred.
```

The D.1 design road (see Document B / the DELTA) is the worked example of this charter in action: the
designer's first routing sketch contained a time-of-check/time-of-use hazard, a false "minimal change"
premise, a wrong recovery-search assumption, and a source-set/hole-count mismatch — all caught by the
coder's independent review across several rounds BEFORE any code. That is the charter working as
intended. You are expected to push back the same way.

---
### The keystone commits, in one line each (what they did)
```text
K.1A  Added the keystone request-plan structures (branch enum/struct; recovery request is a
      holes-list / source-set, NEVER a blanket span; the hard-status branch is a CARRIER for
      existing C.13B guard results, not a new validator) and a temporary KDT dev-trace
      (CNR3_KEYSTONE_DEV_TRACE; [KDT]/[KDT-SUMMARY] driven by the plan structure). No getFrame
      wiring, no source lifecycle, no pixel call, no cache-semantic change, no VS header edit.
      Behaviour-adding -> +1 selftest (45 -> 46).
K.1B  Proved direct cached-output-return ownership, synthetic-first, using the REAL
      Cnr3OwnedFrameRef and REAL cache lookup/addref (counters OBSERVE real ops): success
      1/0/1 (acquired/released/transferred), cleanup-before-transfer 1/1/0, no-acquire miss
      0/0/0. The synthetic sink models the getFrame-return boundary. The real VSFrame
      return-to-VapourSynth was explicitly OWED here and is expected to retire INSIDE the
      branch-(c) work. Behaviour-adding -> +1 selftest (46 -> 47).
K.1C  First live getFrame step: a passthrough scaffold with FIVE R-ARCH-06 fences (removable
      guard; a DISTINCT callback that gets replaced not extended; the scaffold frame is NEVER
      cached / NEVER a predecessor / NEVER checkpointed; a [KDT] SCAFFOLD_NOT_FILTERED marker;
      a return-point comment). [KDT] is emitted ONLY inside getFrame, never at load/registration.
      PLUGIN-ONLY (changes only src/vapoursynth-Cnr3.cpp + src/cnr3_build_config.h); proven by
      the coordinator A/B byte-compare harness, NOT by a selftest -> count stays 47.
K.1D  The FIRST REAL output frame: output[0] created, stored as a cache-authoritative
      checkpoint, and returned through live getFrame; N>0 cleanly refused. Reached via
      copyFrame(source, core) (a bitwise, writable, caller-owned duplicate) because frame-0
      fresh-start output[0] = source[0] byte-for-byte (no predecessor, no blend; luma always
      source-copy, chroma source-copy when no predecessor) -> so NO proven code is touched
      (zero contact with cnr3_frame_processing.cpp / P.11C). PLUGIN-ONLY; A/B harness green
      (frame-0 byte-identical to source; N>0 clean refusal leaves a header-only y4m, no FRAME
      marker). Count stays 47. Guard: CNR3_KEYSTONE_LIVE_GETFRAME_FRAME0_PROOF.
```

```text
K.1E.2/E.3  Live predecessor-present compute for N==1 then N==2 (branch-c): acquire cached
      output[N-1] as predecessor (real lookup/addref, carried in frameData), request source[N],
      compute output[N] via the PROVEN P.11B path, release predecessor, store, return. Ownership
      tail acquired=1/released=1/transferred=0 (consumed-and-released, the opposite of a cache-hit
      return). Known-answer goldens 161/95 (N=1) and 163/93 (N=2). Closed R-ARCH-06 live (the
      predecessor is the cached filtered OUTPUT, never source[N-1]).
Recovery-Step-0  AS4 single-lock batch discharge: discharge_all delegates to the cache core taking
      cache_mutex_ ONCE for the whole pin-list. Cache-core only; count 48 -> 49.
K.1F  Live direct cached-output return (branch-b): present-N pins output[N] at arInitial (gap
      protection), requests source[N] as an Option-C lifecycle TRIGGER (retrieved+immediately freed,
      NOT consumed), returns the cached frame at arAllFramesReady via add_ref + Step-0 discharge. This
      proved the R-LIFECYCLE correction (CMS07.10 9A.1.1): EVERY getFrame branch requests >=1 real
      source at arInitial and returns only at arAllFramesReady. Plugin-only; count unchanged 49.
K.1G  Plugin source split, no behaviour change: vapoursynth-Cnr3.cpp split into cnr3_arInitial.cpp
      (branch START), cnr3_arAllFramesReady.cpp (branch-tag EXECUTION), cnr3_plugin_internal.h
      (private shared decls). New .cpp in the cnr3 DLL project only; selftest compiles neither. The
      live getFrame code now lives in these files — that is where D.2 lands.
D.1   Live branch-(d) exact-anchor SINGLE-hole recovery (the first live recovery): A-safe-1 routing
      (cache-hit pin -> N==0 fresh-start -> predecessor pin -> recovery), each decision a find-and-pin
      (NO naked peek). Reconstructs absent output[N-1] from a pinned anchor at N-2, then computes
      output[N]. Accept gate restricts to hole_count==1 & anchor==N-2 (or zero-hole degenerate
      anchor==N-1); source set DERIVED as {N} U holes (dissolved window); pre-compute adopt-and-skip;
      authoritative target return on duplicate; AS4 batch discharge. Branch-c refactored to ACCEPT an
      already-recorded predecessor pin from routing. P.11C scene-change DEFERRED uniformly
      (scene_change_deferred=1 — a shared owed ledger item, to be wired across all branches before any
      real-footage test). Goldens 145/111 (hole) and 147/109 (target). Plugin-only; count 49.
```

### THE K.1D REORIENTATION — the chief disciplinary lesson of the keystone (read this; it is about YOU)
**The first K.1D patch was DROPPED, even though it built and passed the four-way 47/47.** On
the read-first diff review it was found to (1) silently REWRITE the body of the proven,
selftested P.11C reset function to route through a new helper; (2) introduce a SECOND
source-to-output copy orchestration, hand-setting the reset-summary flags to MIMIC the reset
path without BEING it; and (3) broaden scope undisclosed into the proven
`cnr3_frame_processing.cpp` (+351 lines) against a "report before broadening" commitment.
**A passing four-way after swapping proven internals is NOT proof of equivalence** — it proves
only that the existing selftests did not DETECT a difference, not that there is none (the
P.11C selftest may simply not exercise the changed path). The patch was **WITHDRAWN to the
proposal stage** — not patched-and-fixed — and the reorientation produced a smaller, safer
design (`copyFrame`, touching no proven code). This is now a standing rule (R-PROCESS-21,
below). It exists because the coder's observed failure mode at the keystone is reasoning
forward from getFrame and touching proven code to avoid a conversation. **If standing up a
phase appears to require touching proven pixel or cache-core internals, STOP and raise it as a
design question before writing it — do not fold it into the patch.**

**Document B (current version, see section 1) is authoritative for volatile state and the forward roadmap.
The older keystone and P.11C sections are historical except where explicitly restated as proven background.
This introduction carries the live Step 0 hot-zone/prune review orientation (section 0.1); where it overlaps
Document B, Document B (top UPDATE block) and the repository win on build state.**

---
## 0.1 THE LIVE TASK — Step 0 CMS hot-zone/prune review, then live cache-pressure wiring

The live getFrame dispatch is FEATURE-COMPLETE (all four branches) WITH scene handling, the branch-(d)
recovery arc is COMPLETE (D.1-D.5, all committed both configs), and the P.11C scene-change arc is CLOSED
(.1-.5, committed through CMS07-P.11C.5). The next action is deliberately NOT to start coding from the
old plan text. The next action is a **joint CMS sensibility review** focused on hot zones and pruning:

```text
Step 0: review the CMS itself for sensibility and gaps regarding live hot-zone/prune wiring.
```

Why Step 0 exists:
```text
- Hot-zone and prune logic are already built and selftest-proven in cache-core.
- The committed live getFrame path currently has zero live callers for the cache-pressure policy:
  record_hot_zone_observation / retire/merge hot zones / execute_bounded_prune_pass.
- The live store path appends cached outputs and does not run the soft prune trigger.
- Therefore the likely remaining functionality is live cache-pressure wiring.
- But before coding, the CMS must be cross-reviewed against the current proven implementation and
  final goals so we do not implement an old or incomplete policy merely because it is written down.
```

Step 0 review questions:
```text
1. Is the CMS hot-zone/prune policy still conceptually correct after P.11C.5?
2. Does the policy fit the final fmParallel target while allowing safe single-activation wiring now?
3. What exactly should a live hot-zone observation mean: requested frame, requested span, recovery
   holes/source span, returned frame, or some combination?
4. Where exactly should observation occur: arInitial, arAllFramesReady, after store, or more than one?
5. When exactly should the live store path invoke bounded prune?
6. How does prune-trigger timing compose with the active pin_list and the arInitial->arAllFramesReady gap?
7. What diagnostics/KDT are mandatory before real clips can be interpreted?
8. Which concurrent/fmParallel questions remain explicitly deferred?
```

Provisional post-review implementation shape, only if Step 0 confirms it:
```text
HZP.1  hot-zone observation/retirement wiring, likely at arInitial per CMS §5.7;
HZP.2  central post-store prune-trigger helper for live store paths;
HZP.3  synthetic live prune-trigger proof that does not depend on a particular victim;
HZP.4  diagnostics/telemetry placement and first real-footage validation sequencing;
then fmParallel/concurrency validation later.
```

Carry these settled findings (do NOT re-derive):
```text
1. R-LIFECYCLE (CMS07.10 9A.1.1): EVERY getFrame branch requests >=1 real source at arInitial and
   returns only at arAllFramesReady. The act-time branch is keyed on the frameData branch tag set
   at arInitial, never on re-inspecting frame state.
2. A-safe-1 routing hard floor: no branch exits arInitial relying on an UNPINNED observation; each
   selected branch owns its pinned foundation via its own atomic find-and-pin; a miss is only a
   routing opportunity. (No naked presence peeks.)
3. Dissolved source window: request {N} U genuine-hole-sources, DERIVED from the hole catalogue,
   never a blanket backward span and never hardcoded.
4. P.11C scene-change is CLOSED, not deferred: branch-c and branch-d compute/reset/checkpoint routing
   are enabled and proven; P.11C.5 proves the cache-half scene-cut-checkpoint recovery-anchor effect.
5. fmParallel goal: every live cache-pressure design note must carry an explicit interleaving analysis.
   Single-activation wiring may be done first, but concurrent prune/hot-zone behaviour is still owned by
   the fmParallel arc / FI-06-FI-08.
6. Golden-chain note (durable): robust pixel proofs combine KDT mechanism + direct byte checks via
   cache-hit follow-up, never target byte margin alone.
```

Where the relevant live/cache code lives:
```text
src/cnr3_arInitial.cpp            branch STARTs; likely hot-zone observation point if Step 0 confirms CMS §5.7.
src/cnr3_arAllFramesReady.cpp     branch COMPLETIONs, store/return paths, recovery ascending fill loop; likely
                                  post-store prune trigger location if Step 0 approves it.
src/cnr3_plugin_internal.h        frameData branch tags, recovery vectors, active pin_list.
src/cnr3_cache_core.cpp/.h        proven hot-zone/prune primitives: record_hot_zone_observation,
                                  retire/merge hot zones, calculate trigger decision, execute_bounded_prune_pass.
src/cnr3_cache_core_selftest.cpp  D/G/P.11C cache-policy and composition proofs.
```

Do not implement before Step 0 concludes:
```text
- do not change cache-core prune semantics;
- do not introduce checkpoint provenance;
- do not wire pruning from every store call without a central trigger contract;
- do not combine CMS review, hot-zone wiring, prune wiring, diagnostics, and real-clip testing into one patch;
- do not claim fmParallel prune safety from the single-activation wiring proof.
```

## 1. Attachments expected for this resume (and how they lead into Doc A and Doc B)
Do not proceed from this introduction alone. This intro is the LEAD-IN; the authority is the pack.
Read in this order, and take the HIGHEST version present if names differ:

**This intro orients you. Then Document A gives you the standing project context and rules; then
Document B gives you the live build state and work plan. The CMS is the design authority above both.**
```text
1. This introduction (orientation only):
   CNR3_Coder_Restart_Introduction_to_CMS07_RESUME_v6_3.md
2. Controlling design authority:
   cnr3_cache_manager_design_v7_13.md
   (CMS07.13 — supersedes all earlier CMS07.x and CMS06.x. Carries: 9.7 keystone
    predecessor-sourcing; 9.7.7 rpGeneral source-input dependency (FI-04 resolved); 9A.1.1 the
    arInitial/arAllFramesReady frame-return contract WITH the R-LIFECYCLE correction proven by
    K.1F; 9.2/9.6.5 pre-compute adopt-and-skip normative since CMS07.9; 9.1/9.5/9.6 the bounded
    recovery model that the full branch-(d) arc D.1-D.5 wired and completed; 0A the Design Alignment
    and Escalation Charter; 9.5 the materialized-floor-is-the-foundation invariant. CMS07.11/.12/.13
    are charter+clarifications — no design rule, AS scope, or section-number change. 6.4/9.5 cut->
    checkpoint promotion is the recovery interlock P.11C wires to.)
3. Project context / standing rules  ->  DOCUMENT A:
   Document_A_CNR3_Project_Context_and_Standing_Rules_v3_7.md  (or highest present)
   (the standing project context + the full section 3A register reproduced from the Production
    Spec, incl. R-PROCESS-20..23 and the Design Alignment and Escalation Charter at 3A.5.0.
    NOTE: if only an older Document A (v3.4 or earlier) is present, it is on the K.1D/CMS07.8
    baseline and its STATE pointers are stale — trust THIS intro's section 0 and Document B for
    current state, and the Production Spec section 3A for the authoritative rule text.)
4. Current work plan + BUILD STATE  ->  DOCUMENT B:
   Document_B_CNR3_Restart_Work_Plan_and_Current_State_v3_7.md  (or highest present)
   (the live build state through P.11C.5, the working method, salvage inventory,
    next phases, and the do-not-implement list. READ THIS for where the build actually is.
    Its top UPDATE block is authoritative; older blocks below are history.)
5. Production Spec (canonical context master + section 3A rules):
   CNR3_Handover_Pack_Production_Spec_v2_13.md  (or highest present)
   (populated section 3A register: R-PROCESS-20 (PDAP), R-PROCESS-21 (proven-code-stays-proven),
    R-PROCESS-22 (lifecycle/API from documentation, not test behaviour), R-PROCESS-23, and the
    Design Alignment and Escalation Charter at 3A.5.0. Section 3A is the AUTHORITATIVE rule text.)
6. Diagnostics spec:
   cnr3_diagnostics_specification_v1_5.md
   (subordinate to the CMS and section 3A; section 2.8 = the temporary keystone KDT dev-trace,
    removed at the post-keystone cleanup.)
7. Manifest:
   CNR3_Handover_Pack_*_MANIFEST.md
   (reading order and pack contents; may lag the version numbers above — the individual documents'
    own version headers win.)
```
Companion documents (read if present; not the controlling design):
```text
- CNR3_Designer_Reviewer_Role_Handover_v1_9.md  (or highest present)
  (the DESIGNER/REVIEWER role doc — review disciplines D0-D16 (D0 is the Design Alignment and
   Escalation Charter), decision heuristics, the pixel-layer reference confirmed against vsCnr2.cpp,
   the accuracy rule, recorded deliberate divergences, and the review checklist. It is the clearest
   map of what the coordinator will scrutinise — and what you should self-check before proposing.)
- CNR3_THIS_CHAT_DELTA_current_state_SLIMMED_v4_13.md  (or highest present)
  (the SLIMMED current-state delta companion to Document B — a committed-phase INDEX through D.5
   (recovery arc COMPLETE), the R-LIFECYCLE finding kept in full, the P.11C active-phase detail, and
   the owed-items ledger. Per-phase golden chains / proof narratives live in the dev-branch git
   history. If included, read it for current state + depth pointers.)
```
NOT part of the durable implementation authority (do not treat as controlling):
```text
- CNR3_CMS_Future_Investigations_and_Open_Questions_v7_13.md
  (NON-NORMATIVE companion to CMS07.13, lockstep filename; deferred tuning / fmParallel-phase
   questions only (FI-01..08); ignore for implementation. FI-04 is RESOLVED into CMS 9.7.7. The open
   FI items are the subject of the upcoming fmParallel phase.)
- the old .txt reference source under src/superseded_by_v7/ (salvage is per-case, approval-only).
- older Document A / Document B / Role Handover / introduction versions, and the old CMS06-era
  decision log — out of scope as active inputs (intentionally, to keep stale assumptions out).
```
If **CMS07.13 itself is not attached**, stop and say so. You may comment on this introduction, but
you cannot enumerate rules or proceed without the controlling design.

---
## 2. FIRST action — confirm the build state from the repository, then start Step 0 review

Before anything else (before enumerating rules, before proposing a patch), confirm the build state from the
authoritative source — the repository — not from these documents' say-so. This re-establishes the project's
"prove it, do not assert it" discipline from your very first action:

```text
1. Read the recent git log. Confirm the latest commit is:
       CMS07-P.11C.5: prove scene-cut checkpoint recovery anchor
   or equivalent commit title carrying marker:
       CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof

2. Read src/cnr3_build_config.h; confirm CNR3_EDIT_VERSION reads:
       CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof

3. Build + run the isolated cache-core selftest and confirm the four-way:
       Debug   normal                              -> 53/53 PASS, exit 0
       Release normal                              -> 53/53 PASS, exit 0
       Release --force-fail-for-harness-proof      -> 52/53 PASS, 1 FAIL, exit 1
       Release --verbose                           -> 53/53 PASS, exit 0

4. In the --verbose trace, confirm the P.11C.5 scenario is present:
       non-grid unpinned frame 165 stored as sole checkpoint;
       bounded prune removes ordinary non-checkpoint frame 1;
       frame 166 absent by construction;
       read-only bounded recovery for 167 anchors on checkpoint 165.

5. Audit the live source for the cache-pressure wiring gap before proposing any implementation:
       record_hot_zone_observation / retire hot zones / execute_bounded_prune_pass
   should have no live getFrame callers yet. Report if that is no longer true.

6. Start the Step 0 review as text, not a patch:
       Does CMS07.13 still give a sensible and complete live hot-zone/prune wiring plan
       against the current P.11C.5 code, safety constraints, real-clip goal, and final
       fmParallel target?
```

Do not produce a hot-zone/prune wiring patch until Step 0 has been reviewed and approved.

---
## 3. WHEN IN DOUBT — raise it for review; do not decide alone
This project runs through a **designer/coordinator review loop**, and that is exactly what has
kept the build sound across every phase. There are two different "ask" situations, and BOTH mean
stop and raise it — not proceed on your own judgement:
```text
A. CMS gaps (R-AUTH-03): if the CMS is silent, ambiguous, or incomplete on an implementation
   point — STOP and ask. Do not guess, do not improvise.
B. Design-coordination questions (broader than the CMS): if you have ANY doubt about
       - the direction of the work,
       - which subphase comes next or a subphase's scope,
       - whether a test case is adequate / genuinely discriminating,
       - a subphase's exit bar or per-phase goal,
       - whether something is in scope for the current subphase,
       - whether reuse of a proven operation would TOUCH it (always a design question — see
         section 0.1 / R-PROCESS-21),
       - whether something diverges from vsCnr2 and, if so, whether that divergence is intended,
   then RAISE IT to the user/coordinator for review before acting. "The CMS does not forbid it"
   is NOT license to decide a direction, scope, or test-design question unilaterally.
```
Concretely: the build cadence is **propose → review → approve → code**, never idea straight to
committed code. The coordinator runs a separate designer review of each proposal against the
spec and the vsCnr2.cpp source. If you are unsure whether to raise something, raise it. A
question is cheap; a wrong unilateral call on scope, test design, a silent divergence from the
reference, or a touch of proven code is not.

This has been borne out repeatedly — most sharply at the keystone, where a patch that passed the
four-way but silently rewrote proven code was caught on review and withdrawn (the K.1D
reorientation, section 0). The strongest phases were the ones where the coder surfaced a doubt
(a reachability question, an integer-division quirk, an edge-handling divergence, a
self-predecessor shortcut it refused) for review rather than deciding it alone. That instinct is
the project's main safety mechanism — keep it.

---
## 4. How this phase of work differs from the cache-core, pixel, and keystone eras (orientation)

The cache-core phases proved concurrency-correctness primitives: atomic lock scopes, pin/checkpoint/prune
discipline, hot-zone candidate ordering, prune trigger hysteresis, recovery contiguity, and checkpoint-class
retention. The pixel phases proved arithmetic- and real-frame-correctness. The keystone/recovery/P.11C arcs
then connected those pieces through live getFrame and closed scene handling across all branches.

You are now in a fourth kind of correctness: **live cache-pressure policy wiring**.

The relevant distinction:
```text
cache-core componentry is proven;
live getFrame policy trigger/placement is not yet wired or proven.
```

The risks of this era:
```text
- Policy placement: hot-zone observation and prune triggering must occur at the right live lifecycle points.
- Lifecycle/ownership: prune must not invalidate frames protected by active pins or frames needed across the
  arInitial -> arAllFramesReady gap.
- Recovery integrity: pruning must preserve the bounded recovery model and checkpoint retention assumptions.
- Diagnostics: real-clip behaviour will be hard to interpret unless hot-zone/prune decisions are observable.
- Proven-code protection: do not change cache-core prune semantics merely to make live wiring easier.
```

The proof surface is policy/lifecycle composition, not scalar pixel vectors. A phase may be plugin-only if it
only wires live observation/KDT, or selftest-adding if it extends deterministic cache-core proof. Each proposal
must state exactly how it proves the live cache-pressure property without depending on a particular incidental
prune victim unless that victim is deterministically specified by the test.

---
## 5. Hard precedence and old/new separation
```text
If CMS07.13 conflicts with, or is merely unclear in alignment with, prior material:
    CMS07.13 wins unless the user explicitly says otherwise.
If CMS07.13 itself is silent, ambiguous, or incomplete on an implementation point:
    stop and ask (see section 3). Do not guess and do not improvise.
```
References to "CMS07.0" (or any earlier CMS) as controlling, inside reproduced rule text, mean
the latest prevailing CMS — currently **CMS07.13**. Specific CMS section pointers are
version-specific and must be re-checked against CMS07.13. All pre-CMS07 cache code/design is
superseded: old code is salvage reference only, per Document B section 8.5 and the section 3A
salvage rules.

A LIFECYCLE/API epistemics rule now applies (R-PROCESS-22): a VapourSynth lifecycle or API
contract — the arInitial/arAllFramesReady activation-reason and frame-return contract, what may
be requested/retrieved in which activation, a dependency/request-pattern declaration
(rpStrictSpatial vs rpGeneral), a threading/ownership guarantee — must be established from the
AUTHORITATIVE DOCUMENTATION (the R76 VapourSynth4.h header and the CMS), NOT inferred from "it
compiled / a test passed / a path worked." Undocumented-but-works is version-fragile and
especially dangerous under fmParallel. If a contract is unclear, resolve it against the docs; if
the docs are silent, stop and ask.

---
## 6. The highest-risk traps (do not conflate old and new concepts)
These remain inviolable even though the cache core and pixel path are proven — the keystone
re-touches all of them, and adds the proven-code trap.

### 6.1 Cache-core traps (binding at the keystone)
```text
1. Pinning is the mandatory correctness baseline — never optional/deferred. There is exactly ONE
   pin concept: consumer-claim, recorded on a per-invocation pin-list.
2. A checkpoint is a separate eviction-protection FLAG, not a pin.
3. Hot zones are prune-policy HINTS only — pins provide active liveness, hot zones do not.
4. Recovery uses the CMS two-phase model: request source N plus genuine holes only — never a
   blanket bounded-warmup source window.
5. The predecessor is the previous filtered OUTPUT from the cache/recovery layer, NEVER
   source[N-1] (R-ARCH-06). This is the keystone correctness property of the whole design.
```

### 6.2 Pixel/arithmetic traps (load-bearing as the keystone feeds real pixels into P.11B)
```text
6. Signed differences (current - previous) MUST stay signed int end-to-end into the table lookup
   — NO unsigned intermediate anywhere on the sample->diff->index path. (Proven correct through
   P.5A; preserve it as real pixels feed the path through the keystone.)
7. The blend accumulator is int64; shift2 = depth<<1, shift = 1LL<<shift2, shift1 = shift>>1,
   reproduced bit-exactly. Do NOT "improve" definitional integer arithmetic.
8. Recorded deliberate divergences from vsCnr2 (do NOT "fix" back, do NOT flag as bugs — see the
   Role Handover accuracy rule for the full reasoning):
     - parameter scaling uses round-to-nearest (value*peak+127)/255, more accurate than vsCnr2's
       integer-factor truncation at 10/12/14-bit (identical at 8/16-bit);
     - P.4A downsample-luma CLAMPS edge taps rather than reading past the frame as vsCnr2 does.
   The GOVERNING RULE: accuracy upgrades only where vsCnr2 is accidentally lossy; definitional
   integer arithmetic is reproduced bit-exactly. When unsure which a step is, treat it as
   definitional and ask.
```

### 6.3 The proven-code trap (the keystone's defining risk — R-PROCESS-21)
```text
9. Proven code stays proven. Once a function is proven by a committed selftest (the P.11B/P.11C
   pixel path, the cache-core internals), its behaviour AND internals are frozen unless a phase
   explicitly proposes the change and the designer approves it IN ADVANCE. A passing four-way
   after an internals swap is NOT proof of equivalence. If reuse appears to require touching
   proven code, that is a DESIGN QUESTION to raise — not a licence to modify, re-implement in
   parallel, hand-set flags to MIMIC the proven path, or broaden scope into a proven file
   undisclosed. When a change endangers proven code, WITHDRAW-and-reconsider, do not patch-and-fix.
   (This is the K.1D reorientation lesson; it is the bar to watch hardest on K.1E's P.11B reuse.)
```
Nothing may be implemented that obstructs the fmParallel end-goal unless it is an unavoidable,
explicitly recorded, temporary stepping-stone preserving the path to fmParallel.

---
## 7. Engineered guards you must respect
### 7.1 Atomic-scope register (AS1-AS7)
CMS07.10 defines an atomic-scope register, AS1-AS7. It is designer-owned and inviolable. Every
cache critical section is enumerated there, including what happens inside one lock acquisition and
in what order. Implement these scopes exactly — do not shrink, split, merge, reorder, or
reinterpret them. If implementation reveals a needed operation the register does not cover, raise
it; do not invent an ad-hoc lock scope. (Directly relevant as the keystone wires the cache to real
requests; the cache is used through its public store/lookup API at K.1E.)

### 7.2 V5 firewall
VapourSynth frame reference counts are internally atomic — and that **gives you NOTHING over lock
scopes.** It protects a single `addFrameRef`/`freeFrame` only. It is not a licence to take a pin
outside the cache lock or to shrink any critical section. The protected thing is the multi-step
cache decision (find-then-pin, decide-then-detach), not the refcount bump.

### 7.3 VapourSynth lifecycle + frame-return contract (VS-LIFECYCLE-01; CMS 9A.1 / 9A.1.1)
Any source frame retrieved in `arAllFramesReady` must have been requested in `arInitial` of the
same activation (VS-LIFECYCLE-01). And the frame-return contract (CMS section 9A.1.1, established
from the R76 header): `arInitial` requests inputs and returns NULL; a frame is returned only at
`arAllFramesReady`. The source-filter exception (return a frame from arInitial) does NOT apply to
CNR3 — it is a dependency filter with an input node. **Both are binding now, as the keystone wires
getFrame — they are no longer hypothetical.** Settle these from documentation, not from a passing
run (R-PROCESS-22).

### 7.4 Dependency declaration: rpGeneral (FI-04 resolved, CMS 9.7.7)
The source-input dependency declaration is **rpGeneral**, not rpStrictSpatial, for a recursive
filter. rpStrictSpatial stops being truthful once recovery requests bounded source ranges;
rpGeneral is conservative-correct. **fmUnordered is unchanged** — `requestPattern` is a SEPARATE
layer from `filterMode` and does not affect the CMS7 cache. K.1E makes this declaration change.

### 7.5 Lock / ownership disciplines held at every phase
```text
- ONE cache-wide non-recursive mutex; RAII guard only.
- Decide INSIDE the lock; do the slow part (especially freeFrame) OUTSIDE it.
- freeFrame is NEVER called inside the cache lock (detach under lock, free after).
- pin-and-record is indivisible; pin-list capacity reserved BEFORE the lock.
- checkpoint is a flag, not a pin; hot zones are hints, not liveness.
```
Document B section 7 carries the full list. These are inviolable.

### 7.6 Category-B developer-alert (emission half of the C.13B guard)
At getFrame integration / error-mapping time, a hard cache status must map to a clean filter
failure (setFilterError) plus a bounded one-shot stderr developer-alert OUTSIDE locks. This is the
EMISSION half of what the C.13B recovery-contiguity guard already DETECTS (CMS section 9.6.4).
Expected Category-A duplicate/adopt outcomes stay silent. The cache core itself emits no stderr.
(For K.1E specifically, the error surface is the N>1 clean refusal; the full developer-alert wiring
arrives with the recovery branch.)

---
## 8. Section 3A is populated — rule enumeration is verification, not first population
The Production Spec section 3A Prevailing Rules Register is populated. Enumerate the prevailing
rules back to the user, but the purpose is **verification/reconciliation**, not first population.
Distinguish:
```text
REGISTER-OWNED rules:
    authority, pack governance, process, architecture/salvage, retired-fact entries — recorded in
    Production Spec section 3A (and reproduced in full in Document A v3.3). The process rules now
    run R-PROCESS-01 through R-PROCESS-22, including R-PROCESS-20 (PDAP), R-PROCESS-21 (proven-code
    stays proven), and R-PROCESS-22 (lifecycle/API contracts from documentation).
CMS-DEFINED / HANDED-OFF rules:
    design / cache-core / reference-count / VapourSynth-lifecycle / recovery / constant /
    instrumentation / atomic-scope rules defined in CMS07.10. NOT duplicated, indexed, or re-IDed
    in section 3A.
```
If you find an apparent missing rule, conflict, ambiguity, or candidate, raise it for user
decision (section 3). Do not silently treat it as controlling.

---
## 9. Salvage policy (per-case, approval-only)
The cache core is proven complete and the pixel-maths reference has largely been salvaged/
reimplemented through P.1A–P.11C, so check what is already active before re-salvaging anything.
Every salvage remains per-case, inspected, and explicitly approved (R-ARCH-07). The inventory is
in **Document B section 8.5**. Key points:
```text
- The pixel-maths reference (vscnr2-style response tables; the frame_internal_processing core with
  its explicit-previous-output boundary) is largely DONE via P.1A-P.11C. That proven code is now
  protected by R-PROCESS-21 — reuse it through thin public calls, do not re-touch its internals.
- TREAT WITH CAUTION: cnr3_common.h (stale CMS06 assumptions may ride along).
- QUARANTINE (do not open for ideas): the old cache managers — they embody the retired concepts and
  are the main route by which they creep back.
- CNR2 / vscnr2 is PIXEL-MATHS reference only. NEVER salvage CNR2 recovery/predecessor logic — that
  approximation (substitute source[n-1] when previous output is absent) is exactly what CMS07
  replaces (R-ARCH-06).
- vsCnr2.cpp is the bit-exact reference for the pixel arithmetic. The canonical source the designer
  verifies against is:
  https://raw.githubusercontent.com/Asd-g/AviSynth-vsCnr2/refs/heads/main/src/vsCnr2.cpp
```
Old `.txt` code is not copied into new files without approval.

---
## 10. Process rules that matter immediately (orientation only — section 3A holds the wording)
```text
- Comments: concise, useful, never safety-incomplete.
- Code delivery uses the PDAP (R-PROCESS-20): a downloadable .patch per phase (git diff -U10 from
  the committed baseline), with a Stage-1 validation block (git apply --check, --whitespace=error,
  git diff --check, isolated build, changed-files list, apply sequence, build/test commands). The
  coordinator does the read-first review, applies, builds Debug+Release of BOTH cnr3 and
  cnr3_cache_core_selftest (and, for a plugin-only keystone phase, the cnr3.dll plugin), runs the
  four-way, and commits the src/ files (NOT the .patch). Provide a Visual Studio-style commit
  title/body with each PASS. Inline before/after edit blocks are NOT used for code delivery.
- The four-way: Debug normal (N/N exit 0), Release normal (N/N exit 0), Release
  --force-fail-for-harness-proof ((N-1)/N exit 1), Release --verbose (N/N exit 0). A D-SUM
  compute-gate change adds the R-PROCESS-19 macro-off observe-only proof (a fifth run); keystone
  phases so far have added no D-SUM gate.
- A live-getFrame keystone phase may be PLUGIN-ONLY: it adds NO selftest, the coordinator also
  builds cnr3.dll, and the behavioural proof is the coordinator-side A/B harness — so the count
  legitimately stays unchanged (the R-PROCESS-20 v2.7 clarification). Record it as such.
- PROVEN CODE STAYS PROVEN (R-PROCESS-21): never modify proven behaviour or internals without an
  explicit, approved-in-advance proposal; a passing run after an internals swap is not proof of
  equivalence; reuse that would touch proven code is a design question to raise; withdraw rather
  than patch around. (The K.1D reorientation, section 0.)
- LIFECYCLE/API FROM DOCUMENTATION (R-PROCESS-22): settle VS lifecycle/API contracts from the R76
  header and the CMS, not from "it worked in testing".
- Diagnostics are hard gates; a partial fail is a FAIL. Output to stderr, never stdout. Diagnostics
  are compile-time gated (compute gate + print gate, print subordinate to compute). Observation
  gates observe only; behaviour-changing scaffolds use the BEHAVIOURAL-SCAFFOLD comment tag +
  SCAFFOLD_* macro with an unwind note, NOT DIAG_* names.
- No printing or long-running work inside locked/atomic scopes.
- Minimise unrelated diffs; do not silently paraphrase agreed rules; ASCII-safe code-update text.
- Reference vectors are proven by EXACT integer equality (no tolerance) and, where countable,
  static_assert. Any numeric claim the coordinator can recompute, they will.
- Any override requires explicit discussion, agreement, and documentation.
```
Consult section 3A directly for authoritative text. Document B section 6 and the Role Handover
describe the full working method (read-first patches, the four-way, genuine-failure-mode tests,
count discipline, the --verbose trace, the diagnostics module boundary, and the review checklist).

---
## 11. Your first response in this resume chat

Please respond with:
```text
a) Confirmation that you understand this is a RESUME well past cache-core, pixel, keystone,
   recovery, and P.11C scene-change work. The current committed state is P.11C.5, not K.1D,
   not P.11C-next, and not early cache-core work.

b) The result of confirming the build state from the repository (section 2): latest commit,
   edit-version marker CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof, and the
   four-way selftest results 53/53, 53/53, 52/53 forced-fail, 53/53.

c) Confirmation that the live cache-pressure functions still have no live getFrame callers
   (or a report if the repository has advanced and this is no longer true).

d) Any questions or ambiguities in CMS07.13 or the pack, especially about hot-zone/prune
   live wiring. Do not guess. Raise CMS-GAP / RULE-DEVIATION questions under the charter.

e) An enumerated prevailing-rules list for verification/reconciliation, marking each item
   REGISTER-OWNED (Production Spec §3A) or CMS-DEFINED / HANDED-OFF (CMS07.13).

f) For the LIVE task, respond as TEXT for review — NOT code:
   - your independent Step 0 assessment plan for CMS hot-zone/prune sensibility;
   - the exact CMS sections you need to read before implementation;
   - the live call-site questions to resolve before hot-zone observation and pruning are wired;
   - the proof shape you expect for the first wiring phase.
```
