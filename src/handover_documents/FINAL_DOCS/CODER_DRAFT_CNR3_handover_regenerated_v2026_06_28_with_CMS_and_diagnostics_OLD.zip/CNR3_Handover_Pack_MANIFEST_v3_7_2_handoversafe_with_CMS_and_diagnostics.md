# CNR3 Handover Pack MANIFEST

**Version:** v3.7.2-handoversafe-with-CMS-and-diagnostics  
**Date:** 2026-06-28  
**Purpose:** reading order, presence check, and checksum list for the regenerated handover-safety snapshot after the controlling CMS and diagnostics specifications were supplied.

## 1. Reading order for a memoryless coder chat

```text
1. CNR3_Coder_Restart_Introduction_to_CMS07_RESUME_v6_3.md
2. cnr3_cache_manager_design_v7_13.md  (CONTROLLING CMS; content supplied as uploaded cnr3_cache_manager_design_v7_13.1.md and normalised to the required pack filename)
3. Document_A_CNR3_Project_Context_and_Standing_Rules_v3_7.md
4. Document_B_CNR3_Restart_Work_Plan_and_Current_State_v3_7.md
5. CNR3_Handover_Pack_Production_Spec_v2_13.md
6. CNR3_THIS_CHAT_DELTA_current_state_SLIMMED_v4_13.md
7. CNR3_CMS_Future_Investigations_and_Open_Questions_v7_13.2.md  (non-normative; read only for open questions)
8. CNR3_Diagnostics_Arc_Condensed_Plan_v1_2.txt  (forward plan; not the next coding task)
9. cnr3_diagnostics_specification_v1_5.md  (diagnostics-arc authority for D-SUM framework; needed when diagnostics arc begins)
10. cnr3_memory_diagnostics_spec_v2.md  (memory-diagnostics formatted-output spec; included for diagnostics arc completeness)
```

## 2. Current state

```text
Latest committed marker: CMS07-P.11C.5-scene-cut-checkpoint-recovery-anchor-proof
Selftests: 53/53 PASS; forced-fail 52/53 expected; verbose 53/53 PASS
Next action: Step 0 joint CMS sensibility review for live hot-zone/prune wiring
Do not code hot-zone/prune wiring before the Step 0 review is complete.
```

## 3. CMS filename / front-matter caution

The uploaded CMS file was named `cnr3_cache_manager_design_v7_13.1.md`, while the pack and Production Spec refer to `cnr3_cache_manager_design_v7_13.md`. The file content itself declares **Version: CMS07.13** and states that the P.11C implementation-state note is additive and not a CMS version change. For handover-pack consistency, this zip includes the same CMS content under the required pack filename `cnr3_cache_manager_design_v7_13.md`.

Two non-design front-matter wording issues remain for a future CMS currency cleanup:

```text
- the Status paragraph still contains old restart-era wording: "ready for coder study and the isolated cache-core milestone";
- the companion-document example still says `_v7.10.md` even though this pack pairs the CMS with the v7.13-series companion.
```

These do not change the current handover state because the adjacent implementation-state note and the generated restart documents explicitly state P.11C.5 / 53/53 / live-cache-pressure-wiring-next, but they should be fixed if the CMS is reissued.

## 4. Diagnostics specifications now included

The diagnostics specifications were supplied after the CMS-inclusive zip. They are now included under the canonical filenames expected by the generated pack:

```text
cnr3_diagnostics_specification_v1_5.md
cnr3_memory_diagnostics_spec_v2.md
```

The diagnostics specification declares `CNR3 Diagnostics Specification v1.5`, CMS07.0 restart design epoch, and governs the D-SUM framework. The memory diagnostics file is included as the formatted-output companion referenced by the condensed diagnostics plan, but its front matter still says `Companion document: CMS06`; treat that as legacy front-matter/currency text until the diagnostics arc reconciles it. It is NOT the controlling cache design authority.

## 5. Generated files and SHA-256

| File | SHA-256 |
|---|---|
| `CNR3_Coder_Restart_Introduction_to_CMS07_RESUME_v6_3.md` | `a98fdf3ec7da5ae9b9a9c28b9e0829b5bc38da800b2673b924bd7b4e510b12c8` |
| `cnr3_cache_manager_design_v7_13.md` | `f9e51da4a7b8d0b0d53fdfad1d166ff8ecaa3abd9a017a1b2a242f8ec1662418` |
| `Document_A_CNR3_Project_Context_and_Standing_Rules_v3_7.md` | `d10fa7386ff0a94bdaf263f9be760cc49ba5093a4120c2158c060ee085fb9000` |
| `Document_B_CNR3_Restart_Work_Plan_and_Current_State_v3_7.md` | `4844309283164e39403c0d1e4dabcd8dfb6051ff39daa3fac79c4afef2239b4f` |
| `CNR3_Handover_Pack_Production_Spec_v2_13.md` | `653c5be03cea8867d920080789737b2f482b1838b22d8ce473e355704d8a143a` |
| `CNR3_THIS_CHAT_DELTA_current_state_SLIMMED_v4_13.md` | `b869e404c196c8bcf6654dfe93aa9c399a09cb4d3cccf2a47635a44787362f1d` |
| `CNR3_CMS_Future_Investigations_and_Open_Questions_v7_13.2.md` | `59d34c92edfa71786b200c97dae17069a70756687d0b7bdbb1237ff338c9543b` |
| `CNR3_Diagnostics_Arc_Condensed_Plan_v1_2.txt` | `6524b019c68586d91308ed728ce6f2abec824ab79693d970a0dec6ee52969c03` |
| `cnr3_diagnostics_specification_v1_5.md` | `8d7e4f92c3b4e61dc49d97dc317eff1aaf17f0a09ba11028c1d26a3113ebf24a` |
| `cnr3_memory_diagnostics_spec_v2.md` | `39126ea8967ad97ddc7c7adbe2149d862caa5b7df9fb281fbdcd634a8776260f` |
| `CNR3_Handover_Audit_and_Regeneration_Notes_2026_06_28_with_CMS_and_diagnostics_addendum.md` | `1e5a537f6430c0a6f5c0495f31aafc9a3c7fc8cb477a9378e54a2f90378db02c` |

Manifest file is intentionally not self-hashed in this table because adding the hash would change the file content.

## 6. Still not included in this uploaded/regenerated subset

```text
Role Handover document
Reviewer Introduction document
current code snapshot or repository access
```

The current controlling CMS and the diagnostics specifications are now included. The remaining items above are noted so a restart chat does not mistake this generated subset for the complete durable pack.
