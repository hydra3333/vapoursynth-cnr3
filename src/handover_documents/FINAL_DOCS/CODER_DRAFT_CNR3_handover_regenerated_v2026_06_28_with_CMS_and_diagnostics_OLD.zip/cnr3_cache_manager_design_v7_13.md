# CNR3 Cache Manager Design Specification
**Date:** 2026-06-27 (CMS07.13; supersedes CMS07.12 dated 2026-06-27, which superseded CMS07.11 dated 2026-06-27, which superseded CMS07.10 dated 2026-06-25, which superseded CMS07.9 dated 2026-06-24, which superseded CMS07.8 dated 2026-06-23, which superseded
CMS07.7 dated 2026-06-21, which superseded CMS07.3 dated 2026-06-19, which superseded
CMS07.2 dated 2026-06-17, which superseded CMS07.1 dated 2026-06-17, which superseded
CMS07.0 dated 2026-06-12)
**Version:** CMS07.13
**Status:** Design specification — architectural supersession. COMPLETE: all verify
items V1–V8 resolved (several against authoritative sources: the CNR2 reference code,
the local R76 VapourSynth4.h header); section-level bring-across audit of the
CMS06.11 body done (§9A); final self-review pass done. Controlling design authority
for the CNR3 restart; ready for coder study and the isolated cache-core milestone.
**Implementation-state note (additive; not a CMS version change — no rule, constant, AS-scope, or section is added/changed/removed; CMS remains CMS07.13).** The scene-change design specified in this CMS — §6.3 (promote every detected cut to the checkpoint pool), §6.4 (scene-change frames as checkpoints; a cut-checkpoint is just a present output the §9.5 Phase-1 search finds), §6.5 (cut-near-grid), and detection-during-compute — is now IMPLEMENTED AND PROVEN in the live build via the P.11C arc (CMS07-P.11C.1 through .5, committed; selftests 53/53 both configs). Scene detection runs uniformly across the predecessor-present (.3) and recovery hole+target (.4) live branches, and a scene-cut-created checkpoint is proven to survive prune by checkpoint class and serve as a later recovery anchor (.5), exactly as §6.3/§6.4 specify. This note records implementation status only; the design text is unchanged. NEXT (not a CMS change): wiring the §5 hot-zone observation and §6.3 prune into the live getFrame path — the logic is built and selftest-proven but not yet live-wired; the live prune-trigger contract is pending a designer+coder review (single-activation wiring first; concurrent prune is part of the fmParallel arc).

CMS07.13 is a CLARIFICATION over CMS07.12: it makes the materialized-floor-is-the-foundation invariant explicit in §9.5 (floor fallback) — proven live by D.3 — and records that floor-fresh-start supersedes the D.2-era no-in-window-anchor refusal for reachable N. It adds no rule/AS-scope and changes no behaviour (D.3 already ships this). CMS07.12 is a CLARIFICATION over CMS07.11: it makes the bounded-search REPORT semantics explicit in §9.5 Phase 1 (the search reports only within [max(0,N-B), N-1]; no-in-window-anchor does not distinguish out-of-window-anchor from no-prior-output) and corrects the bounded-anchor-search interval upper bound to N-1; it adds no new rule/AS-scope and changes no behaviour (D.2 already ships this). CMS07.11 was a GOVERNANCE addition over CMS07.10: it added §0A (the Design Alignment and Escalation
Charter) and changed NO design rule, decision, constant, AS scope, or section number. CMS07.10 was a
CORRECTION over CMS07.9: it corrected §9A.1.1 for the K.1F-proven
R-LIFECYCLE triggering-request rule. A dependency-filter cache-hit activation must not
rely on zero-request arInitial->NULL (not guaranteed an arAllFramesReady callback under
API4/R76); every CNR3 branch requests at least one real source frame at arInitial and
returns only at arAllFramesReady. Branch-(b) cache-hit uses source[N] as a lifecycle
trigger, pins cached output[N] across the activation gap, retrieves/frees the trigger
source (not consumed), and returns the cached output via lookup-and-add-ref plus AS4
batch discharge. This correction does not change the CMS07.9 recovery model, AS scopes,
constants, or branch-(d) plan.
CMS07.9 is an ADDITIVE revision over CMS07.8, made to bring an fmParallel/two-instance
consequence forward into normative text rather than discover it at the parallel phase
(the standing mandate is to build toward the fmParallel + two-instance-interlaced end
goal; §2, §8.6). It (1) makes the per-hole **pre-compute adopt-and-skip** check
NORMATIVE in §9.2 (and consolidates it as §9.6.5): before computing a recovery hole,
check-present-and-pin-and-skip if a concurrent activation already filled it during the
arInitial→arAllFramesReady gap — correctness was already guaranteed by the post-compute
first-in-best-dressed path (§9.3), this adds the efficiency path that avoids redundant
full-frame recompute under fmParallel; (2) clarifies §9.6.2 and the §8.7 AS3 STATUS NOTE
so the DEFERRED sparse-plan PLANNER extension is not conflated with the now-NORMATIVE
act-time gap-fill PRIMITIVE; (3) makes the §9.1 AS1 start-point-pin fmParallel rationale
explicit (the pin is what keeps the plan's foundation safe from a concurrent prune during
the gap); and (4) records in the §8.7 AS4 entry the ruled single-lock batch-discharge
resolution (owed as recovery-step-0). No design rule, decision, constant, or section
number is removed; §9.6.5 is the only new subsection (see §14 changelog).
CMS07.8 is a further ADDITIVE revision over CMS07.7: it adds §9.7.7 (the source-input
dependency declaration `rpGeneral`, resolving companion investigation FI-04) and §9A.1.1
(the arInitial / arAllFramesReady frame-return contract, a hard-API sibling to
VS-LIFECYCLE-01); no design rule, decision, constant, or section number is changed or
removed (see §14 changelog). CMS07.7 is an ADDITIVE consolidation over CMS07.3: it adds
§9.7 (the keystone predecessor-sourcing decision, collecting existing rules from §4.8,
§6.3-§6.6, §9.1-§9.3, §9.5-§9.5.1, §9.6, and §9A.7 into one place from the keystone-writer's
view); no design rule, decision, constant, or section number is changed or removed.
CMS07.3 was an ADDITIVE clarification over CMS07.2: it added §9.6 (current minimal
recovery path, AS3 deferral, the two state categories, and the developer-alert
principle) and a STATUS NOTE on the AS3 register entry in §8.7.
CMS07.2 added the companion-document front-matter note. CMS07.1 itself added §6.6
(checkpoint flag is monotonic under duplicate stores) and a §9.3 cross-reference over
CMS07.0.
**Supersedes:** CMS07.0-and-later supersedes CMS06.11 and ALL earlier CMS06.x / CMS0x cache
designs. This is an architectural supersession, not a refinement: the pinning model
and the hot-zone model both change fundamentally. Earlier documents are reference
material only.
**Companion document (non-normative).** This CMS has a companion working document,
`CNR3_CMS_Future_Investigations_and_Open_Questions_vXX.Y.md`, which always carries the
**same version number as this CMS** (XX.Y = this CMS version; for this version,
`_v7.10.md`). It records deferred design questions and open tuning investigations. It is
**NOT part of this specification, NOT controlling, and NOT part of the coder handover
pack**; nothing in it is implemented without formal prior approval and a corresponding
CMS revision. It exists only so that open questions are not lost between sessions. Refer
to it if you need that context; otherwise this CMS and the Production Spec §3A process
rules remain the authorities.
---
## 0. How to read this document (and what changed)
CMS07.0-and-later replaces the previous cache architecture. The two headline changes:
1. **Pinning is now the mandatory correctness mechanism.** In the old design
   (CMS06.11 and earlier), actively-needed frames were kept findable by a
   combination of held references plus hot-zone heuristics, and non-checkpoint
   pinning was a *deferred emergency escalation*. That is superseded. In CMS07.0,
   any frame a request actively needs is **pinned** by that request (a
   consumer-held pin), and the cache is the **complete liveness index** for the
   active set.
2. **Hot zones are demoted to prune-policy hints.** They no longer guarantee
   findability of active frames (pins do that). They protect the *anticipatory /
   decaying* set — frames likely-to-be-needed-soon or recently-needed-but-not-yet-
   cold — which pins structurally cannot protect (a pin needs a present consumer).
**You must not conflate the old and new concepts.** The three highest-risk traps:
- treating pinning as optional/deferred — it is now baseline;
- reintroducing held-ref-only predecessor reservation — superseded by consumer-pins;
- thinking of a checkpoint as a kind of pin — a checkpoint is a separate
  eviction-protection FLAG with its own retention rule; there is exactly ONE pin
  concept (consumer-claim).
**Design vs code:** CMS07.0-and-later is a design supersession. The existing CODE is at the
prior (CMS06.11 / sequential-fast-path-through-H15.5) state. Development restarts
against this spec; old source is reference material for verifiable salvage only.
**Versioning** where the text mentions CMS07.0, it should be read as referring to
the currently prevailing version of the CMS which may be later than 7.0 (eg  CMS07.1).
---
## 0A. Design Alignment and Escalation Charter (governance — how the CMS is used)
This charter governs HOW the designer/reviewer, coder, and coordinator use this CMS. It is governance,
not a design rule: it adds, changes, and removes nothing in §1–§15. It is reproduced identically in the
Production Spec §3A.5.0 and the Role Handover §D0; on any wording drift, those and this must be
reconciled to one agreed text. The CMS is the controlling DESIGN authority; this charter says when
strict alignment yields to a surfaced issue.

```text
(Three-way working charter: designer/reviewer, coder, coordinator. The coordinator holds final
authority on scope, sequencing, and commits.)

1. CMS is the controlling guide; strict alignment is the default. Two distinct issue types license
   departing from "follow the CMS as written," and both are surfaced rather than handled silently:
   - RULE-DEVIATION issue (case a): a NAMED, SPECIFIC CMS rule, if followed, would produce a
     demonstrably wrong, inconsistent, or unsafe result. This bar is HIGH: comparable to the
     evidence that produced the CMS07.10 correction (analysis/source-level proof, not a hunch), and
     never invoked for convenience, brevity, or preference.
   - CMS-GAP issue (case b): a bigger-picture concern (emergent risk, missing abstraction,
     fmParallel/reliability/safety implication) with little or no correspondence to any specific
     existing rule, which may call for a NEW or REVISED rule or approach. This is NOT gated behind
     the high deviation bar; identifying that the CMS is silent or under-specified on something that
     matters is encouraged, and lands as a surfaced critical issue or proposed rule even when no
     single existing rule is in conflict.
   - Issues are classified RULE-DEVIATION or CMS-GAP when raised; the classification may be
     corrected as evidence develops (a gap that turns out to conflict with a specific rule, or
     vice versa).

2. On either issue type: stop and raise -- never route around silently. Work ON THE AFFECTED CHANGE
   pauses (unrelated, clearly out-of-scope work may continue); the issue surfaces as an explicit
   decision, resolved by designer+coder agreement with coordinator approval before proceeding. For
   RULE-DEVIATION the resolution amends or excepts the named rule; for CMS-GAP it produces a
   new/updated rule, a recorded approach, or an owed-items entry. No party implements a deviation,
   or quietly works around a gap, unilaterally or with deferred mention. Local experiments to
   UNDERSTAND an issue are allowed, but must be labelled exploratory and must not be committed or
   treated as accepted design until the issue is resolved.

3. Cross-checking is bidirectional and substantive, into each other's domain. The designer
   read-firsts the coder's diffs against design intent and independently computes/verifies golden
   values; the coder checks the designer's scope against code and primitive reality. Each verifies
   the other's home turf rather than deferring to it. The coordinator arbitrates and holds final
   authority on scope, sequencing, and commits.

4. Weight scales to risk. Full review ceremony for changes to proven code, lifecycle/concurrency,
   anything bearing on the long-term fmParallel goal, or anything where a gap would be silent and
   costly; lighter touch for mechanical steps. For the fmParallel goal specifically, concurrency
   reasoning is recorded at design time, not deferred to "it passed single-threaded."

5. Agreed deviations, new/updated rules, and discovered gaps are recorded durably -- CMS correction
   block, new/revised CMS rule, owed-items ledger, or DELTA/handover note as appropriate -- so the
   reasoning persists across chats and is neither lost nor re-litigated. For behaviour, lifecycle,
   ownership, concurrency, or proven-code changes, the agreed resolution is recorded BEFORE OR AS
   PART OF the commit that implements it -- not deferred.
```

Note on this charter's own status: it is a CMS-GAP-class addition (governance the CMS previously left
implicit), agreed designer+coder+coordinator 2026-06-27, recorded here so the design authority itself
carries the escalation model rather than relying on it living only in the handover docs.

---
## 1. Project context (orientation — adapted from handover Document A §A2/§A3/§A4)
CNR3 is a VapourSynth **API4-only**, **integer-YUV-only** recursive temporal chroma
stabiliser, inspired by the CNR2/vscnr2 algorithm, intended for analogue / video-
capture material (chroma shimmer, temporal chroma noise). The final operational
target is **fmParallel** (Section 2).
**The load-bearing fact:** `output[N]` depends on `source[N]` and on the
*already-filtered* `output[N-1]` — not on `source[N-1]`. This recursion is why a
naive stateless filter cannot work.
**Algorithmic core (§A4 — V1 RESOLVED: confirmed causal by Dave against CNR2):**
- For luma Y: copy source luma unchanged.
- For chroma U/V: compare current source chroma vs previous *filtered* chroma, and
  current downsampled luma vs previous downsampled luma; use signed-difference
  response tables; blend
  `output_chroma[N] = blend(output_chroma[N-1], source_chroma[N])` by the combined
  response.
- **Scene-change (cut) detection** runs *during compute* as part of comparing frame
  N to its predecessor. On a true cut at N, output[N] is computed as a **fresh start**
  (copy source chroma, skip the recursive blend), so output[N] does NOT depend on
  output[N-1]. A cut therefore SEVERS the recursive chain at N. (This is a third
  reset point alongside frame 0 and the lower-bound floor; see Section 9.5/9.6.)
- The algorithm is **purely causal**: computing output N uses only the current
  source (N) and the previous filtered output (N-1). There is NO forward-source peek
  / look-ahead / bilateral reach. The source reach to compute N is therefore
  **backward-only**. (V1 confirmed against CNR2 itself; corroborated by §A4, by the
  proven request window in CMS06.11, and by the absence of any forward reference.)
**Why the cache exists (correctness, not performance):** a modern VapourSynth graph
may request output frames out of display order (e.g. 0, 3, 1, 2, 4). To compute
output 3 the filter needs filtered output 2, which may not yet exist. The cache
retains computed outputs so the recursion can find predecessors (or recover them)
rather than rebuilding the chain from frame 0 on every request. **The cache is a
correctness subsystem.** (The reference CNR2 — https://github.com/Asd-g/AviSynth-vsCnr2
— runs serialized and approximates a missing predecessor with the previous *source*
frame; CNR3 abandons serialization for fmParallel and replaces that approximation with
exact output recovery. See §12B for this root rationale and §13 V8.1 for pixel-layer
salvage guidance.)
---
## 2. Operational goal and the fmParallel invariant (stated outright — from §A8)
```text
safe under fmUnordered now
structurally compatible with fmParallelRequests
final design target: fmParallel
```
**Invariant (top-level, binding):** fmParallel is the final operational target.
Interim development may pass through fmUnordered and fmParallelRequests, but design
and coding MUST NOT make choices that block eventual safe fmParallel operation
unless explicitly justified and recorded. This invariant is the justification for
adopting Position B (Section 3) over the simpler held-ref-only model.
`old_strict_cache.next_needed` and `old_strict_cache.prev_output` are NOT final
fmParallel output authority and must be retired/bypassed/redesigned before final
authority (carried forward from decisions D26/D33). The restart is the occasion to
retire the old strict-streaming bridge.
---
## 3. Foundational model — the cache holds references, Position B mandatory
**3.1 The cache holds references, not pixels.** A cache slot holds an
`addFrameRef` reference to a VapourSynth-core-owned `VSFrame`; it does not own
pixel memory. The core reclaims a frame when its atomic reference count reaches
zero. `addFrameRef`/`freeFrame` are declared in the R76 header (VapourSynth4.h lines
377–378). The core's *internal frame refcount* is atomic (V5) — but see the V5
firewall in Section 8.6: that internal atomicity does NOT license shrinking any
designer-mandated cache-lock scope.
**3.2 Two leak surfaces — WE manage allocation and cleanup (no coder discretion).**
Confirmed against the actual R76 header (VapourSynth4.h):
- (a) The per-request `frameData` struct — `VSFilterGetFrame(..., void **frameData,
  ...)` (line 337). It defaults to NULL and is **ours to allocate and free**; the API
  contract requires it be deallocated before the last call for the frame
  (arAllFramesReady or error), and `setFilterError` (line 409) marks the error path.
  The core carries the *pointer* between activations but never owns the struct. The
  API SANCTIONS and REQUIRES manual management — there is no core cleanup hook for it.
  Therefore CMS07.0 mandates our specified allocate-in-arInitial / free-before-last-
  call / free-on-error discipline; the coder IMPLEMENTS it and has NO discretion to
  change whether or how we manage it (V4 RESOLVED).
- (b) `VSFrame` references — core-owned memory; our obligation is ref discipline
  (`freeFrame` every ref we take), never deallocation.
- **Destruction ordering (mandatory):** on `frameData` destruction, first discharge
  every ref the struct tracks (walk the pin-list; unpin / `freeFrame`), THEN free
  the struct. Freeing the struct first loses the owed-ref list → leak.
- **Concurrency guarantee (from the header, strengthens our design):** `getFrame` is
  never called concurrently for the same frame number; for fmParallel-class modes it
  may be called by multiple threads with arInitial but only one thread calls
  arAllFramesReady at a time. Therefore a request's per-invocation `frameData`
  (and its pin-list) is never touched by two threads for the same N — the pin-list's
  "private per request, contention-free" property (Section 4.3) is GUARANTEED by the
  API, not merely our convention.
- **Note — we deliberately do NOT use the core's `cacheFrame`/`setLinearFilter` API
  (VapourSynth4.h lines 362, 408).** That is an opaque core convenience cache for
  linear filters; it offers no consumer-pins, no checkpoint/zone control, and
  constrains the access model via `setLinearFilter`. It cannot provide the
  complete-liveness-index correctness guarantee our recursion requires. Our own cache
  manager is therefore necessary, not a reinvention. (Recorded so the choice is
  explicit, not an apparent oversight.)
**3.3 Position B — mandatory architecture.** Slot and frame operate as a managed
unit; the cache is the complete liveness index for the active set. A frame that is
alive-but-unfindable is, for the cache's purpose, equivalent to one that does not
exist (recompute either way) — so completeness of the index IS searchability for
our goals.
- **Position A (held-ref-only)** is the proven correctness floor and may be used
  ONLY in a specific, named circumstance where B is demonstrated unnecessary or
  unworkable, and ONLY by explicit per-case agreement, documented. The default is
  B; A is the documented exception, never a silent fallback. A B/A mix is rejected.
- **Justification:** (i) goal-driven — under fmParallel, predecessors are the most-
  shared frames, so alive-but-unfindable becomes a frequent recompute tax; (ii)
  conjectural on the performance margin (unmeasurable until testing — instrument and
  confirm); (iii) KISS / maintainability — B is ONE mental model (cache = liveness
  truth; slot+frame are one unit), whereas A forces every contributor to carry the
  decoupling forever, a comprehension tax that erodes and reintroduces bugs. B holds
  even if the performance margin proves small.
- **This supersedes decision D13** ("non-checkpoint pinning deferred"). See §12.
**3.4 Direction of causation.** The output side drives: downstream requests output
N; the filter then requests the source frame(s) it needs. Demand flows
output → filter → source. The input clip is passive. VS-LIFECYCLE-01 (only retrieve
in arAllFramesReady what was requested in arInitial) is a contract with the engine's
source handling. The filter NEVER requests its own output frames from VapourSynth —
outputs exist only when computed; the cache is their sole retainer.
**3.5 Per-instance, per-invocation (D03/D16).** The cache is per filter instance,
never global. Per-request planning/ownership state (source plan, pin-list) is
carried in per-invocation `frameData`, never in shared `Cnr3Data` state.
---
## 4. Pinning scheme (the correctness mechanism)
**4.1 Consumer-pins principle.** A pin represents a consumer's active, in-flight
need. The consumer takes the pin; the consumer releases it. **Production never
pins** (producing output N is not consuming it; nobody consumes N yet — its future
consumer N+1 will pin it when it arrives). No pin without a present consumer. Pin
ownership is unambiguous and self-balancing per request: the thread that pinned
unpins, within its own arInitial → arAllFramesReady lifetime.
**4.2 No pre-anticipation pinning.** A speculative pin by a producer on behalf of a
future, possibly-never-arriving consumer creates ambiguous ownership. Rejected. The
anticipatory case is the hot zone's job (Section 5), not a pin's.
**4.3 Pin-and-record inside the atomic.** Every pin taken is appended to the
request's private per-invocation `frameData` pin-list, INSIDE the same atomic as the
pin (pin and record are indivisible). The pin-list is private per request → no
cross-thread contention on it.
**4.4 Single-ownership / null-on-consume.** A reserved/owned ref or pin entry is
owned by `frameData` until consumed:
- successful consumption releases (or transfers) the ref exactly once, then sets the
  field/entry to nullptr/consumed;
- cleanup releases an entry only if it is still non-null;
- the null field is the idempotency guard; exactly one of {consume, cleanup}
  releases any given entry;
- consume and cleanup attribute counters correctly (cleanup increments the cleanup
  counter; consume increments the consume counter — never both for one entry).
**4.5 Final unpin.** At end of arAllFramesReady, unpin the entire recorded pin-list
in ONE short atomic (count decrements, marshalled inside the lock). Hold-to-end,
uniform, once. Mid-walk unpinning is a known-available future optimisation,
deliberately NOT used (avoids variable intra-request pin lifetimes).
**4.6 Leak-safety.** `frameData` cleanup/destructor must unpin any pins still on the
list on EVERY exit path including errors. Makes leaked pins structurally hard.
**4.7 One pin concept.** "Pin" = consumer-claim only. There is no "policy-pin." (See
Section 6 for checkpoints, which are a separate flag, not a pin.)
**4.8 Ownership accounting (carried forward from D05/D06/D55).** Pin/owned refs
participate in the existing lookup-ref accounting:
`lookup_owned_ref_acquired_total == released_total + transferred_total`. A consumed
predecessor/intermediate is an INPUT → **released, not transferred**; only the
returned output frame N is transferred to VapourSynth.
---
## 5. Hot-zone scheme — decay-hints over the pinned liveness floor
**5.1 Role (demoted from the old design).** Hot zones do NOT guarantee findability
of active frames — pins do. Zones protect the **anticipatory / decaying** set:
frames no current request has claimed but which are likely-needed-soon (the
store→next-claim handoff) or recently-needed-but-not-yet-cold (the dwindling-zone
graceful-decay window). This is orthogonal to pinning, not a substitute for it.
**5.2 B de-risks the zone scheme.** Because pins guarantee the active set
independently, the zone's failures (premature prune, merge churn, zone-limit churn)
cost EFFICIENCY (a recompute), never CORRECTNESS. The old scheme's soft spots become
harmless inefficiencies.
**5.3 Zone definition.** A zone is a `[low, high]` window tracking where recent
activity has been, carrying `last_observed_frame`. Frames inside a live zone are
prune-DEFERRED (a preference); frames outside all zones are prune-ELIGIBLE.
**5.4 Slide / spawn / merge (machinery carried forward from D08, revalidated).**
- Slide rule: for an arriving frame F, find the nearest active zone within
  `JUMP_THRESHOLD`; if found, slide it so `low = max(0, F - BACK_RADIUS)`,
  `high = F + FORWARD_RADIUS`, update `last_observed_frame`. Else it is a jump →
  allocate a new zone (or, if no free slot and none retire-eligible, merge the two
  closest zones conservatively: `min(lows), max(highs)`).
- Sliding is safe because correctness rests on pins, not on the zone covering the
  predecessor.
**5.5 Decay sequence (makes dwindling-zone pruning safe; prune after criteria):**
active (pins in range OR recently observed) → dwindling (no new observation, pins
clearing) → retire-eligible (NO pins in range AND `decay_margin` frames elapsed
since `last_observed_frame`) → retired (anticipatory protection withdrawn) → frames
prune-eligible → pruned by capacity pressure, furthest-from-zone first. Safe at every
step because pins underwrite correctness.
**5.6 Retirement test is EXACT and cheap.** "No pins in range" is answerable in the
same locked prune pass from the pin-count state already maintained — NO parallel
`active_request_count` counter needed. Checkpoints do NOT keep a zone alive (they
have their own separate retention rule). This eliminates the old conservative
"no pinned checkpoint" proxy and its merge-ratchet tendency.
**5.7 Hot-zone update at arInitial (carried forward from D15).** Zone activity is
registered at arInitial, not deferred to arAllFramesReady — required for safety once
multiple requests are in flight.
---
## 6. Checkpoints — a flag with its own retention rule (NOT a pin)
**6.1 A checkpoint is a FLAG, eviction-protected by a separate retention rule.** A
checkpoint with no active consumer is NOT pinned. The three independent eviction
protections, each meaning one thing: `pin_count > 0` (active consumer need),
checkpoint flag (recovery-anchor retention), hot-zone membership (anticipated need).
Only the first is a pin.
**6.2 Hard floors apply to both ordinary and checkpoint frames.** A pinned frame is
NEVER evicted; a hot-zone frame is spared. Checkpoint-ness never overrides a pin; a
pin never overrides checkpoint protection. ANDed.
**6.3 Establishment and retention (DISTINCT rules; V2/V3 confirmed):**
- Establishment: promote every `CHECKPOINT_INTERVAL`-th frame (and frame 0) to the
  checkpoint pool — the regular grid. **In addition, promote every detected
  scene-change (cut) frame to the checkpoint pool** (Section 6.4). The grid promotion
  is RETAINED alongside cut promotion (regular anchors for long static scenes + exact
  anchors at cuts).
- **Supplementary rule — checkpoints may be IRREGULARLY spaced** because of scene-cut
  promotion. This is safe: the checkpoint search is position-agnostic (it finds the
  greatest checkpoint frame ≤ the search bound via the ordered frame-number map, D04),
  making no assumption of regular spacing. The only place INTERVAL appears beyond
  establishment is the capacity sizing estimate (CR5), which becomes a density FLOOR,
  not a ceiling (cuts add density on top of the grid).
- Retention: count-based soft trigger — checkpoint prune RUNS when the pool exceeds
  `CHECKPOINT_MAX_RETAIN`, prunes toward `CHECKPOINT_MIN_RETAIN`. A checkpoint is a
  prune candidate iff frame ≠ 0 AND `pin_count == 0` AND outside every hot zone.
  Evict greatest-hot-zone-distance first. Retain limits are SOFT triggers (a
  hot-zone or pinned checkpoint is retained past MAX_RETAIN). Frame 0 never pruned.
- "Kept longer but bounded": pool lives between MIN_RETAIN and MAX_RETAIN; does not
  grow with clip length.
- Under fmParallel scatter, count-trigger + hot-zone-distance ordering (not a
  distance-from-a-single-front metric, which is ill-defined under scatter).
**6.4 Scene-change frames as checkpoints.** A cut detected during compute (Section
9.2) makes output[K] a fresh-start, dependency-free reset — the IDEAL recovery anchor
(exact, not approximate, and nothing before it is needed). Therefore output[K] is
stored with the checkpoint flag set. No special search or recovery handling is needed:
a cut-checkpoint is just a present output the Phase-1 descending search (9.5) finds
like any other, and its longer retention makes it more likely to survive in a cold
region. Cuts-as-checkpoints absorbs the previously-considered "remember cut positions"
optimisation. **Sizing caveat:** checkpoint density is now "grid + cuts," so in
cut-heavy content the pool runs nearer MAX_RETAIN; the soft-trigger retention sheds the
unprotected (cold, out-of-zone) cut-checkpoints first, which are exactly the ones safe
to drop. A cut-checkpoint inside a hot zone or pinned is retained regardless (it should
never be evicted while protected — instrument for that as an invariant).
**6.5 Cut-near-grid checkpoints — accept slight waste (V2/V3 decision).** When a cut
lands close to a grid checkpoint (e.g. cut at 47, grid at 50), both are kept — two
near-duplicate anchors. This is ACCEPTED as harmless: retention prunes the cold one;
the cost is minor pool churn. NO suppression logic and NO new "minimum spacing"
threshold (rejected as over-engineering for a marginal saving). V2/V3 confirmed:
CHECKPOINT_INTERVAL=10, MIN_RETAIN=10, MAX_RETAIN=48 are intended for the new
architecture.
**6.6 Checkpoint flag is monotonic under duplicate stores (CMS07.1 clarification —
first-in-best-dressed interaction).** First-in-best-dressed (§9.3) governs the frame
*data*: the first stored output for a frame number wins, and its pixel content is
NEVER overwritten by a later duplicate store. The checkpoint *flag* is a SEPARATE
property and is **monotonic** under duplicate stores — it may be RAISED but never
CLEARED by a duplicate:
- **Promote (raise allowed):** a later store that is checkpoint-eligible (a grid frame
  per §6.3, or a detected-cut frame per §6.4) arriving for a frame already cached as
  non-checkpoint PROMOTES the existing slot — set `is_checkpoint` and add it to the
  checkpoint pool/index. The cached frame *data* is unchanged (first-in-best-dressed);
  only the flag is upgraded. The flag-set occurs INSIDE the same store atomic (AS2,
  §8.7) as the duplicate-store handling — never as a separate lock acquisition.
- **Never demote:** a non-checkpoint duplicate store arriving for a frame already
  cached as a checkpoint NEVER clears the flag or removes it from the checkpoint pool;
  the checkpoint flag and its retention are retained.
- **Rationale.** §6.3 requires *every* detected cut frame to become a checkpoint, but
  out-of-order scheduling can cache a frame as an ordinary (non-checkpoint) output
  *before* the activation that recomputes it and detects its cut. Without promotion,
  such a cut frame would never acquire its anchor retention — silently defeating the
  cuts-as-checkpoints mechanism (§9.5) for exactly the frames it was designed to keep.
  Promotion is **correctness-neutral**: the Phase-1 descending search treats the
  checkpoint flag as retention-only ("checkpoint flag IRRELEVANT here: the first
  present frame wins", §9.5), so a missing flag can only cause earlier eviction (more
  recomputation), never wrong output — and promotion simply restores the intended
  longer retention. Demotion is never wanted because losing a flag can only shorten an
  anchor's life. Hence raise-only.
- **Scope.** This rule concerns only the checkpoint *flag* under a duplicate store for
  an already-present frame number. It does not change first-in-best-dressed for frame
  data (§9.3), the establishment grid or cut-promotion rules (§6.3/§6.4), the
  retention/prune rules (§6.3), or any AS scope (§8.7) beyond confirming the flag-set
  is folded into the existing AS2 store atomic.
---
## 7. Eviction predicate and bounded prune
**7.1 Composite eviction predicate (read atomically under the single lock):**
```text
evict(slot) iff
    slot.pin_count == 0
    AND slot.frame_number is outside every live hot zone [low, high]
    AND ( slot.is_checkpoint
            ? checkpoint-retention-permits (Section 6.3)
            : capacity-permits (Section 7.2) )
ordering: evict greatest-distance-from-any-hot-zone-boundary first.
```
Zone retirement (5.5/5.6) flips a zone inactive so its range stops contributing to
"outside every live hot zone."
**7.2 Capacity trigger (carried forward from D10/D11, self-debouncing).**
Non-checkpoint prune fires when the pool strictly exceeds
`active_ceiling × OVERFLOW_FACTOR`; prunes back toward `active_ceiling`. The
capacity→overflow gap IS the hysteresis (won't re-fire until the pool climbs back
over threshold). No percentage marks, no periodic timers. Store prunes before
hard-ceiling rejection (D11).
**7.3 Bounded prune — three acts (composes the decide/detach/free separation).**
- (a) DECIDE: under the lock, evaluate the eviction predicate, select up to **K**
  victims (greatest-distance-first).
- (b) DETACH: under the SAME lock, detach each selected slot from the cache index
  via the single central remove helper (D09), collecting its `VSFrame*` ref into a
  local list. (a)+(b) are one critical section — a pin cannot creep in between select
  and detach (the slot leaves the index the moment selected; a pinned frame is never
  selected).
- (c) FREE: release the lock; then `freeFrame` the collected refs in one post-lock
  BATCH (freeFrame may trigger core deallocation — kept outside the lock).
- **K** caps the lock-hold for BURST prunes (post-seek, cold-start); rarely binds in
  steady trickle. Instrumentation: count "prune stopped at K with pool still over
  threshold"; raise K if it fires regularly.
---
## 8. Locking — one cache-wide lock, held minimally
**8.1 Decision.** A single mutex guards all cache state (slot index, both pools,
zones, checkpoint flags, pin-counts). Correct-by-construction; the single consistent
snapshot that region-scoped search-and-pin and the composite eviction predicate both
require is FREE under one lock; no lock-ordering, no deadlock; one mental model.
**8.2 Discipline.** Do ALL the right in-memory cache operations inside the lock and
no more — without being stingy. Slow work goes OUTSIDE the lock.
- INSIDE (indivisible commits): search; pin; hole-catalogue; store; pin-record;
  final unpin; eviction-predicate read; prune decide+detach.
- OUTSIDE (never serialises threads through the cache mutex): pixel computation;
  VapourSynth source requests; `freeFrame` of evicted/duplicate refs.
**8.3 Combined principle:** pin-and-record the plan INSIDE the lock; execute the slow
parts OUTSIDE it. The inside-lock pinning is what makes outside-lock execution safe.
**8.4 Fine-grained / cross-region locks: REJECTED as baseline.** They reintroduce
the "separated things humans fail at" problem at the locking layer, threaten the
snapshot property the pin scheme depends on, and add deadlock risk. Deferred to a
MEASURED optimisation applied only if instrumentation proves the single lock is the
actual bottleneck. Fine-graining attacks a load-bearing assumption → requires strong
evidence.
**8.5 Mutex-scoping audit (coder task).** Enumerate every cache operation that
checks-then-acts and confirm none drops the lock between check and act:
search-identify-and-pin; store-on-compute-complete (+ first-in-best-dressed); bounded
prune (decide+detach / free); hot-zone slide; zone retirement; checkpoint establish;
final unpin. PLUS a broad open ask: identify any scenario not enumerated here where
cache state is checked-then-acted across a lock boundary, given this caching goal.
**8.6 V5 firewall — core refcount atomicity does NOT shrink any cache-lock scope.**
There are two unrelated "atomicity" concepts; they must never be conflated:
1. The core's *internal frame reference count* is updated atomically (V5). This
   protects a SINGLE refcount operation (`addFrameRef` / `freeFrame`).
2. The designer-mandated *cache-lock critical sections* (Section 8.7) protect
   MULTI-STEP cache-state decisions (e.g. find-then-pin, decide-then-detach).
These are different layers. The core's atomic refcount does **NOT** make any
cache-lock scope optional, smaller, or splittable. In particular: the fact that a
pin's `addFrameRef` is internally atomic gives NO licence to take that pin OUTSIDE
the cache lock — because the protected operation is the *find-and-pin sequence*, not
the bare refcount bump. Taking the refcount bump alone, outside the lock, would
reintroduce exactly the TOCTOU gaps this architecture eliminates (another thread can
prune the slot between the find and the bump). **The atomic-scope register (8.7) is
the authority on critical-section boundaries; V5 confirms only the refcount's own
atomicity and confers nothing over those boundaries.**
**8.7 Atomic-scope register — DESIGNER-OWNED, MANDATORY, boundaries inviolable.**
Each entry is one indivisible cache-lock critical section. The coder IMPLEMENTS these
exactly; the coder may NOT shrink, split, merge, or reorder the contents of a scope
without explicit designer agreement. All slow work (pixel compute, VS source
requests, the batch `freeFrame`) is OUTSIDE these scopes by mandate.
```text
AS1  arInitial plan-and-pin (Section 9.1):
       { Phase-1 descending bounded search [max(0,N-B), N];
         pin the start point and every present reused frame;
         catalogue the output holes;
         append every pin to frameData pin-list;
         update/slide hot zone(s) for N }
       — one lock acquisition, indivisible.
AS2  arAllFramesReady per-hole store-and-pin (Section 9.2), repeated per hole:
       { first-in-best-dressed check;
         store computed output (or adopt existing winner);
         pin it; append to pin-list }
       — one lock acquisition PER hole; compute happens OUTSIDE before this.
AS3  reused-frame pin during ascending fill (Section 9.2/9.5), as encountered:
       { confirm output[K] present; addFrameRef under lock; append to pin-list }
       — find-and-pin is one indivisible unit (the find-and-add-ref primitive, D06).
       STATUS NOTE (see §9.6, updated CMS07.9): two things must be kept distinct. The
       PLANNER extension to sparse reused-intermediate frames remains DEFERRED (no such
       plan shape is emitted by the current contiguous-hole planner; it awaits a future
       approved sparse-plan revision; do not implement it against an unreachable synthetic
       plan shape). But the AS3 find-and-pin PRIMITIVE applied at fill act-time — the
       pre-compute check-present-and-pin-and-skip of §9.2/§9.6.5 — is NORMATIVE under
       fmParallel as of CMS07.9: a hole correctly catalogued as absent at AS1 plan time may
       be present by act time under concurrency (§9.6.3 Category A), and is then adopted-
       and-pinned with the compute skipped. This is the act-time gap-fill case, NOT the
       deferred planner extension.
AS4  final unpin (Section 4.5):
       { for every entry on the pin-list: unpin (decrement) }
       — one lock acquisition for the whole list at end of arAllFramesReady.
       IMPLEMENTATION NOTE (CMS07.9): this whole-list single-lock requirement is
       authoritative. The committed `Cnr3CachePinList::discharge_all` currently takes one
       lock PER token (it calls the per-token `unpin_frame`, which locks each time) — a
       wording-vs-code discrepancy that is correctness-safe at single-pin and while no
       slot under discharge can vanish mid-walk (INV-B2: pinned slots are never pruned),
       but does NOT match this register entry once multi-pin discharge (anchor + holes)
       appears in branch-(d) recovery. RESOLUTION (ruled, owed as recovery-step-0): add a
       single-lock batch discharge — acquire `cache_mutex_` once, unpin every token via the
       existing `unpin_frame_locked`, reset the list — so AS4 is one lock for the whole
       list as specified. The freeFrame for any frame is NEVER inside this scope (discharge
       only decrements pin_count); leak-safety on every exit path (§4.6) is preserved.
AS5  bounded prune decide+detach (Section 7.3 a+b):
       { evaluate composite eviction predicate;
         select up to K victims (greatest-distance-first);
         detach each victim slot from the index (central remove helper, D09);
         collect freed VSFrame* refs into a local list }
       — one lock acquisition; the batch freeFrame (c) is OUTSIDE this scope.
AS6  checkpoint establish (Sections 6.3/6.4):
       { on store of a grid frame or a detected-cut frame, set is_checkpoint;
         insert into checkpoint pool / ordered index }
       — folded into the relevant AS2 store scope (same lock), not a separate lock.
AS7  zone retirement / merge (Sections 5.5/5.6):
       { test no-pins-in-range + decay-margin; mark zone inactive / merge }
       — performed under the same lock during AS1 or the prune pass; never split.
```
The register is the single authority on critical-section boundaries. If an operation
needed in practice is not covered here, it is raised to the designer — NOT improvised
with an ad-hoc smaller lock.
---
## 9. Request lifecycle with atomic scope
**9.1 arInitial (one atomic + slow work outside).**
- INSIDE one atomic: determine the recovery plan for N (Section 9.5) — i.e.
  Phase-1 descending search for the start point, pinning the start point and any
  present cached outputs that will be reused, and cataloguing the OUTPUT HOLES that
  must be computed; record all pins to the `frameData` pin-list; update hot zone(s)
  for N (D15). One indivisible operation. The backward search is BOUNDED — it must
  bound the search interval `[max(0, N-B), N]` itself, not find a global nearest
  prior anchor and reject it afterward (carried forward from CMS06.11 §4.5.3 /
  `prepare_bounded_recovery_plan()`).
- OUTSIDE the atomic: request from VapourSynth the SOURCE frames needed — **source N
  plus the sources for the genuine output holes only** (Section 9.5.1 — the dissolved
  source window). NOT a blanket `[max(0,N-B), N]` source window. Slow (may trigger
  upstream decode) — never inside the lock.
- Safe because present/reused frames (and the start point) are pinned (protected) and
  holes are absent (cannot be pruned). The plan snapshot stays valid after lock
  release. **Why the start-point pin is load-bearing under fmParallel (CMS07.9
  clarification, no behaviour change):** because planning (here, at arInitial) and
  acting (the ascending fill at arAllFramesReady) are SEPARATE atomics with an
  unbounded gap between them, under fmParallel-class concurrency another activation
  may run a prune pass during that gap. Pinning the start point / anchor INSIDE the
  AS1 atomic (it carries a pin before the lock is released) is precisely what stops a
  concurrent prune from evicting the frame the plan is built on — prune never selects
  a pinned slot. Without the AS1 pin the plan's foundation could be freed before the
  fill consumes it; with it, the plan snapshot is durable across the gap regardless of
  concurrent prune activity. (This is a rationale for the existing AS1 pin requirement,
  not a new requirement; see §8.7 AS1 and the prune predicate §7.1.)
**9.2 arAllFramesReady (compute outside, per-frame store-and-pin atomic, end-unpin).**
- The WHOLE activation is the single overarching consumer for the hole-filling pass.
- For each output hole, in ASCENDING frame-number order from the start point forward:
  **first, a brief pre-compute atomic { check-present-and-pin } (CMS07.9, normative):
  before computing hole K, check under the cache lock whether output[K] is ALREADY
  PRESENT (a concurrent activation may have stored it during the gap since AS1 planned
  it as absent); if present, pin it, append the pin to the pin-list, and SKIP the
  compute and the store for K entirely (adopt-and-skip). Only if output[K] is absent
  at this check** do we then compute the output OUTSIDE the lock; then a brief per-frame
  atomic { first-in-best-dressed check; store; pin; record }; unlock; proceed. Store-and-pin
  MUST be the same atomic (else a gap lets another thread prune the just-stored frame).
  The pre-compute check is the find-and-pin primitive (D06) applied at the START of
  per-hole handling; it is the SAME mechanism as the AS3 reused-frame pin (§8.7), now
  reachable and normative under fmParallel (see §9.6.3 Category A and §9.6.5).
- **Scene-change detection runs during each compute** (Section 1, §A4): if a cut is
  detected at hole K, output[K] is computed as a fresh start (copy source chroma,
  skip the recursive blend) and stored WITH the checkpoint flag set (Section 6.4);
  otherwise output[K] = blend(output[K-1], source[K]). Either way it is store-and-
  pinned and the ascending walk continues. A cut severs the chain at K (frames below
  K do not influence frames ≥ K).
- Compute output N from the now-present, pinned predecessor chain via the existing
  explicit-predecessor processing boundary (D27/D37 — no new pixel maths); return N
  to VapourSynth (the returned frame's ref is TRANSFERRED, not released).
- Final unpin of the whole pin-list in one short atomic at end (4.5).
**9.3 First-in-best-dressed — both branches release (D07).**
- Winner: store-and-pin-and-record (inside atomic), no extra addref beyond the store.
- Loser: `freeFrame` its computed-but-unstored duplicate before discarding — never
  drop the pointer (else leak). Wasted compute acceptable
  (`duplicate_store_computed_but_discarded` counter); the frame ref must still be
  freed.
- First-in-best-dressed governs the frame *data* (the first store's pixels win). The
  checkpoint *flag* is handled separately and is monotonic under duplicate stores —
  raise allowed (promote), never cleared (demote) — per §6.6.
**9.4 Terminology (kept distinct to stop one word hiding two things):**
*unlock* (release the cache lock) ≠ *freeFrame* (release a frame ref); *source hole*
(missing source → request from VS) ≠ *output hole* (missing cached output →
recompute); *pin* (consumer need, in lock) ≠ *hot zone* (anticipated, heuristic) ≠
*checkpoint flag* (recovery-anchor retention).
**9.5 Recovery model — two-phase: descending search, then ascending fill-holes-only.**
The old conservative `[max(0,N-B), N]` source-request window is GONE (it was an
artifact of held-ref-only defensiveness). Because pins guarantee a present
predecessor cannot be pruned, recovery only computes genuine holes and only requests
their sources. This makes the old "H17 sparse-hole" efficiency the BASELINE, because
the pin scheme makes it safe.
**Phase 1 — find the start point (DESCENDING search from N-1).**
```text
scan K = N-1, N-2, ... down to the lower-bound floor max(0, N-B):
    first PRESENT cached output found  -> start_point = K, STOP (pin it)
        (checkpoint flag IRRELEVANT here: the first present frame wins, close or
         far. A checkpoint matters only because its longer retention makes it MORE
         LIKELY to still be present in a cold region — not because it is preferred
         when a closer ordinary output exists.)
    none present before the floor       -> floor fallback (below)
```
The search is bounded to `[max(0,N-B), N-1]` (do not scan the whole clip; the requested frame N
is the target, never an anchor candidate).
**Bounded-report semantics (clarification; normative for recovery refusal):** the Phase-1 search
reports presence ONLY within its window `[max(0,N-B), N-1]`. When it finds no present output in that
window, the result is a single state — "no in-window anchor" — and it does NOT distinguish "an older
present output exists BEYOND the window" from "no prior output exists at all." Distinguishing those
would require an unbounded out-of-window scan, which the bound exists to avoid. A recovery refusal
therefore reports `no-in-window-anchor` and MUST NOT claim a bounded-window-exceeded vs no-prior-output
distinction the bounded search cannot make; any caller needing that distinction proves it by
construction/context, not from the search result. (Proven live by D.2's bounded-window refusal.)
**Phase 2 — fill (ASCENDING from start_point to N), fill-holes-only (CMS06.11 §2.1).**
```text
for K ascending from start_point+1 .. N:
    if output[K] already present -> reuse it (find-and-pin); do NOT recompute
    else (hole)                  -> compute (scene-change-aware, Section 9.2);
                                    store-and-pin (first-in-best-dressed)
then return output[N].
```
(There may be OTHER present frames above the start point; fill-holes-only reuses each
of them too — only genuine holes are computed.)
**Floor fallback — D29 approximate fresh-start (confirmed).** If Phase 1 reaches the
floor `max(0, N-B)` without finding any present output, compute the floor frame as a
FRESH START (no predecessor, reset/start semantics — as if frame 0), then fill
ascending to N. Justification: the recursive chroma blend smears toward its
predecessor, so the influence of the approximate start frame DECAYS over the B-frame
walk and the visible result at N-1/N converges to near-continuous-from-0 blending.
**Materialized-floor-is-the-foundation (clarification; proven live by D.3).** Once the floor frame
has been fresh-started, stored, and pinned, it IS the validated consumer foundation for the ascending
walk — equivalent to a search-discovered anchor. The fill machinery validates only the structural walk
contract (a present, pinned foundation frame with the holes as the contiguous run above it); it does
NOT depend on HOW that foundation came to exist (found by the Phase-1 bounded search, or created by
this floor fallback). So treating the materialized floor as the walk's anchor is a now-true structural
fact, not a bypass. This supersedes the D.2-era no-in-window-anchor REFUSAL for reachable in-range N:
after the floor fallback is wired, recovery floor-fresh-starts rather than refusing; genuine refusal
narrows to structural/impossible cases (corrupt/non-contiguous plan, n<=0, source/alloc failure).
**Coherence constraint:** B (BACK_RADIUS) MUST exceed the effective settling length of
the recursive blend, so the approximation is invisible at N (relates CR2/CR3).
**Scene cuts bound the approximation further.** A cut between the start point (or
floor) and N severs the chain and resets EXACTLY at the cut, wiping any approximate-
start error below it. So the floor approximation only matters for a long static span
with NO cut between floor and N — precisely where recursive blending is most stable
anyway. Detected cuts are promoted to checkpoints (Section 6.4), so they become exact,
longer-retained start points found naturally by the Phase-1 search — this absorbs the
previously-considered "remember cut positions" optimisation for free.
**9.5.1 Dissolved source window (the request set).** arInitial requests **source N +
the sources for the genuine output holes only** (the holes found in Phase 1 between
start_point and N). NOT a blanket backward window. Example: start point a checkpoint
at N-10, holes only at N-3 and N-1 → request sources {N-3, N-1, N}, three frames, not
eleven. Requesting a source for a position whose output is already present is
unnecessary and avoided (it would be harmless per CMS06.11 first-in-best-dressed
layering, but the point of the dissolved window is to not do it).
**9.6 Current minimal recovery path, AS3 deferral, and the two state categories (clarification).**
This subsection clarifies which subset of the §9.1/§9.2/§9.5 recovery model is the
*currently proven and active* correctness path, and resolves the apparent tension
between the reserved AS3 atomic (§8.7) and the nearest-present-start-point +
contiguous-hole planner that is actually built and proven (through CMS07-H.3A). It adds
no new design behaviour; it pins down interpretation.
**9.6.1 The current minimal planner is nearest-present-start-point + contiguous holes.**
Phase-1 bounded search descends from `N-1` and the first present cached output found
becomes the start point / anchor. The hole catalogue is therefore CONTIGUOUS from
`start_point + 1` through `N - 1`, with `N` (the requested frame) recorded separately as
the repair target, never as a hole-catalogue entry. Under this minimal planner, a
present cached output strictly between the start point and `N` cannot also be a "reused
intermediate" distinct from both the start point and the holes:
```text
- if it was PRESENT during AS1 planning, the descending search would have stopped there
  and made it the (nearer) start point;
- if it was ABSENT during AS1 planning, it is a planned hole and is consumed through AS2.
```
There is no third category in the current planner.
**9.6.2 AS3 — what is deferred, and what is now normative (CMS07.9 clarification).** A
distinction must be drawn that earlier wording (CMS07.3) left implicit and which is easy
to misread:
```text
- DEFERRED: extending the PLANNER to catalogue sparse reused-intermediate frames
  (frames between the start point and N that are planned as reused rather than as
  contiguous holes). Under §9.6.1 the current planner emits no such plan shape, so a
  reused-intermediate-DISTINCT-from-start-point-and-holes does not arise AT PLAN TIME.
  This planner extension awaits a future, separately approved sparse-plan /
  recompute-avoidance CMS revision. Do NOT implement it against an unreachable synthetic
  plan shape, and do NOT extend the planner to sparse reused intermediates without that
  approval.
- NORMATIVE (CMS07.9): the AS3 find-and-pin PRIMITIVE applied at AS2/fill ACT TIME — the
  pre-compute check-present-and-pin-and-skip of §9.2. This is NOT the deferred planner
  extension. It does not change the plan; it handles the case where a frame the planner
  correctly catalogued as a hole AT PLAN TIME has become present BY ACT TIME under
  fmParallel concurrency (§9.6.3 Category A). It is reachable, expected, and required
  under fmParallel and is therefore baked in now (see §9.6.5).
```
The earlier "AS3 is reserved but deferred / no reachable trigger" statement was correct
ONLY about the planner extension and ONLY at plan time; it must not be read as denying
the act-time gap-fill race, which §9.6.3 Category A always recognised as expected and
which §9.2/§9.6.5 now handle normatively. Until the sparse-plan revision, recovery
execution consists of:
```text
- start-point / anchor pin-record from AS1 (proven: H.2A);
- per hole, ascending: pre-compute check-present-and-pin-and-skip (CMS07.9, §9.2/§9.6.5),
  else compute-then-contiguous-hole-consume through AS2 (proven: H.3A);
- the requested frame N handled separately by later return/output authority.
```
**9.6.3 Two superficially similar states must be treated DIFFERENTLY.**
*Category A — a planned hole became present before this activation's AS2 store
(EXPECTED concurrency, NOT an error).* Under fmParallel-class concurrency, a frame that
was a genuine output hole at AS1 time may be stored by another activation before this
activation reaches its AS2 store for the same hole. This is handled by the existing AS2
first-in-best-dressed duplicate/adopt semantics (§9.2/§9.3): the existing winner remains
authoritative, this activation's incoming computed duplicate is rejected and its frame
ref freed (the `duplicate_store_computed_but_discarded` case, §9.3), the existing winner
is pinned, and exactly one pin is recorded for this activation (proven: H.3A). This is
NORMAL and correctness-complete. It must NOT be treated as a failure, must NOT abort, and
must NOT emit a user-visible error. It may be counted as ordinary telemetry later
(§9.6.4 and the diagnostics specification).
*Category B — a non-contiguous reused-intermediate state under the contiguous-hole
planner (IMPOSSIBLE / design-drift, a hard failure).* A recovery plan in which a present
cached output appears between the start point and `N` as something other than the start
point or a planned hole (e.g. holes catalogued as {start+1, start+3} with start+2 present
and reused) is NOT producible by the §9.6.1 planner. If such a state is ever observed, it
indicates an invariant violation / design drift, NOT an AS3 opportunity. It must be
detected and must NOT be silently accepted (which could produce a wrong output frame).
The cache-core layer reports it by returning a hard status (`invariant_violation` or
`lifecycle_violation`); it does NOT print while holding a cache lock. Later, when the
VapourSynth integration / getFrame layer exists, that layer maps the hard status to clean
filter failure and MAY emit a single bounded developer-alert to stderr OUTSIDE all cache
locks (see §9.6.4).
**9.6.4 Detection placement and the developer-alert principle (forward-looking).**
Detection of Category B belongs as immediate structural status returns inside the
cache-core helpers NOW (no printing there). Proving the guardrails belongs in the
aggregate cache-core proof (CMS07-C.14A): that the plan is contiguous and self-consistent,
that the requested frame is never consumed as a hole, that every recovery AS2 consume is
for a genuine planned hole, that Category-A duplicate/adopt is accepted and accounted, and
that a Category-B shape is rejected by status rather than silently accepted. The
user-visible developer-alert itself is FUTURE integration work (it occurs at getFrame
error-mapping time, which is not yet built) and is NOT a current requirement of the
isolated cache core. When it is built, it must follow this PRINCIPLE: a bounded,
structured, one-shot (or rate-limited per instance/condition) incident report on stderr
only (never stdout), emitted outside all cache locks, carrying enough real context to
write a targeted reproducer (e.g. an edit-version/condition identifier, the relevant
frame numbers and expected-vs-actual plan classification, the status code, and an
instruction to report it with the script, clip format, and VapourSynth version), and
reserved strictly for Category-B impossible states — never emitted for Category-A expected
concurrency. The exact field set is deferred to implementation time (it depends on what
the integration layer can observe) and is decided then. "Bounded/one-shot" means not a
per-frame flood and not a full internal-state dump; it does not mean information-poor.
**9.6.5 Pre-compute adopt-and-skip — normative under fmParallel (CMS07.9).** Per-hole
recovery handling (§9.2 ascending fill) is, NORMATIVELY, a two-check sequence per hole K:
```text
(1) PRE-COMPUTE, under the cache lock: check whether output[K] is already present.
    - If PRESENT: pin it, record the pin to the pin-list, and SKIP both the compute and
      the AS2 store for K (adopt-and-skip). One pin recorded; no compute performed.
    - If ABSENT: release the lock and proceed to (2).
(2) COMPUTE OUTSIDE the lock, then AS2 store-and-pin with first-in-best-dressed (§9.2/§9.3):
    - winner: store-and-pin-and-record;
    - loser (a concurrent activation stored K while we computed): adopt-and-pin the
      existing winner, free our computed duplicate (§9.3), record one pin.
```
Both checks are the SAME find-and-pin / first-in-best-dressed primitive applied at two
points on the timeline (before the compute and after it). The reason BOTH are required,
not just one:
```text
- The POST-compute check (2) is what makes recovery CORRECT under concurrency: it has
  existed since CMS07.1/§9.3 and guarantees the right end state (one authoritative frame,
  one pin) no matter who wins the race. Correctness does not depend on (1).
- The PRE-compute check (1) is what makes recovery EFFICIENT under fmParallel: without
  it, every hole a concurrent activation already filled during the gap is recomputed in
  full and then discarded as a loser at (2). Under fmParallel — and a fortiori under two
  interlaced single-field instances each running fmParallel over overlapping frame ranges
  — gap-fills are EXPECTED and FREQUENT (§9.6.3 Category A), so "compute-then-discard" as
  the only handling would do a large amount of redundant full-frame work. (1) converts
  that into a cheap present-check-and-adopt.
```
This step is baked in NOW, ahead of the fmParallel correctness phase, deliberately: the
design mandate is to build toward the fmParallel + two-instance-interlaced end goal
(§2 filter-mode posture; §8.6), and the pre-compute adopt-and-skip is a structural
consequence of that goal that would otherwise have to be retrofitted onto an
already-shipped recovery path. It is normative, not optional. (1) and (2) are each one
indivisible cache-lock critical section; neither holds the lock across a compute or a
freeFrame (§8.7; the compute and the loser freeFrame are OUTSIDE the locks). Telemetry:
(1)-hits (compute skipped) and (2)-losers (computed-then-discarded) are distinct counters;
their ratio measures how much redundant compute the schedule induces and whether (1) is
earning its keep (diagnostics specification; observe-only).
---
## 9.7 Predecessor sourcing for the keystone (consolidated; non-normative restatement)
This subsection adds **no new rule and changes no decision.** It collects the
predecessor-sourcing decision for the getFrame keystone — currently distributed across
§4.8, §6.3–§6.6, §9.1–§9.3, §9.5–§9.5.1, §9.6, and §9A.7 — into one place, stated from the
keystone-writer's point of view, with pointers to each owning section. The owning sections
remain authoritative. (It was added because the keystone implementation re-opened several of
these decisions as if undecided; consolidating them here prevents that.)
**There is no branch that uses `source[N-1]`** (R-ARCH-06; §12B).
### 9.7.1 The predecessor decision for output[N]
Determine the predecessor in this order. Every branch is specified in an owning section;
§9.7 only collects them.
```text
(a) N == 0
        -> FRESH START. output[0] = source[0] copied (copy source chroma, copy luma,
           skip the recursive blend). No predecessor exists or is sought.
           [Owning: §9.2 fresh-start definition; §9.5 "as if frame 0"; §6.3 frame 0 is
            always a checkpoint and is never pruned.]
(b) output[N] already present in cache
        -> RETURN IT DIRECTLY. No predecessor is sought, and no source is needed or
           consumed for the result; no pixel path runs. (Cache-hit fast path for
           repeated/duplicate requests and seeks.) Under R-LIFECYCLE (§9A.1.1), CNR3 as a
           dependency filter still requests source[N] as a lifecycle TRIGGER for
           callback-safety, retrieves and immediately frees it (not consumed), and returns
           the cached output at arAllFramesReady; "direct" means "no predecessor, no result
           source, no pixel path" -- NOT "no request and not from arInitial."
           [Owning: §9.3 first-in-best-dressed; the cached frame's ref is transferred to
            VapourSynth on return, §4.8; §9A.1.1 R-LIFECYCLE for the trigger-request timing.]
(c) N > 0, output[N] absent, output[N-1] PRESENT in cache
        -> USE output[N-1] as the predecessor (find-and-pin). Request source[N] only.
           Blend output[N] = f(source[N], output[N-1]).
           [Owning: §9.6.1 nearest-present-start-point — here the start point is N-1
            itself; §4.8 the consumed predecessor is an INPUT, released not transferred.]
(d) N > 0, output[N] absent, output[N-1] ABSENT
        -> §9.5 BOUNDED RECOVERY (see §9.7.2). One bounded backward search from N-1 to the
           floor max(0, N-B), B = BACK_RADIUS = 50 (§10.1), taking the FIRST present output
           found; never preferring checkpoints; never scanning past the floor. Checkpoints
           are the present outputs that SURVIVE eviction (§6.3), and CR3 (§10.2) sizes the
           bound to span ~5 checkpoint intervals (50 ~= 5 x CHECKPOINT_INTERVAL = 5 x 10),
           so a surviving anchor is almost always in reach and the EXACT path is the common
           case; the floor fresh-start is the RARE fallback when even the in-window
           checkpoints are gone. Never source[N-1]; never a from-frame-0 rebuild unless
           frame 0 falls inside the bound; never controlled failure for "no anchor" (the
           floor fresh-start always produces a frame).
           [Owning: §9.5 search + floor fallback; §9.6.1 minimal planner; §9.5.1 holes-only
            source window; §6.3 retention; §10.2 CR3.]
FORBIDDEN ON EVERY BRANCH:
        substituting source[N-1]; substituting any same-numbered raw source frame;
        substituting a nearest source frame; treating source as a "close enough"
        predecessor. (§12B — this approximation is exactly what CNR3's cache replaces.)
```
### 9.7.2 The bounded recovery (branch (d), expanded)
Let `B = BACK_RADIUS` (§10.1, currently 50), `floor = max(0, N - B)`, and
`CHECKPOINT_INTERVAL` (§10.1, currently 10) the grid anchor cadence. The headings below are
the implementation's distinct concerns; each is a separate constraint to hold.
**Search bound and direction (§9.1 INSIDE one atomic; §9.5).** Run ONE descending scan
`K = N-1, N-2, ... ` down to `floor`. The interval `[floor, N]` is a hard bound: bound the
interval itself; do not scan past it, and do not find a global nearest prior anchor and then
reject it (§9.1). There is exactly one search over the present-frame index (D04) — NOT a
recent-cache search followed by a separate checkpoint search. Recent-cache entries and
checkpoints are both just "present outputs" in the same ordered index from the search's view.
**Selection rule — first present output wins (§9.5 Phase 1).** The first present cached
output found (the greatest present frame `<= N-1` within the bound) becomes the START POINT;
the search stops and pins it. The checkpoint flag is IRRELEVANT to selection — the first
present frame wins, close or far. A checkpoint is NOT preferred over a closer ordinary output.
**Why checkpoints survive to be found (§6.3 retention; §6.4 cut promotion).** Ordinary cached
outputs are pruned (the non-checkpoint pool is bounded and evicts); checkpoints are retained
(kept between MIN_RETAIN and MAX_RETAIN; frame 0 never pruned; cuts promoted). So in a COLD
region — seeked-into, where the rolling recent-cache has long since evicted the ordinary
outputs — the frames most likely still present are the checkpoints. The search finds them not
because it seeks them, but because they survived.
**Bound-to-cadence sizing — why the search usually succeeds (CR3, §10.2).** The search reach
is `B = 50` and checkpoints are planted every `CHECKPOINT_INTERVAL = 10`, so by CR3
(`BACK_RADIUS ~= 5 x CHECKPOINT_INTERVAL`, `50 = 5 x 10`) roughly 5 grid checkpoints fall
WITHIN the search window, plus any cut-checkpoints, plus frame 0 if in range. This is what
makes checkpoint retention redeemable within the bound: the bound is sized to contain enough
surviving anchors that the search almost always finds one before the floor. (If
CHECKPOINT_INTERVAL were widened beyond `B`, the window could contain zero checkpoints and
this would fail — CR3 prevents that.)
**Common case — exact recovery (the usual outcome).** If a start point `S` is found
(`S >= floor`): `S`'s output is real filtered output. Walk forward `S+1..N` filling ONLY the
genuine holes (§9.2), each blended against the now-present predecessor below it. Reused
present frames between `S` and `N` are NOT recomputed (§9.6.1 — and there is NO third
"reused-intermediate" category under the current planner; AS3 is reserved but DEFERRED,
§9.6.2 — do NOT implement AS3 against a synthetic plan). Cost is bounded — at most the
distance to `S` (`<= ~CHECKPOINT_INTERVAL` in a warm region, `<= B` in a cold one) holes to
recompute — and clip-length-INDEPENDENT.
**Rare fallback — floor fresh-start (only when the window is barren).** If the search reaches
`floor` with nothing present: compute the floor frame as a FRESH START (no predecessor, copy
source chroma, reset semantics — the SAME operation as a cut-reset and as frame 0; §9.5,
"D29 approximate fresh-start"), then walk forward `floor+1..N` as above. Frame 0 is reached
here ONLY when `N < B` (floor clamps to 0); for a far seek the reset is at the floor (e.g.
`N=1000` -> reset at 950), NOT at frame 0. See §9.7.3 for the honesty constraint on this
approximation.
**Fill order (§9.2 arAllFramesReady).** Fill holes in ASCENDING frame-number order from the
start point. For each hole `K`: compute outside the lock; brief atomic { first-in-best-dressed
check; store; pin; record }; unlock. A reconstructed `output[K]` is stored through AS2 and is
then a present predecessor for `K+1` — do NOT hold it in a local and skip the store/find
cycle; the store-then-reacquire discipline is what guarantees each predecessor is the real
cached output, even mid-recovery.
**Source request set — holes only (§9.1 OUTSIDE the atomic; §9.5.1).** Request `source N`
PLUS the sources for the genuine output HOLES ONLY. NOT a blanket `[floor, N]` source window.
Example: start point a checkpoint at `N-10`, holes only at `N-3` and `N-1` -> request
`{N-3, N-1, N}`, three sources, not eleven. Request HOLES, not SPAN (so it is correct when
the holes are sparse, not only when contiguous).
### 9.7.3 The honesty constraint on the floor fresh-start (carried from §9A.7)
The floor fresh-start (branch (d), rare fallback) is EXACT FROM THE FLOOR FORWARD but is a
BOUNDED APPROXIMATION relative to a true from-frame-0 recursion: the recursive chroma blend
began at the floor, not at 0. This is the ONE place CNR3's output is not bit-exact to a
continuous-from-0 run.
- CR2 (§10.2) is the constraint that keeps it invisible at `N`: `B` must exceed the recursive
  blend's effective settling length. (If `B` is ever shrunk for memory, re-confirm CR2.)
- A scene cut between the floor and `N` severs the chain and resets exactly at the cut (§9.2),
  wiping any approximate-start error below it — so the floor approximation matters only for a
  long STATIC span with no cut, precisely where the blend is most stable anyway.
- The floor-approximation use MUST be disclosed in diagnostics and MUST NEVER be described as
  exact full-history recursion (§9A.7 durable rule).
### 9.7.4 Ownership and cleanup for the keystone (consolidated; owning §4.4–§4.8, §9.3)
- Only the returned output frame `N` is TRANSFERRED to VapourSynth (§4.8 / §9.2).
- A consumed predecessor or recovery intermediate is an INPUT — RELEASED, not transferred
  (§4.8). Balance: `lookup_owned_ref_acquired_total == released_total + transferred_total`
  (§4.8).
- Single-ownership / null-on-consume (§4.4): each reserved/owned ref or pin entry is owned by
  `frameData` until consumed; successful consumption releases-or-transfers EXACTLY ONCE then
  nulls the entry; cleanup releases an entry only if still non-null; the null field is the
  idempotency guard, so exactly one of {consume, cleanup} releases any given entry. This is
  what makes the failure-path cleanup below safe against double-free.
- A cache-store ref for `output[N]` (and for each reconstructed `output[K]`) is consumed by
  AS2 under first-in-best-dressed duplicate/adopt (§9.3); the loser duplicate is freeFrame'd
  before discarding (§9.3 `duplicate_store_computed_but_discarded` — never drop the pointer);
  the winner/adopt outcome is a NORMAL, correctness-complete Category-A outcome and MUST NOT
  abort or emit (§9.6.4 / §9.3).
- `frameData` cleanup/destructor MUST unpin any pins still on the pin-list on EVERY exit path
  including every early error return (§4.5/§4.6). freeFrame is NEVER inside the cache lock
  (detach under lock, free after).
- A HARD cache/recovery status (e.g. a non-contiguous recovery plan rejected by the C.13B
  guard) maps to setFilterError + a bounded one-shot stderr developer alert OUTSIDE locks —
  the EMISSION half of what C.13B DETECTS (§9.6.4). Expected Category-A duplicate/adopt and
  ordinary cache-miss-leading-to-recovery stay SILENT.
### 9.7.5 Scene-reset is already a checkpoint (no special keystone path)
A scene-change/reset frame is computed as a fresh start (§9.2) and is THE IDEAL recovery
anchor (exact, dependency-free). It is therefore stored WITH the checkpoint flag set by the
existing §6.4 rule, as part of the normal AS2 store — NOT by any special keystone logic. The
keystone lets §6.4 fire; it adds no scene-reset checkpoint handling of its own. (Checkpoint
flag is monotonic under duplicate stores, §6.6: raised, never cleared.)
### 9.7.6 One-line summary
Predecessor for `output[N]` = (a) `N==0` fresh-start; (b) cached `output[N]` returned
directly; (c) `output[N-1]` present -> use it; (d) `output[N-1]` absent -> §9.5 bounded
recovery (one search to floor `N-B`; first present output wins; exact anchor if found; else
floor fresh-start); NEVER `source[N-1]`.
### 9.7.7 Source-input dependency declaration — rpGeneral, not rpStrictSpatial (resolves FI-04)
This subsection RECORDS A DECISION and is NORMATIVE for the keystone's registration step. It
concerns the dependency the filter declares to the VapourSynth engine for its SOURCE INPUT
node — NOT the filter's threading mode (§2) and NOT the CMS7 OUTPUT cache (§3–§9.7.6).
**Decision.** The source-input dependency is declared **`rpGeneral`** (general request
pattern), NOT `rpStrictSpatial`.
**Why.** `rpStrictSpatial` declares that producing output[N] requests ONLY input frame N (a
strict 1:1 spatial dependency — the engine's strongest sizing assumption). That is truthful
for a stateless spatial filter, but it is FALSE for CNR3 the moment recovery is live: bounded
recovery (§9.5 / §9.7.2) requests **source N PLUS the sources for the genuine output holes**
(§9.5.1 — a sparse set of EARLIER source frame numbers), and the floor fresh-start may request
an earlier source still. So output[N] does not depend on input N alone; it may depend on a
bounded backward set of inputs. `rpStrictSpatial` would misdeclare that to the engine.
`rpGeneral` is the conservative-correct declaration for a filter whose input request set for
output[N] is a bounded backward set rather than the single frame N. (This is the
registration-layer counterpart of the output→filter→source demand direction in §3.4 and the
dissolved holes-only request set in §9.1/§9.5.1.)
**Orthogonality (do NOT conflate — the trap this subsection exists to prevent).**
`requestPattern` (the `rp*` enum: `rpGeneral` / `rpNoFrameReuse` / `rpStrictSpatial`) and
`filterMode` (the `fm*` enum: `fmUnordered` / `fmParallelRequests` / `fmParallel`, §2) are
SEPARATE, ORTHOGONAL layers:
- `requestPattern` is a HINT to the engine about the SHAPE of this filter's UPSTREAM input
  requests, used to size the engine's own input-frame cache. It is a property of the input
  dependency.
- `filterMode` is THIS filter's THREADING model.
Declaring `requestPattern = rpGeneral` does **NOT** change `filterMode` (`fmUnordered` remains
current; the `fmParallel` final-goal invariant of §2 is untouched) and does **NOT** touch the
CMS7 OUTPUT cache, its pins, its checkpoints, its recovery, or any correctness property in
§3–§9.7.6. The CMS7 cache is the sole authority on OUTPUT caching (V6, §3.2 "do not layer the
core cache over our outputs"); `requestPattern` concerns only how the engine caches our INPUT
requests, which is a cost/scheduling matter, never a correctness one.
**Scope.** This declaration is part of the filter's registration / dependency setup (the
keystone's wiring step). It changes no constant (§10), no AS scope (§8.7), no recovery rule
(§9.5/§9.6), and no ownership rule (§9.7.4). It resolves companion investigation FI-04.
---
## 9A. Carried-forward hard rules (section-level audit of CMS06.11 — gap-fill)
The CMS06.11 body was audited section-by-section as an INDICATIVE gap-finder (not a
definitive authority — where it conflicts with this architecture, CMS07.0 wins). The
following still-valid mechanism detail was not yet stated in CMS07.0 and is carried
forward here, each rule re-validated against the new architecture.
**9A.1 VS-LIFECYCLE-01 — hard VapourSynth API constraint. Non-negotiable.**
```text
Any source frame that will be retrieved with getFrameFilter() in
arAllFramesReady must have been requested with requestFrameFilter()
in arInitial of the SAME callback activation.
```
This is not a CNR3 design choice; it is a hard API rule. Violating it produces silent
failure or undefined behaviour. It is NOT possible to discover in arAllFramesReady
that more sources are needed and request-then-retrieve them there. Consequence under
the new model: the request decision must be made using only arInitial-time
information — which is exactly why AS1 (Phase-1 descending search + hole catalogue +
pin) runs in arInitial, and why the dissolved source request set (§9.5.1) is computed
there. If the Phase-2 walk could ever need a source not in the AS1-computed set, that
is a design bug, not a runtime recoverable.
**9A.1.1 arInitial vs arAllFramesReady — the frame-RETURN contract (hard API rule; sibling
to VS-LIFECYCLE-01).** VS-LIFECYCLE-01 (§9A.1) governs what may be RETRIEVED in
arAllFramesReady (only what was requested in arInitial). This sibling rule records the paired
hard-API fact §9A.1 does not state: WHEN the output frame is RETURNED. Both are properties of
the R76 `VSFilterGetFrame` activation-reason contract (VapourSynth4.h), not CNR3 design
choices.
```text
CNR3 is a DEPENDENCY filter (it has a source input node), NOT a source filter. Therefore:
  arInitial         -> request the needed input frames (requestFrameFilter) and return NULL.
                       Do NOT return an output frame from arInitial.
  arAllFramesReady  -> retrieve the requested inputs (getFrameFilter), compute, and RETURN
                       the output frame here (its ref TRANSFERRED, §4.8).
```
The "return a finished frame directly from arInitial" pattern is the **source-filter**
exception — for a filter with NO input node that synthesises frames from nothing. It does
**NOT** apply to CNR3. Consequence for §9.7.1 branch (b) (output[N] already cached → return it
directly): for a dependency filter this still occurs through the normal cycle — at arInitial
the activation returns NULL; at arAllFramesReady it returns the cached frame (ref transferred,
§4.8). "Return it directly" means "no predecessor sought, no pixel path run" — NOT "returned
from arInitial." Together with VS-LIFECYCLE-01: **request-in-arInitial,
retrieve-and-return-in-arAllFramesReady.** A request decision (including the dissolved
holes-only source set, §9.5.1) must therefore be complete at arInitial time using only
arInitial-time information; the output is produced and returned one activation-reason later.
(Confirmed against the local R76 VapourSynth4.h.)

*** CMS07.10 CORRECTION TO CMS07.9 §9A.1.1 — R-LIFECYCLE (the triggering-request rule). Proven live by
keystone K.1F (live direct cached-output return), 2026-06-25. ***
The paragraph above previously stated that at arInitial the branch-(b) cache-hit activation
"requests nothing ... and returns NULL." Investigation for K.1F (multiple authoritative-source
reviews + the R76 vsthreadpool completion path) established that this is **NOT safe**: under
API4/R76, a getFrame activation that requests ZERO input frames at arInitial and returns NULL
is **not guaranteed an arAllFramesReady callback** (the disputed-but-unrefuted reading is that
zero-pending + NULL-return is treated as terminal; it is not confirmable from quotable core
source, so CNR3 does not rely on it). Two zero-/early-return alternatives were therefore
REJECTED as unverified for a non-source filter under fmParallel: (A) returning the cached frame
directly at arInitial (source-filter pattern, not established safe for a dependency filter under
fmParallel), and (B) zero-request arInitial→NULL then return at arAllFramesReady (the callback
may never fire). CNR3 adopts no unverified method.
**R-LIFECYCLE (normative): EVERY CNR3 getFrame branch requests at least one REAL source frame at
arInitial and returns its output ONLY at arAllFramesReady.** For the branch-(b) cache hit, which
needs no source for its result, the branch requests exactly **source[N] as a lifecycle TRIGGER**
(Option C): at arInitial it pins the cached output[N] (consumer pin recorded in frameData, so a
concurrent prune cannot evict it across the activation gap — the §9.1 AS1 rationale applies
here too), requests source[N], and returns NULL; at arAllFramesReady it retrieves source[N],
**immediately frees it** (a normal owned ref — not consumed for compute, not stored, freed
outside any cache lock), acquires the return ref via lookup-and-add-ref on the pinned output[N]
(present by pin; if absent it is an invariant violation, surfaced — never a garbage return),
discharges the pin-list (the AS4 single-lock batch discharge, recovery-step-0), and transfers
the cached frame. HONEST COST: a branch-(b) return can be blocked by a source[N] retrieval
failure even though the cached output already exists; accepted, because output[N] was previously
produced from that same source in the same graph, so a source[N] failure on re-request is an
anomaly. The trigger request is the dependency-filter price of staying on the documented
request-in-arInitial / return-in-arAllFramesReady contract. (Branches and the act-time dispatch
are keyed on a per-invocation frameData branch tag set at arInitial, never on re-inspecting
frame state at arAllFramesReady, so a concurrent cache change cannot cause a different branch to
execute than the one planned.)
*** end CMS07.10 CORRECTION ***
**9A.2 Reference-count discipline RC1–RC8 (carried; helper NAMES indicative — the
restart coder names them; the OBLIGATIONS are mandatory).**
- **RC1 — Single store helper.** All cache-owned `addFrameRef` calls occur only in
  the one store helper.
- **RC2 — Single remove helper.** All cache-owned `freeFrame` calls occur only in the
  one remove helper. No direct pool/index erase outside it (this is the D09 central
  remove helper; AS5 detach goes through it).
- **RC3 — Store error paths rebalance.** Store takes `addFrameRef` then fails to
  insert → `freeFrame` before returning.
- **RC4 — Lookup error paths rebalance.** find-and-add-ref takes the ref then fails →
  `freeFrame` before returning null.
- **RC5 — Caller exit paths free.** Every path holding a caller-owned ref frees or
  transfers it exactly once on every exit: success, error, early return, abort.
  (Generalised by the pin-list discharge, §3.2/§4.6.)
- **RC6 — Shutdown clears.** Manager destruction iterates both pools, `freeFrame`s
  every slot, clears the index, resets zones, and **logs a warning for any slot with
  pin_count > 0** — under the new model a non-zero pin at shutdown can only mean a
  leaked consumer pin (the API guarantees the free function runs after all getFrame
  activity), so it is a leak indicator, never normal.
- **RC7 — Validation enforces balance.**
  `cache_addframeref_total − cache_freeframe_total == total_live_slots` at quiescent
  points.
- **RC8 — First-in-best-dressed store idempotency.** If output[N] already exists at
  store time: return success WITHOUT taking `addFrameRef`, without modifying either
  pool, without disturbing the existing slot's classification (including its
  checkpoint flag). The cache has NOT taken ownership of the caller's frame — the
  caller (the losing walk) still owns and must free it (§9.3).
**9A.3 RAII owned-ref wrapper — UPGRADED from "recommended" to BASELINE.** The old
design specified a move-only `Cnr3OwnedFrameRef` RAII wrapper (frame + vsapi;
`freeFrame` in destructor; `release()` for transfer) as recommended-but-deferred
because legacy code used explicit handling. The restart removes that constraint:
**new code uses the RAII wrapper from the start** for caller-owned refs (and the
frameData pin-list discharge composes with it). Explicit manual handling is no longer
the accepted interim. The caller-side diagnostic counters and invariant carry
unchanged: `lookup_owned_ref_acquired_total == released_total + transferred_total`
at quiescent points (development mode).
**9A.4 Ceiling derivation (concrete formula, carried — this is V8's
"derives from actual frame bytes" made exact).** At create time: per-plane
bytes = ceil-subsampled width × height × bytes_per_sample summed over planes;
`candidate_ceiling = CACHE_BYTE_BUDGET / estimated_frame_bytes`;
`active_ceiling = clamp(candidate, MIN_HARD_CEILING=150, MAX_HARD_CEILING=1000)`.
The ceil-division on subsampled dimensions is deliberate (never underestimates for
odd dimensions). Disambiguation retained: PAL VHS is 720×576 (ceiling clamps to
1000); a genuine 1440×576 8-bit clip derives ≈863 unclamped — a log showing
ceiling=1000 for a claimed 1440-wide clip indicates a width misreport.
**9A.5 Hard-ceiling abort policy (carried, adapted to pin-list).** A store is allowed
iff live refs after store ≤ active_ceiling. Rejected iff it would exceed the ceiling
AND prune cannot free any frame (everything is pinned / protected). On rejection:
1. Store returns failure WITHOUT taking `addFrameRef` (RC3 preserved).
2. Increment `cache_ceiling_hard_aborts`.
3. The getFrame path executes cleanup (9A.6), then returns a VS filter error:
   *"CNR3: cache ceiling reached ([N] frames). CNR3 is designed for near-linear
   access. Large random seeks in rapid succession may exceed cache capacity."*
Note under the new model: a hard abort implies the pinned+protected set has filled
the ceiling — CR4's headroom rule exists precisely so this never happens in
legitimate operation; an abort is therefore also a CR4-violation signal.
**9A.6 Failure-path cleanup discipline (carried, simplified by the pin-list).** Every
failure path returning a VS error must, before returning:
1. Discharge the frameData pin-list (unpin every recorded pin — this single step
   replaces the old per-kind "unpin checkpoint pins" item).
2. Free every caller-owned VSFrame ref not on the pin-list (RAII makes automatic).
3. Free any source frames obtained from VapourSynth.
4. Free any destination frame allocated but not returned.
5. Hot-zone state: NO rollback — a zone touched by a failed request retires
   naturally via the decay rule (§5.5).
6. Diagnostic counters still increment.
A ceiling abort may leave already-stored frames in the cache — those are valid
outputs and stay. After cleanup, all ref balances hold.
**9A.7 Bounded-start honesty (durable rule, carried).** When recovery starts at the
floor (S > 0 fresh-start, §9.5), the start is a bounded reset/start APPROXIMATION.
It must never be described — in docs, comments, or diagnostics — as exact
full-history recursion. Diagnostics must disclose floor-approximation use (the §10.5
summary's floor count satisfies this). Override only by explicit documented
agreement.
**9A.8 Design Compliance Review (process rule, carried; checklist adapted).** After
each implementation phase (or coherent block), review all changed code paths AND all
unchanged helpers invoked by them, verifying execution follows CMS07.0 — not old
assumptions. Adapted checklist: (1) mutex ownership correct at every mutable-state
access; (2) `_externally_locked`-style helpers called only under the lock; (3)
public locking helpers never call other public locking helpers (deadlock); (4) no
old-architecture logic in any active path; (5) no pool/index erase bypassing the
single remove helper (RC2); (6) no cache-owned addFrameRef outside the store helper
(RC1); (7) store collisions follow RC8; (8) store-failure rebalances (RC3); (9)
find-and-pin is atomic under the lock (AS3); (10) every caller-owned ref freed or
transferred exactly once (RC5); (11) every pin discharged on every exit (pin-list);
(12) hot-zone state never rolled back on failure; (13) cache-side balance holds
(RC7); (14) caller-side lookup-ref diagnostics balance (dev mode); (15) shutdown
clear() releases everything (RC6); (16) no diagnostics write to stdout; (17) NEW —
every critical section matches its atomic-scope register entry (AS1–AS7) exactly.
**9A.9 FORWARD_RADIUS empirical basis (citation carried).** FORWARD_RADIUS=10 rests
on measured linear-encode request jitter from the prior design's simulation (p99
forward jitter ≈ 8 under concurrent linear encoding) — it is measured-and-margined,
not arbitrary.
**9A.10 Audit verdict on everything else in the CMS06.11 body.** Superseded by this
architecture and intentionally NOT carried: §4.2 zone-as-findability-guarantee
lifecycle and the lazy-retirement proxy (replaced §5.5/5.6); §4.4 deferred pinning
(replaced §3.3/D13 supersession); §4.5 bounded-warmup conservative-window recovery
(replaced §9.5; the §4.5.3 bounded-search contract survives as the bounded Phase-1
search in §9.1/AS1); §4.10/4.10.1 sequential fast path + reserved-predecessor model
(subsumed: under pins, EVERY request with a present pinned predecessor IS the fast
path); §8 phase plans and §14 implementation state (old code state — design
superseded, code state unchanged until restart coding begins); §13.18
reserved-predecessor rules (mechanism superseded, sub-rules retained per §12.3).
Old §6 counter catalogue: the accounting INVARIANTS carry (RC7, 9A.3, reservation/
pin balances); the specific counter set is re-derived by the restart coder around the
new mechanisms (§10.4/§10.5 state the required ones).
---
## 10. Constants and parameter coherence
**10.1 Sizing constants (V2/V3/V8 confirmed; carried forward from CMS06.11 with
MAX_RETAIN raised).**
```text
active_ceiling            : frame-count, derived at creation from a 1 GiB nominal
                            byte budget / estimated frame bytes, clamped
                            [MIN_HARD_CEILING=150, MAX_HARD_CEILING=1000].
                            8-bit 4:2:0 PAL 720x576 (~0.59 MiB/frame) → byte budget
                            non-binding → ceiling = 1000 (~590 MiB). Format-agnostic:
                            derives from the ACTUAL frame bytes at creation (V8).
OVERFLOW_FACTOR           = 1.1
CHECKPOINT_INTERVAL       = 10        (+ frame 0; grid promotion)
CHECKPOINT_MAX_RETAIN     = 48  (soft; raised from 32 for cut-checkpoint density)
CHECKPOINT_MIN_RETAIN     = 10
HOT_ZONE_FORWARD_RADIUS   = 10
HOT_ZONE_BACK_RADIUS      = 50
MAX_HOT_ZONES             = 5
JUMP_THRESHOLD            = FORWARD_RADIUS + BACK_RADIUS + 1 = 61   (DERIVED)
decay_margin              = 20        (NEW — Section 5.5)
K (bounded-prune victims) = 8         (NEW — Section 7.3; instrumentation-tunable)
```
**10.2 Coherence rules (CR1–CR5) — coder MUST codify each as a comment directly
above the constant's definition (per Rule 1 / Document A §A12):**
- **CR1** JUMP_THRESHOLD is DERIVED = FORWARD_RADIUS + BACK_RADIUS + 1; never set
  independently.
- **CR2** BACK_RADIUS ≥ bounded recovery search window B; ideally = B (currently
  both 50). **AND** B MUST exceed the effective settling length of the recursive
  chroma blend, so the floor-approximation fresh-start (Section 9.5) is invisible at
  N. (If B were shrunk for memory, confirm it still exceeds the blend settling
  length, or the approximate start would show at the output.)
- **CR3** BACK_RADIUS ≈ 5 × CHECKPOINT_INTERVAL (a zone covers ~5 grid anchors);
  50=5×10.
- **CR4** active_ceiling ≥ ~2 × max-protected set, where max-protected ≈
  MAX_HOT_ZONES × (BACK_RADIUS + FORWARD_RADIUS) + checkpoint pool ≈ 5×60 + 48 =
  ~348; 1000 ≫ 348. (If pruning can never reach target, this rule is violated.)
- **CR5** CHECKPOINT_MAX_RETAIN ≥ MAX_HOT_ZONES × (BACK_RADIUS / INTERVAL) = 25 grid
  checkpoints, treated as a density FLOOR (cuts add irregular checkpoints on top —
  Section 6.4). MAX_RETAIN raised 32 → 48: 25 grid floor + ~23 headroom for scene-cut
  checkpoints within the ~300-frame protected span. Content-dependent starting value;
  if cut-heavy material keeps the pool pinned at 48 with prune unable to reduce, raise
  it. MIN_RETAIN unchanged at 10.
- **decay_margin bound:** FORWARD_RADIUS ≤ decay_margin ≤ BACK_RADIUS (10 ≤ 20 ≤ 50);
  far below active_ceiling.
**10.3 MAX_HOT_ZONES = 5** scales with concurrent DISTINCT access regions, NOT thread
count. Linear pipe-to-ffmpeg uses ~1 zone regardless of threads → 5 ample. Raise only
if a scatter workload appears (raising it pushes CR4 → active_ceiling may follow).
**10.4 Instrumentation discipline.** A counter BUMP (single increment) may occur
inside a lock; FORMATTING and EMISSION (sprintf, string building, file/stderr writes)
MUST be outside the lock unless specifically justified. Emitting inside a critical
section extends it and pollutes contention measurement. Non-zero error counters are a
hard gate (D14).
**10.5 Recovery-search summary (required end-of-run diagnostic).** To measure actual
search cost (rather than rely on the design's conjectures), record per recovery
(cheap counter bumps; format/emit once at end-of-run, outside any lock):
- **Search-depth distribution** — frames walked back from N-1 before Phase 1 stopped
  (0 = predecessor present immediately = fast path). Histogram, **omit zero-count
  lines**.
- **Terminated-on** — present ordinary output / present grid-checkpoint / present
  cut-checkpoint / floor (approximate start). (Splitting grid vs cut quantifies how
  much cuts-as-checkpoints actually helps.)
- **Holes-filled distribution** — genuine holes computed by Phase 2 per recovery
  (the real recompute cost; distinct from search depth — a deep search may find most
  frames present). Omit zero-count lines.
- **Summary line** — average and max search depth; average holes filled; count and %
  of floor-approximation use.
Reading guide: depth-0 % should dominate under linear workload (low → predecessors
being pruned too eagerly → revisit hot-zone/decay sizing); floor-approximation % more
than tiny → B / lower-bound too short or cache too small. This summary, with the
K-bound prune counter (7.3) and the cut-checkpoint-evicted-while-protected invariant
(6.4), validates the tuning guesses (K=8, MAX_RETAIN=48, decay_margin=20, B) after one
real run.
---
## 11. First implementation milestone (prove ownership before behaviour — D30)
Build, against this spec and **in isolation (no VapourSynth wiring yet)**, the
cache-manager core, mirroring the staged "prove the mechanism before wiring
behaviour" discipline:
- cache-manager data structures (slot = `VSFrame*` ref + frame number + pin_count +
  is_checkpoint; ordered frame-number index per D04; non-checkpoint + checkpoint
  pools per D05; hot-zone state; per-invocation pin-list);
- single cache-wide lock skeleton + the inside/outside-lock discipline;
- pin / unpin + pin-list record/discharge + single-ownership/null-on-consume +
  discharge-before-free ordering;
- composite eviction predicate + bounded prune (decide+detach in lock, batch
  freeFrame outside, K-bound).
Prove in isolation: pin/unpin balance = 0, lookup-ref balance = 0, no leaks, no
double-free, eviction never selects a pinned/checkpoint/in-zone slot — BEFORE any
getFrame integration. Header/structure design and exact function naming are the
coder's, aligned with separation-of-responsibilities (pixel processing must not own
cache/scheduling policy; the cache manager must not contain pixel logic).
**Second step — salvage:** identify old code verifiably safe to reuse (response-table
creation, memory diagnostics, the pixel/frame-processing layer incl. the explicit-
predecessor boundary) and copy/modify from the `.txt` reference files into the new
locations, preserving separation of responsibilities.
---
## 12. Decision cross-check vs prior settled decisions (Document B)
**12.1 Carried forward UNCHANGED:** D01 (API4-only), D03 (per-instance), D04 (ordered
maps), D05 (pools own refs, index non-owning), D06 (addref under mutex — this is the
find-and-pin primitive), D07 (first-in-best-dressed), D08 (sliding zones), D09
(central remove helper), D10 (frame-count ceiling), D11 (prune before reject), D14
(diagnostics gate), D15 (zone update at arInitial), D16 (per-invocation frameData),
D26/D33 (old_strict not final authority; retire before parallel), D27/D28 (reuse
processing boundaries; no parallel pixel algorithms — override discipline), D29
(bounded-start reset semantics), D30 (compute/store/return/transfer/authority
separately provable), D31/D32 (CMS02-J0 mandatory before parallel wiring; diagnostics
consolidation), D36/D37 (sequential predecessor reuse; fast path = source N + cached
output N-1 via explicit-predecessor boundary — generalised: predecessor is PINNED).
**12.2 SUPERSEDED:** **D13** ("non-checkpoint pinning deferred") — superseded by
Position B (Section 3.3): consumer-pinning is the mandatory baseline, not a deferred
escalation. Reason: fmParallel goal + KISS/maintainability.
**12.3 Superseded IN MECHANISM, sub-rules RETAINED** (the old held-ref-only
predecessor-reservation cluster, D38–D58): the held-ref reservation MECHANISM is
replaced by consumer-pins, BUT these sub-rules survive (generalised from "the
reserved predecessor ref" to "any consumer pin"): single-ownership/null-on-consume
(D45/D53/D54 → Section 4.4); lookup-ref accounting `acquired==released+transferred`
(D55 → 4.8); ordinary refs are lookup-addref not a distinct pin-kind, don't conflate
with checkpoints (D56 → Section 6); H17 deferred (D48/D57 → 9.5); Option A (rely on
serial callback ordering) rejected (D49 → Section 3.3). The fail-closed-only H15.6B
draft stays retired (D46/D58).
---
## 12A. Failure-mode register vs the new architecture (V7 RESOLVED — bring-across proof)
CMS06.11 §1 named the failure modes the old design existed to prevent. V7 asked: does
the NEW architecture provably cover each? Mapping (this is the concrete
bring-across-and-revalidate evidence that nothing the old design guarded is lost):
- **FM1 — Prune destroys in-flight predecessor.** OLD: hot-zone heuristic + deferred
  pinning. NEW: **consumer-pins make it structurally impossible** — an in-flight
  predecessor is pinned; the eviction predicate (§7.1) never selects a pinned slot.
  This is THE reason hot zones could be demoted to decay-hints: the one failure mode
  they were load-bearing for is now covered by something STRONGER (structural, not
  heuristic). ✓ improved.
- **FM2 — Prune destroys a checkpoint needed by a recovery chain.** NEW: checkpoint
  retention flag (§6) protects future-needed anchors; an ACTIVELY-walked checkpoint is
  pinned during the walk (AS3). ✓
- **FM3 — Jump-recovery burst exceeds pool capacity.** NEW: bounded prune + K-bound
  (§7.3) + CR4 (ceiling ≥ ~2× max-protected); and the dissolved window (§9.5.1) +
  fill-holes-only shrink the burst footprint to genuine holes, not a blanket window. ✓
- **FM4 — Prune eviction key wrong (lowest-first).** NEW: evict greatest-distance-
  from-zone first (§7.1), never by frame-number magnitude. ✓ carried forward.
- **FM5 — VSFrame reference leak.** NEW: RC invariant (one addFrameRef per slot, one
  freeFrame on removal) + pin-list discharge on every exit path (§3.2/§4.6) +
  first-in-best-dressed both-branches-release (§9.3). ✓ strengthened.
- **FM6 — VSFrame use-after-free.** NEW: find-and-pin under the lock before use (AS3);
  pins keep frames alive for the consumer's whole lifetime. ✓
- **FM7 — Duplicate store overwrites / double-references.** NEW: first-in-best-dressed
  idempotent store, both branches release (§9.3). ✓ carried forward.
**V7 conclusion:** hot zones were the heuristic mitigation for FM1 (and partly
FM2/FM3). The new architecture replaces that heuristic with a structural guarantee
(pins), which is precisely why demoting hot zones to decay-hints is provably safe.
FM4–FM7 were never hot-zone responsibilities and carry forward unchanged. Every old
failure mode is covered, most of them more strongly. Also retained: the RC invariant
(CMS06.11 §2 goal 5) — exactly one addFrameRef per slot while held, one freeFrame on
removal.
---
## 12B. Root rationale — CNR3's cache replaces CNR2's predecessor approximation
The reference CNR2 source (https://github.com/Asd-g/AviSynth-vsCnr2 ;
https://raw.githubusercontent.com/Asd-g/AviSynth-vsCnr2/refs/heads/main/src/vsCnr2.cpp)
is the algorithmic ancestor of CNR3 and is prime salvage for the pixel layer. It also
makes the motivation for CNR3's entire cache+recovery architecture concrete:
CNR2 runs `MT_SERIALIZED` (single-threaded, effectively sequential) and keeps the
previous filtered output in a single `prev` member. Its `GetFrame(n)` does:
```cpp
if (last_frame != n - 1) {           // non-sequential request
    prev = child->GetFrame(n - 1);   // fetch SOURCE n-1 as an APPROXIMATE predecessor
    downSampleLuma(prevp_y, prev);
}
... blend cur with prev; prev = dst;  // sequential case uses the true previous OUTPUT
```
So when a request is NOT sequential, CNR2 cannot supply the true previous OUTPUT and
substitutes the previous SOURCE frame — an approximation it gets away with only because
it is serialized and the recursive blend forgives a one-frame stand-in.
**CNR3 deliberately abandons serialization (the final goal is fmParallel) and therefore
cannot rely on that approximation.** CNR3's cache + recovery model (Sections 9.5, 5, 6,
7) is the principled replacement: on any request, supply the EXACT previous output —
present-and-pinned, or rebuilt by the descending-search / fill-holes walk, or (only when
nothing is recoverable within the bounded floor) an explicit fresh-start that the blend
smear forgives far more comfortably than CNR2's source-substitution ever did.
**Coder consequence (stressed):** salvage CNR2's pixel maths (response tables, blend,
downSampleLuma, in-compute scene-detect — V8.1) but NOT its predecessor/recovery logic.
The `last_frame != n-1 → use source[n-1]` shortcut is exactly what CNR3 exists to
eliminate. Importing it would defeat the architecture.
---
## 13. Verify items (confirm before treating dependent sections as final)
- **V1 RESOLVED** algorithmic temporal reach backward-only / purely causal —
  confirmed by Dave against CNR2 itself (authoritative); corroborated by §A4, the
  proven CMS06.11 request window, and absence of any forward reference. Closed.
- **V2 RESOLVED** checkpoint retention params (MAX_RETAIN raised to 48, MIN_RETAIN=10)
  confirmed intended for the new architecture; cut-near-grid waste accepted (§6.5).
- **V3 RESOLVED** checkpoint establishment (every-10 grid + frame 0 + cut frames)
  confirmed intended (§6.3/§6.4).
- **V4 RESOLVED** frameData carry + cleanup confirmed against the local R76
  VapourSynth4.h: `void **frameData` (line 337) is the sanctioned carry, defaults
  NULL, ours to free before the last call / on error (`setFilterError` line 409); no
  core cleanup hook. WE manage allocation/cleanup per our discipline (Section 3.2);
  coder implements, no discretion. Per-frame-number single-threading guarantees the
  pin-list is contention-free. Cut/storage residual: none material — the header uses
  the `void **frameData` pointer form (no `void *[4]` inline variant in this header).
- **V5 RESOLVED (with firewall)** `addFrameRef`/`freeFrame` declared (lines 377–378);
  core refcount atomicity relied upon for the refcount itself ONLY. Section 8.6
  firewall: this confers NO licence to shrink any cache-lock scope (8.7 register is
  the authority). Coder may confirm atomicity but gains nothing over lock boundaries.
- **V6 RESOLVED (design position; residual is runtime-tuning only)** R76 caches
  upstream node output by default (`VSCacheMode cmAuto`; controls `setCacheMode` line
  363, `setCacheOptions` line 364, `setMaxCacheSize` line 482). So our SOURCE requests
  (including dissolved-window holes) are often served warm by the core without
  re-decode — a COST benefit, never a correctness factor. Design position: leave our
  OWN node at cmAuto and do NOT call `setCacheMode`/`cacheFrame` on it — our cache
  manager is the sole authority on OUTPUT caching; layering the core cache over our
  outputs would be a duplicative second cache. The exact upstream-cache aggressiveness
  under load is pure runtime tuning, not a design dependency.
- **V7 RESOLVED** the original failure modes are the named FM1–FM7 (CMS06.11 §1).
  Hot zones were the heuristic mitigation for FM1 (partly FM2/FM3); the new
  architecture replaces that with a structural guarantee (consumer-pins), which is why
  demoting hot zones to decay-hints is provably safe. Full mapping in §12A. Every old
  failure mode is covered, most more strongly.
- **V8.1 — PIXEL-LAYER design item (NOT a cache-manager concern; recorded here for the
  pixel-layer/salvage step, not CMS07.0 scope).** CNR3 computes in NATIVE subsampling
  at NATIVE pixel bit depth, using a WIDE (int64) arithmetic ACCUMULATOR for the
  weighted blend with the shift scaled by depth — NOT pixel promote/demote to a working
  format. This is the proven overflow-safe method in the reference CNR2 source (its
  changelog "Fixed high bit depth chroma overflow" corresponds to the int64 accumulator
  + `shift2 = depth<<1`). Restrict to YUV planar 420/422/440/444, 8..16-bit, as CNR2
  does. Reading subSamplingW/H parameterises one compute loop across subsamplings; no
  chroma-siting/resampling.
  **Reference (pixel layer salvage):**
  - repo: https://github.com/Asd-g/AviSynth-vsCnr2
  - source: https://raw.githubusercontent.com/Asd-g/AviSynth-vsCnr2/refs/heads/main/src/vsCnr2.cpp
  **ADOPT from CNR2:** the response-table construction (raised-cosine weighting from
  mode/ln,lm,un,um,vn,vm), the weighted blend formula
  `dst = (weight*prev + (shift-weight)*cur + shift1) >> shift2` with int64 weight and
  `shift2 = 2*depth`, `downSampleLuma` (2×2 box average of luma to chroma grid), and
  the in-compute scene-change accumulation/threshold. These are clean of any caching
  concern (CNR2 has no real cache).
  **DO NOT ADOPT from CNR2:** its recovery/predecessor logic. CNR2 uses
  `MT_SERIALIZED` and, on a non-sequential request (`last_frame != n-1`), fetches
  SOURCE[n-1] as an APPROXIMATE predecessor. CNR3 MUST NOT do this — CNR3 replaces that
  approximation with EXACT output[n-1] recovery via the cache (Sections 9.5 / 12B).
  Copying CNR2's `GetFrame` wholesale would import the very approximation this
  architecture exists to eliminate.
- **V8 RESOLVED for the cache (format-agnostic).** The cache stores `VSFrame`
  references and derives `active_ceiling` at filter creation from the ACTUAL frame
  byte-size, whatever the format — so the cache manager needs no knowledge of bit
  depth or subsampling. Working footprint note: 8-bit 4:2:0 PAL 720×576 ≈ 0.59
  MiB/frame → byte budget non-binding → ceiling clamps at 1000 (~590 MiB); higher bit
  depths self-adjust the ceiling downward (16-bit 4:2:0 ≈ 860 frames; 16-bit 4:2:2 ≈
  648). No `[VERIFY]` remains for the cache.
---
## 14. Changelog
**CMS07.13 (2026-06-27) — CLARIFICATION (materialized-floor-is-the-foundation); no behaviour change (D.3 already ships this); no new rule/AS-scope.**
- §9.5 floor fallback: made explicit that once the floor frame is fresh-started, stored, and pinned it IS the validated consumer foundation for the ascending walk, equivalent to a search-discovered anchor — the fill machinery validates only the structural walk contract (present pinned foundation + contiguous holes above it) and does not depend on how the foundation came to exist. Treating the materialized floor as the walk's anchor is a now-true structural fact, not a bypass. Also recorded that this floor-fresh-start SUPERSEDES the D.2-era no-in-window-anchor refusal for reachable in-range N; genuine refusal narrows to structural/impossible cases. Proven live by D.3 (floor-fresh-start output[3]=144/113, recover_branch=floor-fresh-start floor=0 floor_outcome=computed; floor byte 56/176 proving fresh-start chroma-unchanged). This documents in the design authority the same reasoning the D.3 patch carries in-code at the anchor relabel.
- **Clarification only.** No design rule, decision, constant, AS scope, or section number changed or removed; recovery behaviour is exactly as built and committed in D.1/D.2/D.3.

**CMS07.12 (2026-06-27) — CLARIFICATION (bounded-search report semantics); no behaviour change (D.2 already ships this); no new rule/AS-scope.**
- §9.5 Phase 1: made the bounded-search REPORT semantics explicit (normative for recovery refusal): the descending search reports presence only within its window [max(0,N-B), N-1]; "no in-window anchor" is a single state that does NOT distinguish "an older present output beyond the window" from "no prior output at all" (distinguishing them needs an unbounded scan the bound exists to avoid). A recovery refusal reports no-in-window-anchor and must not claim the bounded-window-exceeded-vs-no-prior distinction; a caller needing it proves it by construction/context. Also corrected the bounded anchor-search interval upper bound from [max(0,N-B), N] to [max(0,N-B), N-1] (the requested frame N is the target, never an anchor candidate). Raised as a charter CMS-GAP candidate during D.2 review and confirmed; proven live by D.2's bounded-window refusal (RUN C, no-in-window-anchor). Relevant to D.3 (floor-fresh-start is the same no-in-window-anchor boundary).
- **Clarification only.** No design rule, decision, constant, AS scope, or section number changed or removed; the recovery behaviour is exactly as built and committed in D.1/D.2.

**CMS07.11 (2026-06-27) — GOVERNANCE addition; adds §0A (Design Alignment and Escalation Charter); no design rule/decision/constant/AS-scope/section-number changed or removed.**
- Added **§0A** — the three-way (designer/reviewer, coder, coordinator) Design Alignment and Escalation Charter: CMS is the controlling guide and strict alignment is the default; two issue types are surfaced rather than routed around silently — RULE-DEVIATION (a named CMS rule, if followed, would be wrong/inconsistent/unsafe — HIGH bar, CMS07.10-correction-level evidence) and CMS-GAP (a bigger-picture/fmParallel/reliability/safety concern with little or no correspondence to a specific rule — encouraged, low bar, may call for a new/revised rule); on either, work on the affected change pauses, resolved by designer+coder agreement with coordinator approval, recorded durably before/as part of the implementing commit; cross-checking is bidirectional (designer read-firsts diffs + recomputes goldens; coder checks scope against code reality); weight scales to risk; concurrency reasoning for the fmParallel goal is recorded at design time. Reproduced identically in Production Spec §3A.5.0 and Role Handover §D0.
- **Governance only.** No change to §1–§13, §9A, the constants/CR1–CR5, the AS register, or any V-resolution. The charter governs how the CMS is *used*; it asserts nothing about cache/recovery behaviour.

**CMS07.10 (2026-06-25) — CORRECTION to §9A.1.1 (R-LIFECYCLE); proven live by keystone K.1F.**
- §9A.1.1 previously stated the branch-(b) cache-hit activation "requests nothing ... and returns NULL" at arInitial. K.1F investigation established that a ZERO-request arInitial→NULL is NOT guaranteed an arAllFramesReady callback under API4/R76, so that statement was unsafe to implement literally. Added **R-LIFECYCLE**: every CNR3 getFrame branch requests at least one REAL source frame at arInitial and returns only at arAllFramesReady; the branch-(b) cache hit requests source[N] as a lifecycle TRIGGER (Option C), pins output[N] across the gap, retrieves-and-frees the trigger source (not consumed), returns the pinned cached frame at arAllFramesReady via lookup-and-add-ref + AS4 batch discharge. Rejected as unverified-for-non-source-under-fmParallel: (A) return-at-arInitial, (B) zero-request-then-return. Recorded the honest cost (a cache-hit return can be blocked by a source[N] failure) and the frameData-branch-tag dispatch discipline (act-time dispatch keyed on the arInitial-set tag, never on re-inspecting frame state). This is a CORRECTION of a previously-stated arInitial behaviour, not purely additive; the request-in-arInitial / return-in-arAllFramesReady contract and all other §9A.1.1 text stand. Proven live: K.1F harness, Debug+Release, branch=CACHE-HIT returns output[2]=128/163/93 with no compute, core cache defeated via SetVideoCache(mode=0), balanced pin/trigger/return ledgers; repeated-frame-0 proves present-N dispatch precedes the n==0 gate; four-way selftest unchanged 49/49.

**CMS07.9 (2026-06-24) — additive revision; one new subsection (§9.6.5); no rule/decision/constant/section-number removed.**
- Made the per-hole **pre-compute adopt-and-skip** check NORMATIVE in **§9.2** (ascending recovery fill): before computing a recovery hole K, under the cache lock check whether output[K] is already present; if present, pin-and-record and SKIP the compute and store; only if absent, compute outside the lock and proceed to the existing AS2 store-and-pin with first-in-best-dressed. Consolidated as new **§9.6.5**, which also states the correctness-vs-efficiency relationship: the POST-compute first-in-best-dressed path (§9.3, since CMS07.1) already guarantees CORRECTNESS under concurrency; the PRE-compute check adds EFFICIENCY by avoiding redundant full-frame recompute of holes a concurrent activation filled during the arInitial→arAllFramesReady gap — expected and frequent under fmParallel and under two interlaced single-field instances each running fmParallel.
- Clarified **§9.6.2** and the **§8.7 AS3 STATUS NOTE** to separate two things earlier wording conflated: the DEFERRED item is the PLANNER extension to sparse reused-intermediate frames (no such plan shape under the current contiguous-hole planner; awaits a future approved sparse-plan revision); the NORMATIVE item (CMS07.9) is the AS3 find-and-pin PRIMITIVE applied at fill act-time (the §9.2/§9.6.5 pre-compute check). The old "AS3 has no reachable trigger" statement was correct only about the planner extension and only at plan time; it never denied the act-time gap-fill race, which §9.6.3 Category A always recognised as expected.
- Made the **§9.1 AS1 start-point-pin fmParallel rationale** explicit: planning (arInitial) and acting (arAllFramesReady fill) are separate atomics with a gap; pinning the start point/anchor inside the AS1 atomic is what prevents a concurrent prune from evicting the plan's foundation during that gap (prune never selects a pinned slot). This is a rationale for the existing AS1 pin requirement, not a new requirement.
- Recorded in the **§8.7 AS4 entry** the ruled resolution of the discharge_all wording-vs-code discrepancy: add a single-lock batch discharge (one `cache_mutex_` acquisition, unpin every token via `unpin_frame_locked`, reset) so AS4 is one lock for the whole list as the register specifies; owed as recovery-step-0, under R-PROCESS-21 (proven-code change requires explicit proposal + approval + selftest). freeFrame stays outside the scope; per-exit-path leak-safety (§4.6) preserved.
- **Additive only.** No design rule, decision, constant, AS scope boundary, or section number is changed or removed. The pre-compute check is the AS3 find-and-pin primitive (§8.7) applied at act time — it adds no new atomic-scope and changes no existing one. §9.6.5 is the only new subsection; §9.2/§9.6.2/§9.1/§8.7 receive additive clarifications. All of §1–§9.7.7, §9A, §10–§13, the constants/CR1–CR5, and V1–V8 stand as in CMS07.8.

**CMS07.8 (2026-06-23) — additive revision; no rule/decision/constant/section-number changed or removed.**
- Added **§9.7.7 Source-input dependency declaration — rpGeneral, not rpStrictSpatial**, a normative decision for the keystone's registration step: the source-input dependency is declared `rpGeneral` because bounded recovery (§9.5/§9.7.2) requests source N PLUS the sources for the genuine output holes (§9.5.1 — a sparse earlier-source set), so `rpStrictSpatial` ("only input N for output N") would misdeclare the filter to the engine once recovery is live; `rpGeneral` is conservative-correct. The subsection also records the ORTHOGONALITY of `requestPattern` (the `rp*` enum) and `filterMode` (the `fm*` enum, §2): declaring `rpGeneral` does NOT change `fmUnordered` / the `fmParallel` goal and does NOT touch the CMS7 OUTPUT cache or any correctness property in §3–§9.7.6 — it concerns only the engine's caching of our INPUT requests (cost/scheduling, never correctness). This **resolves companion investigation FI-04**.
- Added **§9A.1.1 arInitial vs arAllFramesReady — the frame-RETURN contract**, a hard-API sibling to VS-LIFECYCLE-01 (§9A.1): CNR3 is a dependency filter (it has an input node), so it requests inputs and returns NULL at arInitial and RETURNS its output frame at arAllFramesReady; the "return directly from arInitial" pattern is the source-filter exception and does not apply. Clarifies that §9.7.1 branch (b) (cached output returned directly) still occurs through the normal arInitial-request-nothing / arAllFramesReady-return cycle. Verified against the local R76 VapourSynth4.h activation-reason contract.
- **Provenance note (no existing text changed):** the recovery-plan contiguity guard whose guardrails §9.6.4 says are proven at the aggregate proof (CMS07-C.14A) was INTRODUCED as its own phase at CMS07-C.13B and EXERCISED at C.14A; §9.7.4 (added at CMS07.7) already refers to it as "the C.13B guard." Recorded here for provenance; §9.6.4's existing text stands unchanged.
- **Additive only.** No design rule, decision, constant, AS scope, or section number is changed or removed. §1–§9.7.6, §9A.1, §9A.2–§9A.10, and §10–§13 (including §6.6, §9.3, §9.5/§9.6, the §10.x constants and CR1–CR5, the AS register, and all V1–V8 resolutions) stand exactly as in CMS07.7. The only body additions are the two new subsections §9.7.7 and §9A.1.1.
- Companion `CNR3_CMS_Future_Investigations_and_Open_Questions_v7.8.md` is the version-paired companion (restoring the §CMS07.2 pairing rule). FI-04 is now resolved into this CMS (§9.7.7) and should be marked resolved in the companion; the companion's remaining open items (e.g. FI-01 FORWARD_RADIUS tuning, FI-02 sparse-plan recovery, and the CR2 settling-length / CR4 active_ceiling-clamp coherence investigations) carry forward unchanged and non-normative.
### CMS07.7 — 2026-06-21 (additive consolidation: keystone predecessor-sourcing)
- Added **§9.7 Predecessor sourcing for the keystone** — a non-normative consolidation that collects the existing predecessor-sourcing decision (distributed across §4.8, §6.3-§6.6, §9.1-§9.3, §9.5-§9.5.1, §9.6, §9A.7) into one findable place from the getFrame keystone's point of view, with pointers to each owning section. Added because the keystone implementation re-opened several already-decided points (cold-seek policy, scene-reset checkpointing, the recovery request set, the planner shape) as if undecided; §9.7 prevents recurrence. §9.7 changes no rule, decision, constant, or section number; the owning sections remain authoritative. §9.7.2 in particular surfaces (from §9.5/§6.3/§10.2) that recovery uses ONE bounded backward search to floor N-B (B=BACK_RADIUS=50), takes the first present output (checkpoints not preferred, only retained-and-therefore-likely-present in cold regions), and that CR3 (BACK_RADIUS ~= 5 x CHECKPOINT_INTERVAL) sizes the bound so the exact path is the common case and the floor fresh-start the rare fallback.
- Companion `CNR3_CMS_Future_Investigations_and_Open_Questions_v7.7.md` records two deferred coherence-rule investigations surfaced while preparing §9.7 (CR2 settling-length measurement; CR4 active_ceiling lower-clamp tension). These are NON-NORMATIVE, change no CMS rule, and are to be resolved with the behavioural review at first real .vpy runs.
### CMS07.3 — 2026-06-19 (additive clarification: current minimal recovery path + AS3 deferral)
- **NEW §9.6** clarifying that the currently proven/active recovery correctness path is the
  nearest-present-start-point + contiguous-hole subset (start-point pin-record from AS1,
  proven at H.2A; contiguous planned holes consumed through AS2, proven at H.3A; requested
  frame N handled separately by later return/output authority). Establishes that no
  reused-intermediate-distinct-from-start-point-and-holes state is reachable under this
  planner, so the AS3 atomic is RESERVED but DEFERRED and must not be implemented against an
  unreachable synthetic plan shape, nor the planner extended to sparse reused-intermediate
  frames, without a future separately approved sparse-plan / recompute-avoidance CMS revision.
- **NEW §9.6.3 two-category distinction.** Category A — a planned hole that became present
  before this activation's AS2 store — is EXPECTED fmParallel-class concurrency handled by
  AS2 first-in-best-dressed duplicate/adopt (existing winner authoritative, incoming
  duplicate freed, winner pinned, one pin recorded; proven at H.3A); it is correctness-
  complete, not a failure, must not abort, must not emit a user-visible error, and may be
  ordinary telemetry later. Category B — a non-contiguous reused-intermediate shape under the
  contiguous-hole planner — is IMPOSSIBLE / design-drift; it must be detected and rejected by
  hard status (`invariant_violation` / `lifecycle_violation`), never silently accepted.
- **NEW §9.6.4 developer-alert principle (forward-looking).** Category-B detection is
  status-return-based in the cache core now (no printing); the guardrails are to be proven in
  the aggregate proof (C.14A); the user-visible developer-alert is FUTURE integration/error-
  mapping work (not a current cache-core requirement) and, when built, must be a bounded
  one-shot/rate-limited stderr-only report outside all locks, reproduction-useful, reserved
  for Category-B states, never emitted for Category-A. Exact alert fields deferred to
  implementation.
- **STATUS NOTE on the AS3 register entry (§8.7)** recording the same deferral inline.
- **Additive only.** No design rule, decision, constant, AS scope, or section number is
  changed or removed. §6.6, §9.1–§9.5, §9.3 first-in-best-dressed, the §10.x constants and
  CR1–CR5, the AS register entries themselves (AS3's behaviour is unchanged — only annotated
  as deferred), and all V1–V8 resolutions stand exactly as in CMS07.2.
### CMS07.2 — 2026-06-17 (additive: companion-document reference)
- **NEW front-matter note** declaring the non-normative companion document
  `CNR3_CMS_Future_Investigations_and_Open_Questions_vXX.Y.md`, which is version-paired
  with this CMS (always the identical version number, carried in its filename). The
  companion records deferred design questions and open tuning investigations; it is NOT
  part of this specification, NOT controlling, and NOT part of the coder handover pack,
  and nothing in it is implemented without formal prior approval and a corresponding CMS
  revision.
- **Additive only.** No design rule, decision, constant, AS scope, or section number is
  changed or removed. §6.6, §9.3, the §10.x constants and CR1–CR5, the AS register, and
  all V1–V8 resolutions stand exactly as in CMS07.1. The companion note lives in the
  front matter; the normative body is unchanged.
- **Pairing rule (recorded for maintenance):** when this CMS is next bumped, the
  companion is re-issued at the identical new version number even if its content is
  unchanged (filename-only re-version). The first companion content item is FI-01,
  FORWARD_RADIUS tuning for higher thread counts.
### CMS07.1 — 2026-06-17 (additive clarification of CMS07.0)
- **NEW §6.6 — checkpoint flag is monotonic under duplicate stores.** Resolves a
  silence in CMS07.0: §6.3 requires *every* detected cut frame to become a checkpoint,
  but §6 did not state what happens to the checkpoint flag when a duplicate store
  arrives for a frame number already present (the out-of-order case: a frame cached as
  ordinary *before* the activation that detects its cut). §6.6 makes the flag
  monotonic — first-in-best-dressed governs the frame DATA, while the checkpoint FLAG
  may be RAISED (promote a present non-checkpoint slot on a checkpoint-eligible
  duplicate store) but NEVER CLEARED (no demotion). The flag-set is folded into the
  existing AS2 store atomic (§8.7); no new lock scope.
- **§9.3 cross-reference added** pointing to §6.6 so the first-in-best-dressed and
  checkpoint-flag rules are explicitly consistent.
- **Correctness-neutral / additive only.** Verified against §9.5: the Phase-1
  descending search treats the checkpoint flag as retention-only ("the first present
  frame wins"), so the prior absence of a promotion rule was an EFFICIENCY gap
  (under-retained cut anchors → more recomputation), never a correctness gap.
  Promotion restores the intended retention without affecting output. No existing
  rule, decision, constant, AS scope, or section number is changed or removed; §6.1–
  §6.5, §9.3 winner/loser semantics, and all V1–V8 resolutions stand unchanged.
### CMS07.0 FINAL — 2026-06-13 (promotion from CMS07.0a)
- **Section-level bring-across audit of the CMS06.11 body completed (§9A)**, treating
  CMS06.11 as INDICATIVE (gap-finder), not definitive. Carried forward and
  re-validated: VS-LIFECYCLE-01 full statement (9A.1); RC1–RC8 reference-count
  discipline, obligations mandatory / helper names indicative (9A.2); ceiling
  derivation formula with the 720-vs-1440 disambiguation (9A.4); hard-ceiling abort
  policy + error message, now also a CR4-violation signal (9A.5); failure-path
  cleanup discipline, simplified by the pin-list (9A.6); bounded-start honesty
  durable rule (9A.7); Design Compliance Review process + 17-item adapted checklist,
  item 17 new: critical sections must match the AS register (9A.8); FORWARD_RADIUS
  empirical basis citation (9A.9). Superseded-not-carried material listed (9A.10).
- **RAII owned-ref wrapper UPGRADED from recommended to BASELINE (9A.3)** — the
  restart removes the legacy-code constraint that justified deferral.
- Stale `[VERIFY]` markers cleared from §6.3 and §10.1 (the underlying items were
  resolved earlier in §13 but the body annotations lagged — caught by self-review).
- §15 rewritten from open-items to completion status. Header promoted to final.
- Deliberately out of scope: handover pack bump (deferred by explicit decision);
  pixel-layer spec (V8.1 guidance in §13 feeds that separate workstream).
### CMS07.0a — 2026-06-12 (working draft increment)
- **V1 RESOLVED:** algorithm confirmed purely causal against CNR2 (current source +
  previous output; no forward peek). `[VERIFY]` dropped from Section 1.
- **Recovery model rewritten (Section 9.5):** two-phase — Phase 1 DESCENDING search
  from N-1 for the nearest present cached output (start point; checkpoint flag
  irrelevant at search time), bounded to `[max(0,N-B), N]`; Phase 2 ASCENDING
  fill-holes-only (reuse every present frame, compute only genuine holes).
- **Dissolved source window (Section 9.5.1):** the old blanket `[max(0,N-B), N]`
  source-request window is GONE. arInitial requests source N + sources for genuine
  holes only. The old "H17 sparse-hole" efficiency becomes the baseline (pins make it
  safe). H17-as-deferred-item retired.
- **Floor fallback (Section 9.5):** D29 approximate fresh-start confirmed; justified
  by recursive-blend smear/decay; CR2 extended — B must exceed blend settling length.
- **Scene cuts (Sections 1, 9.2, 6.4):** detection runs during compute; a cut is an
  in-walk fresh-start that severs the chain; cut frames are promoted to checkpoints
  (irregular spacing — search is position-agnostic, D04); grid promotion retained
  alongside; absorbs the deferred "remember cut positions" idea.
- **CHECKPOINT_MAX_RETAIN 32 → 48** for cut-checkpoint density; CR5 reframed as a
  density floor; CR4 max-protected updated to ~348.
- **V2/V3 RESOLVED:** INTERVAL=10, MIN_RETAIN=10, MAX_RETAIN=48 confirmed for the new
  architecture; cut-near-grid near-duplicate checkpoints accepted as harmless (§6.5,
  no suppression logic).
- **Recovery-search summary instrumentation added (§10.5):** depth distribution,
  terminated-on (ordinary / grid-cp / cut-cp / floor), holes-filled distribution,
  averages — end-of-run, zero-count lines omitted — to validate tuning guesses on real
  runs.
- **V4 RESOLVED** against the local R76 VapourSynth4.h: frameData is the sanctioned
  carry, manually managed by us, no core cleanup hook; coder implements our discipline
  with no discretion (§3.2). Per-frame-number single-threading guarantees pin-list
  contention-freedom. Noted we deliberately do NOT use the core `cacheFrame` API.
- **V5 RESOLVED with a firewall (§8.6):** core refcount atomicity is relied upon for
  the refcount only and confers NO licence to shrink/split any cache-lock scope —
  framed explicitly to prevent the coder mistaking refcount atomicity for permission
  to take pins outside the lock (which would reintroduce TOCTOU).
- **Atomic-scope register added (§8.7):** AS1–AS7, designer-owned, mandatory,
  boundaries inviolable — the single authority on critical-section contents; the coder
  implements exactly and may not shrink/split/merge a scope without designer agreement.
- **V6 RESOLVED:** engine caches upstream sources by default (cmAuto); cost not
  correctness; leave our node at cmAuto, do not layer the core cache over our outputs.
- **V7 RESOLVED:** FM1–FM7 failure-mode register added (§12A) mapping each old failure
  mode to the new architecture; hot-zone demotion proven safe (FM1 now structural via
  pins, not heuristic).
- **V8 RESOLVED for the cache (format-agnostic; ceiling self-derives).** V8.1 recorded
  as a PIXEL-LAYER item (compute native-subsampling at widened bit depth, parameterised
  by format descriptor; compare to CNR2 source) — out of CMS07.0 cache scope.
- **ALL VERIFY ITEMS V1–V8 NOW RESOLVED.** Remaining for CMS07.0-final: section-level
  bring-across audit against the CMS06.11 body (no still-valid mechanism detail lost).
- **CNR2 reference source checked** (Asd-g/AviSynth-vsCnr2). Confirms: purely causal
  (`prev` is the previous OUTPUT); native-subsampling native-bit-depth compute with an
  int64 blend accumulator and `shift2 = 2*depth` (the "high bit depth chroma overflow"
  fix) — adopted as the V8.1 pixel-layer method; response tables / blend / downSampleLuma
  / in-compute scene-detect are salvage material. §12B added: CNR3's cache+recovery is
  the principled replacement for CNR2's serialized `last_frame!=n-1 → source[n-1]`
  predecessor approximation. STRESSED: salvage CNR2 pixel maths, NOT its recovery logic.
  Source links recorded in §1, §12B, §13 V8.1.
### CMS07.0 — 2026-06-12
Architectural supersession of CMS06.11. Pinning becomes the mandatory correctness
mechanism (consumer-pins); hot zones demoted to decay-hints over a pinned liveness
index; checkpoints become a flag + retention rule, not a pin; single cache-wide lock
held minimally; bounded prune (decide+detach in lock, freeFrame outside, K=8); new
constants decay_margin=20 and K=8; five parameter-coherence rules (CR1–CR5) to be
codified as code comments; fmParallel final-goal invariant stated outright. D13
superseded; held-ref-only predecessor-reservation cluster superseded in mechanism
with sub-rules retained; foundational decisions D01–D11/D14–D16/D26–D33/D36–D37
carried forward. DRAFT: sections dependent on V1–V8 marked `[VERIFY]`.
---
## 15. Completion status
Originally a DRAFT open-items list; now the closure record.
- V1–V8: ALL RESOLVED (§13) — V1/V8.1 against the CNR2 reference source, V4/V5/V6
  against the local R76 VapourSynth4.h header, V2/V3/V8 by design confirmation, V7 by
  the FM1–FM7 mapping (§12A).
- Section-level bring-across audit against the CMS06.11 body: DONE (§9A) —
  CMS06.11 treated as INDICATIVE gap-finder; carried rules re-validated against the
  new architecture (RC1–RC8, VS-LIFECYCLE-01, abort/cleanup/shutdown, bounded-start
  honesty, DCR process, ceiling formula); RAII wrapper upgraded to baseline;
  superseded material listed (§9A.10).
- Keystone consolidation: §9.7 (CMS07.7) collects the predecessor-sourcing decision in
  one place; §9.7.7 (CMS07.8) records the `rpGeneral` source-input dependency
  declaration (RESOLVES FI-04 — `rpGeneral` conservative-correct, orthogonal to
  `filterMode`); §9A.1.1 (CMS07.8) records the arInitial/arAllFramesReady frame-return
  contract (dependency filter returns at arAllFramesReady; source-filter-return-from-
  arInitial exception does not apply). Companion re-paired to v7.8.
- Final self-review pass: DONE (stale `[VERIFY]` markers cleared; version strings,
  cross-references, and old-concept references checked).
- NOT in this document's scope (separate deliverables): the matched handover pack
  bump (A/B/C → "CMS07.0-or-later", per the Handover Pack Production Spec) — deferred
  by explicit decision; the pixel-layer specification (V8.1 guidance recorded in §13
  for that workstream).
