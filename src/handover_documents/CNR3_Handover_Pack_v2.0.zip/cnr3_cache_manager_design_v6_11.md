# CNR3 Cache Manager — Revised Design Specification CMS06
## Sliding Hot-Zone Pruning with Reference-Count Discipline (Non-Checkpoint Pinning Deferred)

**Date:** 2026-06-11
**Version:** CMS06.11
**Status:** Design specification — ready for coding
**Supersedes:** CMS06.11 supersedes CMS06.10, CMS06.9, CMS06.8, CMS06.7, CMS06.6, CMS06.5, CMS06.4, CMS06.3, CMS06.2, CMS06.1, CMS06, CMS05.2b, CMS05.2, CMS05.1, CMS05, CMS04, CMS03, CMS02, CMS01
**Also supersedes:** Bounded-recovery policy in handover snapshot v0.14 section 0.9A
**Companion documents:**
- CNR3_Handover_Snapshot_v0.14 (for infrastructure already built)
- cnr3_code_review_plan_v5_1.md (code review and simulation plan)

---

## Changelog

### CMS06.11 — 2026-06-11

Clarification and proof-audit pass over CMS06.10. No design reversals; one
correctness fix to stale body wording, the rest are tightening and
anti-regression guards requested during implementation review before
H15.6B.1 coding.

**CMS06.11-1 — Stale H15.6/H15.7 body wording corrected (Section 2.3 and
Section 8).** The Section 2.3 VS-LIFECYCLE-01 discussion still carried the
superseded two-phase "H15.6 probe / H15.7 active reduction" sequence in its
body, which contradicts the controlling H15.6A / H15.6B.1 / H15.6B.2 /
H15.6B.3 split (CMS06.9, CMS06.10). The body sequence is replaced with the
current split. Historical changelog entries for CMS06.8/CMS06.9 that
reference the old H15.6/H15.7 plan are left intact as accurate history. The
stale "H15.6 is the next recommended phase" line in Section 8 is corrected
to H15.6A. This is the one must-fix correctness item in this pass.

**CMS06.11-2 — H15.6B.3 source-reduction eligibility rule added
(Section 13.18, Rule 13.18.5).** A frame is source-reduction eligible only
if `arInitial` successfully acquired and stored a reserved predecessor ref
for `output_cache[N-1]`. A cache-contains check or any non-owning
observation that `N-1` exists is explicitly insufficient. This prevents
reverting to the TOCTOU-prone contains-then-reduce logic.

**CMS06.11-3 — Named frameData release helper specified (Section 13.18,
Rule 13.18.2).** `cnr3_output_cache_authority_release_reserved_predecessor_ref()`
(or the currently named equivalent) is specified with idempotent
null-guard behaviour: the null field is the idempotency guard, so the
helper is safe to call more than once. Counter attribution is corrected so
`reserved_predecessor_released_by_cleanup` increments only on the cleanup
path, not when the same release logic is reached via successful
consumption (which increments `reserved_predecessor_consumed`).

**CMS06.11-4 — H15.6B.2 PASS evidence fields strengthened (Section 8).**
Explicit required proof fields added for the consumed path
(`reserved_predecessor_field_null_after_consume=1`,
`reserved_predecessor_double_release_prevented=1`) and the unconsumed/error
path (`reserved_predecessor_released_by_cleanup=1`,
`reserved_predecessor_field_null_after_cleanup=1`). Makes it hard to pass
H15.6B.2 while leaking or double-releasing.

**CMS06.11-5 — Reserved refs tied into the existing caller-side lookup-ref
invariant (Section 6, Section 13.18 Rule 13.18.6).** Reserved predecessor
refs are not a separate ownership universe. Acquisition increments
`lookup_owned_ref_acquired_total`; release (consume or cleanup) increments
`lookup_owned_ref_released_total`. The reserved predecessor is an input,
not the returned frame, so it is **released, not transferred** in H15.6B.1
and H15.6B.2. The existing invariant
`acquired == released + transferred` continues to hold.

**CMS06.11-6 — Reserved predecessor refs use lookup-addref, not pinning
(Section 13.18 Rule 13.18.7).** H15.6B predecessor reservation must not
introduce checkpoint pin or non-checkpoint pin activity for ordinary cached
predecessor frames. Checkpoint pin/unpin proof remains mandatory for
checkpoint/recovery anchors only.

**CMS06.11-7 — H17 minimal sparse-hole repair recorded as deferred
(Section 13.19).** A future optimisation of the fallback recovery path
(start from nearest suitable cached predecessor/checkpoint in the bounded
window, fetch only missing source frames, compute/store only missing
outputs) is recorded as an explicitly deferred named item so the intent is
not lost. Marked deferred; it must not contaminate H15.6B.

**CMS06.11-8 — Superseded-draft warning mirrored into Section 8.** The
retirement of the fail-closed-only H15.6B draft patch (CMS06.10-9) is now
also stated at the H15.6B phase header, because coders frequently read
Section 8 before the changelog.

### CMS06.10 — 2026-06-11

**CMS06.10-1 — H15.6B predecessor-reservation model adopted (Option B);
TOCTOU gap closed.** H15.6B as previously sketched would check
`output_cache[N-1]` in `arInitial`, reduce the source request to source N
only, then look `N-1` up again in `arAllFramesReady`. That creates a
time-of-check/time-of-use gap: if `N-1` is removed between the two
callbacks, the bounded-warmup fallback would need source frames that were
never requested in `arInitial`, violating VS-LIFECYCLE-01 (Section 2.3).
The settled mechanism instead acquires a caller-owned reference to
`output_cache[N-1]` atomically in `arInitial` via
`cnr3_output_cache_find_frame_and_add_ref()`, carries it in the
per-invocation `frameData`, and consumes it in `arAllFramesReady`. The
held reference keeps the predecessor VSFrame alive even if its cache slot
is pruned in the gap (Appendix B load-bearing property), so the predecessor
is guaranteed valid regardless of scheduling mode. See new Section 4.10.1
and Section 13.18.

**CMS06.10-2 — `frameData` reserved-predecessor ownership rule added
(Section 13.18).** The per-invocation `frameData` source-plan object
currently owns only plan metadata; its destroy helper may `delete` the
plan with no `vsapi` involvement. Once it carries a reserved predecessor
`VSFrame*`, it becomes an owner of a caller-owned VapourSynth reference,
and RC5 (Section 2.2) plus the ownership-and-release-balance durable rule
(Section 13.13) apply to it. The `frameData` destroy/release path must be
upgraded to release a non-null reserved predecessor ref with `freeFrame()`
and record `cnr3_output_cache_note_lookup_ref_released()` on every exit
path before Option B is safe. This is a first-class precondition and proof
target, not incidental cleanup.

**CMS06.10-3 — Single-ownership / null-on-consume rule formalised
(Section 13.18).** The reserved predecessor ref is owned by `frameData`
until consumed. Successful consumption in the fast path must release it (or
transfer ownership as designed) and then set the `frameData` field to
nullptr. `frameData` cleanup releases the ref only if the field is still
non-null. This prevents both double-release (fast path releases, then
cleanup releases again) and leak (fast path assumes cleanup will release;
cleanup assumes fast path consumed). This is a formal proof requirement of
H15.6B.2.

**CMS06.10-4 — H15.6B restructured into H15.6B.1 / H15.6B.2 / H15.6B.3.**
The single H15.6B sub-phase is replaced by a three-way split separating
(1) reservation carry lifecycle, (2) consumption of the carried ref as the
fast-path predecessor, and (3) the actual source-request reduction. This
keeps frame-ownership lifecycle, predecessor-sourcing behaviour, and
source-request behaviour each separately provable (durable rule 13.14). The
H16.3 fallback-proof precondition on source-request reduction is retained
and now attaches to H15.6B.3. See Section 8.

**CMS06.10-5 — Section 4.10 fast-path operation: reserved-predecessor
variant added (Section 4.10.1).** The H15.5 fast-path operation (which
looks `N-1` up in `arAllFramesReady`) remains the accurate description of
currently committed behaviour. Section 4.10.1 adds the forward
reserved-predecessor operation that H15.6B.2 onward will prove, in which
the predecessor is sourced from the carried `frameData` ref and the
`arAllFramesReady` re-lookup of `N-1` is eliminated.

**CMS06.10-6 — Option A (reliance on serial callback ordering) recorded as
rejected alternative (Section 13.18).** Relying on same-instance serial
callback ordering to guarantee `N-1` survives the gap is correct only under
fmUnordered and is exactly the kind of serial-order assumption Sections
13.17 and 14.6 prohibit. It would break silently at CMS02-J. Recorded as
rejected so a future chat does not resurrect it.

**CMS06.10-7 — Reservation/loss counters specified (Section 6).** New
counters: `reserved_predecessor_acquired`, `reserved_predecessor_consumed`,
`reserved_predecessor_released_by_cleanup`, `reserved_predecessor_expected`,
`reserved_predecessor_present`, and the loss counter
`reduced_fastpath_predecessor_lost`. The loss counter must read 0 in all
H15.6B evidence; non-zero is a discipline-failure invariant breach and
prints a prominent warning regardless of diagnostic gate setting, in the
same policy tier as `predecessor_missing_when_expected`.

**CMS06.10-8 — Fail-closed guard demoted to invariant-breach diagnostic.**
The earlier fail-closed-on-missing-predecessor behaviour is no longer the
design mechanism. With reservation in place the original TOCTOU race is
structurally closed under all modes, so the fail-closed branch becomes an
unreachable diagnostic: if reached, it signals a lost owned ref or a failed
`frameData` carry (`reserved_predecessor_expected=1`,
`reserved_predecessor_present=0`, `reduced_fastpath_predecessor_lost=1`,
`proof_ok=0`), not expected operation. See Sections 4.10.1 and 13.18.

**CMS06.10-9 — Prior fail-closed-only H15.6B draft patch retired.** The
fail-closed-only patch produced before this ruling is a superseded draft
and must not be committed. H15.6B coding starts from H15.6B.1 against this
spec. (This is an implementation-state/decision-log fact mirrored in
handover Document B; recorded here for design-authority completeness.)

### CMS06.9 — 2026-06-11

**CMS06.9-1 — Forward phase plan refined: H15.6 split into H15.6A/H15.6B;
H16.1–H16.4 added.** The previous H15.6 (probe) / H15.7 (active reduction)
sequence was too aggressive: it would reduce arInitial source requests
before the predecessor-missing fallback case is proven, risking
under-requesting source frames for a fallback path (VS-LIFECYCLE-01). The
revised sequence interposes safety. See Section 8.

**CMS06.9-2 — H15.6A request classification probe (no behaviour change).**
arInitial must be able to classify each request as frame-0,
sequential-fast-path candidate, predecessor-missing/fallback, or
non-sequential/uncertain — keeping the conservative bounded-warmup window
for everything except proven fast-path frames. See Section 8.

**CMS06.9-3 — H15.6B narrow active reduction (fast-path-eligible only).**
Source-request reduction (request only source N) applies only to frames
classified as sequential fast-path eligible. All other classes keep the
bounded-warmup source window. See Section 8.

**CMS06.9-4 — H16.1/H16.2 close the H2A/H2B obligations.**
The bounded checkpoint-search contract (Section 4.5.3) remains settled
design authority but was not closed as an implementation/proof item. H16.1
(contract closeout) and H16.2 (helper proof) carry the original H2A/H2B
obligations under renamed labels. H2A/H2B are marked superseded-by-H16.1/
H16.2. See Section 8 and Section 14.1.

**CMS06.9-5 — H16.3 predecessor-missing fallback return-transfer proof.**
The case N > 0 with `output_cache[N-1]` missing — fast path declines,
fallback computes/recovers output N, stores it, looks it up, transfers it
as the returned frame, without mutating old strict state — is not yet
proven in the selected output-authority path. H16.3 proves it. See
Sections 4.10 and 8.

**CMS06.9-6 — H16.4 out-of-order fallback validation.**
Out-of-order patterns (e.g. [1,0,3,2], [0,2,1,3], [5,0,1,2]) validate that
fast path returns when `output_cache[N-1]` exists and fallback returns
(not old strict) when it is missing. See Section 8.

**CMS06.9-7 — Proof-coverage scope note added (Section 4.10).**
The sequential fast path is proven through H15.5 for the hot sequential
case. The predecessor-missing fallback case is settled by design but not
yet proven; it is covered by H16.3/H16.4. Active source-request reduction
must not precede that fallback proof.

### CMS06.8 — 2026-06-11

**CMS06.8-1 — CMS02-H6 through H15.5 implementation progress recorded.**
H6 through H8 proved bounded-warmup store, return-decision, and
return-transfer mechanics. H9 integrated output-cache authority. H10–H13
quarantined old strict state and old strict streaming gates from selected
output authority. H14.1–H14.5 normalised selected output-cache authority
naming and labels. H15.1–H15.5 proved and then activated the sequential
fast-path return-transfer path for eligible sequential frames after
frame 0. See Section 8 and Section 14.8.

**CMS06.8-2 — Sequential fast-path authority rule added (Section 4.10).**
For N > 0, when `output_cache[N-1]` is available through
`cnr3_output_cache_find_frame_and_add_ref()`, the selected path may compute
output N using cached output N−1 and source frame N, store output N in
`output_cache`, look up `output_cache[N]`, transfer that lookup ref, and
return it. Frame 0 remains ineligible and uses reset/start fallback.

**CMS06.8-3 — H15.5 current limitation recorded.**
H15.5 proves return transfer but does not yet reduce `arInitial`
source-frame requests. `arInitial` request-plan reduction is a separate
VapourSynth lifecycle phase (VS-LIFECYCLE-01): any source frame retrieved
in `arAllFramesReady` must have been requested in the same callback
activation's `arInitial`. See Section 2.3 and Section 8.

**CMS06.8-4 — H15.6 and H15.7 next-phase direction added.**
H15.6 is an `arInitial` source-plan reduction probe (log only, no request
change). H15.7 is the active `arInitial` request reduction proof, only if
H15.6 evidence is clean. See Section 8.

**CMS06.8-5 — Old strict quarantine preserved and strengthened.**
The sequential fast path must not restore `old_strict_cache.next_needed`
or `old_strict_cache.prev_output` as selected output authority.
Logs/evidence must continue proving old strict non-mutation until old
strict state is retired. See Section 13.17. The fast path being
authoritative for eligible sequential frames increases, not decreases,
the need to keep old strict state quarantined.

**CMS06.8-6 — No handover production-spec change required.**
Handover Pack Production Spec v1.5 remains adequate: it already requires
current-state hard gates, output-authority discipline, ownership/release
balance, old strict-state review, and durable-rule preservation.

### CMS06.7 — 2026-06-10

**CMS06.7-1 — Duplicate-store return value and ownership semantics
clarified (Section 4.9).**
The duplicate/already-cached store case is a first-in-best-dressed
success, not a hard failure. A `true` return means the frame number is
safely represented in the cache (by new insertion or by an existing
first-in-best-dressed frame); it does NOT mean the cache took ownership
of the caller's supplied frame in the duplicate case. The caller still
owns its computed/local frame and must `freeFrame()` it on every exit
path unless a later phase explicitly proves a different ownership
transfer. Counter increments clarified (duplicate_computed_but_discarded
only when the duplicate was actually computed before detection).

**CMS06.7-2 — Decision-log mirror note (Section 4.9).**
A note records the implementation consequence for any decision-log entry
that mirrors first-in-best-dressed duplicate-store semantics: the caller
releases its local frame after a duplicate exactly as it would after a
new insertion where the cache took its own independent addFrameRef. (The
decision log itself lives in handover Document B, not this design
authority.)

**CMS06.7-3 — H6 PASS criteria clarified: non-zero duplicate counters
not mandatory (Section 8).**
A clean sequential H6 proof may not naturally produce duplicate store
attempts. Non-zero duplicate counters are not required for PASS when the
test pattern produces no duplicate store attempts. Duplicate counters
remain important evidence when overlap is deliberately tested.

**CMS06.7-4 — H6 proof summary field list specified (Section 8).**
The H6 store-only proof summary must distinguish local-output
availability, store result, duplicate/idempotent success, caller/local
frame release, and proof-only non-authority. Use the source counter names
where they differ from the names listed.

**CMS06.7-5 — No production-spec change.**
Handover Pack Production Spec v1.5 does not require a version change for
this clarification; it already mandates ownership/release balance,
output-authority discipline, and current-state hard gates.

### CMS06.6 — 2026-06-10

**CMS06.6-1 — CMS02-H / SubPhase H4 complete / PASS with preserved evidence.**
H4 proved request/acquire/release of the conservative bounded warm-up
source-frame set (57/57/57/0) without compute, store, return,
output-authority change, or old strict-state mutation. Full proof evidence
preserved in Section 14.7. Final edit marker:
`CMS02-H4-bounded-warmup-source-frame-set-request-acquire-release-v1-PASSED`.

**CMS06.6-2 — CMS02-H / SubPhase H5 complete / PASS with preserved evidence.**
H5 (bounded-warmup-local-compute-proof) proved local bounded warm-up
computation using the H4 source lifecycle and the existing
explicit-predecessor frame-processing boundary. H5.1 proved zero-start
local rolling compute; H5.2 proved S > 0 bounded-start reset/start
semantics. Full proof evidence preserved in Section 14.7. Final edit
marker: `CMS02-H5-bounded-warmup-local-compute-proof-v1-PASSED`.

**CMS06.6-3 — CMS02-H phase structure updated; H6 next.**
H5+ "Not started" wording replaced. New sequence: H6
(bounded-warmup-store-proof, strictly store-only) is next; H7
(bounded-warmup-return-decision-dry-run, dry-run only) pending; H8+
(return-transfer / output-authority readiness) deferred until after H7
evidence. See Section 8.

**CMS06.6-4 — Bounded-start S > 0 reset/start semantics formalised.**
When bounded warm-up begins at S > 0 with no valid predecessor for S−1,
output[S] uses explicit reset/start semantics — a bounded approximation
start, never described as exact full-history recursion. Required
diagnostic fields specified. See Sections 4.5.4 and 13.11.

**CMS06.6-5 — Durable rule: no parallel pixel/frame algorithms.**
Recovery, bounded warm-up, checkpoint recovery, cache-fill, and future
scheduling-mode work must reuse existing frame-processing boundaries.
Orchestration, ownership, cache, scheduling, and output-authority transfer
are the things being proven — not pixel maths. See Section 13.12.

**CMS06.6-6 — Durable rule: ownership and release balance.**
Every acquired or allocated frame must have a provable owner and a
provable release or transfer path, on every exit path, with diagnostics
proving final balance at quiescent points. See Section 13.13.

**CMS06.6-7 — Durable rule: output-authority discipline.**
Compute, store, return decision, return transfer, and output-authority
transition must remain separately provable. Proof-only paths must state
explicitly what they do and do not do. See Section 13.14.

**CMS06.6-8 — CMS02-J0 mandatory checkpoint inserted before CMS02-J.**
CMS02-J (fmParallelRequests wiring) must not start until CMS02-J0
(pre-fmParallelRequests cleanup and observability review) has been
evaluated and performed, or specific deferrals explicitly documented.
14-item review scope specified. See Sections 8 and 13.15.

**CMS06.6-9 — Compile-time diagnostics direction added.**
Strong recommendation now: prefer compile-time gating (constexpr /
if constexpr) for new diagnostics where practical. Final consolidation to
the compile-time model is a CMS02-J0 deliverable/requirement — not an
immediate refactoring task, to avoid mixing cleanup with active proof
phases. See Section 13.16.

**CMS06.6-10 — Old strict-state final-goal review strengthened to hard gate.**
Before final fmParallelRequests/fmParallel readiness and final
output-cache authority: `old_strict_cache.next_needed`,
`old_strict_cache.prev_output`, the `process_cnr3_frame()` compatibility
wrapper, and any serial-order assumption must be reviewed. These must not
silently remain authoritative in a final parallel design. See Section 13.17.

**CMS06.6-11 — Section 14 implementation snapshot updated.**
H4 and H5 complete/PASS with evidence (Section 14.7); proof paths disabled
in committed state; no warm-up store/return; output authority unchanged;
next CMS02-H task is H6.

### CMS06.5 — 2026-06-08

**CMS06.5-1 — VS-LIFECYCLE-01 named rule added (Section 2.3).**
The VapourSynth arInitial/arAllFramesReady request/retrieve lifecycle
constraint is now a named hard rule in the spec. Any source frame
retrieved with `getFrameFilter()` in `arAllFramesReady` must have been
requested with `requestFrameFilter()` in `arInitial` of the same callback
activation. Attempting to discover, request, and retrieve source frames
inside `arAllFramesReady` is invalid. This is a VapourSynth API
constraint, not a CNR3 design choice.

**CMS06.5-2 — CMS02-H / SubPhase H4 added (Section 8).**
Formal sub-phase entry for
`CMS02-H / SubPhase H4 / bounded-warmup-source-frame-set-request-acquire-release`.
Conservative arInitial request window `[max(0, N-B), N]`. Option B
implementation choice locked in: dedicated H4 plan structure
(`Cnr3ForDebugOnlyBoundedWarmupSourcePlan` or similar), modelled on the
proven G-phase lifecycle shape but with separate H4 names, counters,
comments, and diagnostics. G-phase structure must remain
checkpoint-recovery-specific and must not be repurposed for H4.
20-frame proof expectations (57/57/57/0) specified. Full not-allowed list
included.

**CMS06.5-3 — First-in-best-dressed layer clarification added
(Section 2.1).**
Explicit note added that first-in-best-dressed applies at the output
storage layer, not at the source frame request layer. Conservative source
frame requests in arInitial are fully compatible with the
first-in-best-dressed principle.

**CMS06.5-4 — H3/H4 timing distinction captured in Section 8.**
Explicit note that H3 (post-store diagnostic) and H4 (arInitial ownership
proof) observe cache state at different moments and must not be conflated.
H3 must not be altered to accommodate H4.

### CMS06.4 — 2026-06-08

**CMS06.4-1 — Bounded checkpoint search contract added (Section 4.5.3).**
Bounded recovery planning must bound the checkpoint search interval itself,
not merely find the global nearest prior checkpoint and reject it afterward.
The search interval is `[max(0, N - B), N]`. If no checkpoint exists within
that interval, return false without pinning. Do not search outside the
interval. This is a design contract correction affecting how
`prepare_bounded_recovery_plan()` must behave. See Section 4.5.3 and
Section 13.10.

**CMS06.4-2 — Section 9.2 updated: bounded vs unbounded helpers
distinguished.**
The existing `cnr3_output_cache_find_and_pin_nearest_prior_checkpoint()`
helper is unbounded and must not be used directly inside
`prepare_bounded_recovery_plan()`. A bounded variant that searches only
within `[max(0, N - B), N]` is required. See Section 9.2.

**CMS06.4-3 — CMS02-H sub-phases H2A and H2B inserted.**
Two new sub-phases inserted before H3 in the CMS02-H sequence:
`CMS02-H / SubPhase H2A / bounded-checkpoint-search-contract-review` and
`CMS02-H / SubPhase H2B / bounded-checkpoint-search-helper-proof`.
H3 and later sub-phases must not proceed until H2B is proven. See Section 8.

**CMS06.4-4 — Named item 13.10 added: bounded checkpoint search contract.**
Records the settled design decision with rejected alternative
(search-then-reject) and reason. Prevents future chats from silently
using the unbounded helper for bounded recovery planning. See Section 13.10.

### CMS06.3 — 2026-06-07

**CMS06.3-1 — Phase/subphase naming standard adopted.**
All sub-phase references now use the expanded form
`CMS02-G / SubPhase G10D.N / short-intent-name` in prose and handover
documents. Compact form `CMS02-G.10D.N` retained only in tables, log
markers, and commit titles. Prevents confusion between sub-phases and
major CMS02 phases. See handover pack spec v1.3 Section 3.7.

**CMS06.3-2 — Implementation state updated through CMS02-G / SubPhase G10D.8.**
Phase completion table in Section 14.1 updated. CMS02-G / SubPhase G10ABC
and G10D.1 through G10D.8 recorded as complete. Latest committed phase
label: `Complete CMS02-G.10D.7 recovery-return-decision-dry-run`.
Latest observed proof edit marker:
`CMS02-G10D7-recovery-return-decision-dry-run-v1`.

**CMS06.3-3 — CMS02-F status corrected from "not started" to
"substantially implemented."**
In the source snapshots reviewed: `cnr3_output_cache_find_frame_and_add_ref()`,
`arAllFramesReady` cache-hit lookup, `cnr3_output_cache_note_lookup_ref_transferred()`,
and CACHE-HIT-RETURN return path are implemented. Cache misses still fall
through to strict-streaming computation. Full output-cache authority is not
yet complete. See Section 8 (CMS02-F) and Section 14.3.

**CMS06.3-4 — exact_match named constraint added.**
`exact_match` is a diagnostic label/value in the recovery
difference-measurement proof path. It must not be used as a
bounded-recovery return condition. See Section 13.8.

**CMS06.3-5 — Duplicate/recompute waste summary added to Section 6.**
Raw counters already exist. A required human-readable duplicate/recompute
waste summary block (counts and percentages) is specified as a near-term
required diagnostic output format. Not yet implemented as a formatted block.
See Section 6 and Section 13.9.

**CMS06.3-6 — fmParallel warning strengthened.**
`old_strict_cache.next_needed` and `old_strict_cache.prev_output` are
explicitly named as incompatible with final fmParallel output authority.
Design and coding must not introduce ordering assumptions tied to these
fields. See Sections 1, 14.6.

**CMS06.3-7 — Cnr3OwnedFrameRef RAII wrapper status clarified.**
Not yet implemented. Recommended but not mandatory while explicit ref
handling remains clean and the caller-side invariant holds. Trigger
condition for when it becomes mandatory is now stated. See Section 2.2
and Section 9.1.

**CMS06.3-8 — Section 14.3 stale bullet corrected.**
Removed stale bullet saying `cnr3_output_cache_update_hot_zones()` was
called in `arAllFramesReady`. It is called in `arInitial`. Section 14.3
updated to reflect actual current wiring including cache-hit return path.

**CMS06.3-9 — Section 14.5 and 14.6 updated to match current state.**
Several items previously listed as "not implemented" are now implemented
(cache-hit lookup, transfer accounting). Output authority description
updated to reflect partial shift: cache hits served from output_cache,
cache misses still strict-streaming.

### CMS06.2 — 2026-06-06

**CMS06.2-1 — Section 14.4 hot-zone update placement: RESOLVED.**
The CMS06.1 deviation note saying hot-zone updates were in `arAllFramesReady`
is superseded. The current committed code calls
`cnr3_output_cache_update_hot_zones()` from `arInitial`, before
`requestFrameFilter()`. This is correct and must be preserved. See
Section 14.4 and named item G-PAR-HZ-ARINITIAL-01 (Section 13.3).

**CMS06.2-2 — Open design requirement added before Phase CMS02-G.10D.**
Actual recovery computation must not depend on or mutate
`d->old_strict_cache.prev_output` or `d->old_strict_cache.next_needed`.
A safe processing boundary with explicit predecessor input must exist before
any real recovered-frame computation begins. See Section 8 (G.10D) and
Section 13.4.

**CMS06.2-3 — Implementation state updated through CMS02-G.9AB.**
Phase completion table in Section 14.1 updated. CMS02-G sub-phases G.7A
through G.9AB recorded as complete. All proof paths remain disabled in the
normal committed state. Current `CNR3_EDIT_VERSION`:
`CMS02-G9AB-source-frame-set-proof-disabled-v1`.

**CMS06.2-4 — Phase CMS02-G.10ABC added to Section 8.**
Dry-run compute orchestration skeleton phase. Explicit not-allowed list
prevents premature recovered-frame computation or output-authority changes.
Cross-reference to the G.10D precondition requirement added.

**CMS06.2-5 — Named deferred items added (Section 13).**
Three named items formalised: G-PAR-HZ-ARINITIAL-01 (resolved),
G-DIAG-RECALC-HIST-01 (deferred), G-DIAG-LOG-VOLUME-01 (deferred).

**CMS06.2-6 — Section 4.8 stale note removed.**
The note in Section 4.8 saying hot zones were updated in `arAllFramesReady`
is replaced with a resolved-status note matching Section 14.4.

**CMS06.2-7 — Comment/label drift: do not mix with G.10ABC.**
Noted in Section 13.5 that CMS05/CMS06 comment wording cleanup must not
be combined with G.10ABC. G.10ABC is a safety-critical proof phase.

### CMS06.1 — 2026-06-04

Clarifified that the final target is operating safely fmParallel and that interim
steps of fmUnorderd and fmParallelRequests may be valid interim steps but design
and coding must lean toward safe operation under fmParallel.

### CMS06 — 2026-06-02

Clean version incorporating all CMS05.x revisions. No new design
decisions. Changes from CMS05.1:

**CMS06-1 — Actual code file naming confirmed and spec updated.**
Code review of uploaded source files confirmed the current active naming.
Section 9 updated to match code reality. Two sets of files were in play:
disk-uploaded (pre-rename) and inline documents (current active). The
inline documents are authoritative. See Sections 9 and 14.

**CMS06-2 — `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS` resolved.**
`cnr3_output_cache_manager.h` referenced `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`
which was missing from `cnr3_build_config.h`. The updated build config
now defines it, replacing the old `CNR3_CACHE_MANAGER_DEV_DIAGNOSTICS`.
If any file still references the old name, it must be updated. See
Section 13.1.

**CMS06-3 — Stale phase comment in `cnr3_output_cache_manager.h` noted.**
The comment "Phase 1 intentionally does not change current runtime
behaviour" is stale — Phase 3A store/prune wiring is complete. See
Section 13.2.

**CMS06-4 — Section 14 added: Current Implementation State.**
Ground truth derived from reading the uploaded source files. Records
phase completion, rename completion, what is wired and live, one spec
deviation (hot zone update placement), and what is not yet implemented.

**CMS06-5 — Section 13 added: Pending Code Issues.**
Records known issues requiring resolution before or during next coding
session.

### CMS05.1 — 2026-06-02

- `CNR3_CACHE_BYTE_BUDGET` raised from 512 MiB to 1 GiB.
- Ceiling clarification note added for 720×576 vs 1440×576.
- Appendix D added: Code Review and Simulation Plan reference.

### CMS05 — 2026-06-01

Seven changes from CMS04: first-in-best-dressed store idempotency;
final-frame ownership transfer; lookup-owned reference balance counters;
version-independent naming; Design-Compliance Review process; additional
store-related diagnostic counters; Appendix C added.

---

## 1. Problem Statement

CNR3 is a recursive temporal chroma stabiliser. Every output frame depends
on the previous output frame as a predecessor. The cache manager must
retain enough predecessor frames to satisfy any in-flight computation,
prune old frames to keep memory bounded, and maintain strict VSFrame
reference-count discipline so that no frame is ever leaked or freed
prematurely.

The existing cache manager infrastructure (pools, checkpoint pinning,
mutex model, store/remove/validate helpers) is sound. What is not yet
designed is the pruning policy and structural protections needed to make
that policy safe under three VapourSynth execution modes:

- **fmUnordered** — one request in flight at a time, mostly sequential
- **fmParallelRequests** — multiple concurrent requests, serialised writer
- **fmParallel** — fully concurrent readers and writers (final target)
- Important Notes (repeated in another section):
    To be very clear, **fmParallel** is specifically the final operational target,
    hence design and coding should lead toward running safe under fmParallel although
    iterative design/development may pass through fmUnordered and fmParallelRequests
    as interim stepping stones.
    It is conjectured that the cache design is, with correct mutexes in the correct
    places, orders and depths, compatible with fmParallel; alignment with this will
    be subject to later review.
    **fmParallel warning:** `old_strict_cache.next_needed` and
    `old_strict_cache.prev_output` are not final fmParallel output authority.
    Do not introduce design or code assumptions tied to these fields that would
    block migration to full fmParallel authority.

The primary failure modes without the new design:

**FM1 — Prune destroys in-flight predecessor.**
**FM2 — Prune destroys a checkpoint needed by a recovery chain.**
**FM3 — Jump recovery burst exceeds pool capacity.**
**FM4 — Prune eviction key is wrong (lowest-first).**
**FM5 — VSFrame reference leak.**
**FM6 — VSFrame use-after-free.**
**FM7 — Duplicate store overwrites or double-references existing frame.**

---

## 2. Design Goals

1. Prevent pruning of frames likely to be needed by active computation
   using hot-zone protection. If diagnostics show hot-zone protection is
   insufficient, promote non-checkpoint pinning to a mandatory
   implementation step (Section 4.4).

2. Make pruning decisions based on frame-number proximity to active work,
   not on insertion order or frame-number magnitude.

3. Support up to `CNR3_MAX_HOT_ZONES` simultaneous active working ranges.

4. Fill holes only — never recompute a frame that is already cached.
   Stores are idempotent by frame number (Section 2.1, Section 4.9).

5. **Reference-Count Invariant.** For every VSFrame held by the cache,
   the cache contributes exactly one `addFrameRef` while it holds the
   slot, balanced by exactly one `freeFrame` when the slot is removed.
   No VSFrame is ever leaked. No VSFrame is ever freed while still in
   use outside the cache mutex (Section 2.2, Section 4.7).

6. Bound memory use with a hard ceiling computed from actual frame
   geometry and a configurable byte budget (Section 4.6).

7. Hard-abort cleanly when the ceiling is hit with nothing prunable.
   Filter must remain in a valid state after the abort.

8. Remain compatible with the existing mutex model, pool structures, and
   `_externally_locked` helper pattern.

9. Require no changes to the VapourSynth API interaction model.

10. Keep the first implementation understandable and empirically provable
    before adding further complexity.

### 2.1 Fill-Holes-Only Principle (with Reference-Ownership Rule)

The cache manager must never blindly recompute a complete chain when the
required output frames are already cached.

Recovery and chain-filling operate as follows:

- Recovery proceeds in ascending frame-number order only.
- Before computing any frame K, check whether output[K] already exists.
- If present, reuse it without recomputing.
- If absent (a hole), compute from the best available predecessor, store,
  and continue.
- If a concurrent walk loses a store race, the losing walk's store helper
  returns success without taking ownership of the losing walk's frame.
  The losing walk releases its computed frame normally (Section 4.9).

**Layer clarification — first-in-best-dressed and source frame requests:**

First-in-best-dressed (Section 4.9, RC8) applies at the **output frame
storage layer**, not at the source frame acquisition layer. Requesting a
source frame for a position whose output is already cached is safe:
requesting `source[K]` does not store, modify, or affect the ref-count of
`output[K]`. Conservative source frame requests in `arInitial` (for
example, requesting all frames in a bounded warm-up window regardless of
which outputs are already cached) do not violate first-in-best-dressed.
First-in-best-dressed is enforced when the recovery walk decides whether
to *compute* each output frame, which happens in `arAllFramesReady` after
source frames have already been acquired.

**Reference-ownership rule:**

When output[K] is found in cache and used as the predecessor for
output[K+1] outside the cache mutex, the lookup helper takes
`addFrameRef()` while still holding the cache mutex (atomic find-and-ref),
then returns that caller-owned reference. The caller must `freeFrame()`
on every exit path — success, error, early return. Implemented by
`cnr3_output_cache_find_frame_and_add_ref()` (Section 9.2.H).

Hot-zone protection and `addFrameRef` are independent mechanisms with
different roles (Section 4.7).

### 2.2 Reference-Count Discipline

VapourSynth manages frame memory by reference counting. `addFrameRef`
increments; `freeFrame` decrements. At zero the frame's pixel data is
released.

**Hard rules:**

**RC1 — Single store helper.** All cache-owned `addFrameRef` calls occur
only in `cnr3_output_cache_store_frame()`.

**RC2 — Single remove helper.** All cache-owned `freeFrame` calls occur
only in `cnr3_output_cache_remove_frame_externally_locked()`. No direct
`pool.erase()` or `cache_index.erase()` outside the remove helper.

**RC3 — Store error paths must rebalance.** If store takes `addFrameRef`
then fails to complete insertion, it must `freeFrame` before returning.

**RC4 — Lookup error paths must rebalance.** If
`find_frame_and_add_ref` takes `addFrameRef` then fails before returning
to the caller, it must `freeFrame` before returning nullptr.

**RC5 — Caller exit paths must `freeFrame`.** Every code path receiving
a caller-owned reference from a lookup helper must `freeFrame` on every
exit path: success, error, early return, exception, hard abort.

**RC6 — Shutdown must clear.** Destruction of `Cnr3OutputCacheManager`
must iterate all slots in both pools, `freeFrame` each, and log a
warning for any slot with `pin_count > 0`.

**RC7 — Validation enforces balance.** `validate_invariants` includes:
`cache_addframeref_total - cache_freeframe_total == total_live_slots`.

**RC8 — First-in-best-dressed store idempotency.** Store is idempotent
by frame number. If `output[N]` already exists at store time, return
success without taking `addFrameRef`, without modifying either pool, and
without disturbing the existing slot's classification. The cache has not
taken ownership of the caller's supplied frame. See Section 4.9.

**RAII wrapper — `Cnr3OwnedFrameRef` (recommended, not yet implemented):**

This wrapper is specified and recommended but is not yet in the current
committed code. Explicit ref handling (`cnr3_output_cache_note_lookup_ref_released`,
`cnr3_output_cache_note_lookup_ref_transferred`, and manual `freeFrame` on
every exit path) is the current acceptable interim approach, provided the
caller-side invariant (`acquired == released + transferred`) remains clean
at all quiescent points.

**Trigger condition for mandatory implementation:** If explicit ref handling
ever produces a balance error, or if a code review finds that exit paths are
not reliably covered, implementing `Cnr3OwnedFrameRef` becomes a corrective
action required before further development. No phase is currently blocked on
it while the invariant holds clean.

```cpp
struct Cnr3OwnedFrameRef {
    const VSFrame* frame = nullptr;
    const VSAPI* vsapi = nullptr;
    Cnr3OwnedFrameRef() = default;
    Cnr3OwnedFrameRef(const VSFrame* f, const VSAPI* api)
        : frame(f), vsapi(api) {}
    ~Cnr3OwnedFrameRef() {
        if (frame && vsapi) vsapi->freeFrame(frame);
    }
    Cnr3OwnedFrameRef(const Cnr3OwnedFrameRef&) = delete;
    Cnr3OwnedFrameRef& operator=(const Cnr3OwnedFrameRef&) = delete;
    Cnr3OwnedFrameRef(Cnr3OwnedFrameRef&&) noexcept;
    Cnr3OwnedFrameRef& operator=(Cnr3OwnedFrameRef&&) noexcept;
    const VSFrame* release() noexcept {
        auto f = frame; frame = nullptr; return f;
    }
};
```

**Caller-side diagnostic balance (development only):**

Three development counters track caller-owned reference lifecycle:
- `lookup_owned_ref_acquired_total`
- `lookup_owned_ref_released_total`
- `lookup_owned_ref_transferred_total`

Diagnostic invariant at quiescent points:
`acquired == released + transferred`

### 2.3 VapourSynth arInitial/arAllFramesReady Lifecycle Rule

**VS-LIFECYCLE-01 — Hard VapourSynth API constraint. Non-negotiable.**

```text
Any source frame that will be retrieved with getFrameFilter() in
arAllFramesReady must have been requested with requestFrameFilter()
in arInitial of the SAME callback activation.
```

This is not a CNR3 design choice. It is a hard VapourSynth API rule.
Violating it will produce silent failure or undefined behaviour.

**What this means in practice:**

It is not possible to:
- discover in `arAllFramesReady` that source frames are needed, then
- request them there using `requestFrameFilter()`, then
- retrieve them in the same `arAllFramesReady` block.

That sequence is invalid. The retrieve will not find frames that were
not requested in `arInitial`.

**Consequence for warm-up recovery (Phase CMS02-H):**

If bounded warm-up recovery needs source frames `[K .. N]`, those frames
must be requested in `arInitial` before the `arAllFramesReady` block
begins. The request decision must therefore be made using only information
available at `arInitial` time — before the current frame has been
processed, stored, or promoted to a checkpoint.

This is why `CMS02-H / SubPhase H4` uses a conservative request window
`[max(0, N - B), N]` rather than relying on post-store checkpoint
decisions to determine what to request. See Section 8 and Section 4.5.3.

**H15.5 note — return-transfer is not the same as arInitial request-plan
reduction (CMS06.8, sequence updated CMS06.11):** H15.5 proves that
eligible sequential frames can return through the sequential fast path
(Section 4.10). It does not by itself prove that `arInitial` can stop
requesting the bounded-warmup source window. Request-plan reduction must be
handled separately because of VS-LIFECYCLE-01. The current safe sequence
(CMS06.9/CMS06.10) is:
- H15.6A: request classification probe; no behaviour change;
- H15.6B.1: `arInitial` predecessor reservation lifecycle proof — acquire
  and carry a caller-owned ref to `output_cache[N-1]` in `frameData`; no
  source-request reduction;
- H15.6B.2: reserved-predecessor fast-path consumption proof — consume the
  carried ref as the predecessor; still conservative source requests;
- H15.6B.3: active source-request reduction using the proven reserved
  predecessor, while retaining fallback request behaviour for frame 0,
  holes, non-sequential requests, and failed eligibility.

See Section 4.10.1 and Section 13.18 for the reservation model that makes
the reduction safe.

This prevents a future chat from treating H15.5 as permission to make an
unproven request-plan change.

**Relationship to H3:**

H3 is a post-store diagnostic that runs in `arAllFramesReady` after store
and prune. H3 can see checkpoint N if frame N was just stored. H4's
`arInitial` request decision runs before store, so H4 cannot rely on
the same cache state H3 sees. H3 and H4 are related but not identical,
and H3 must not be altered to accommodate H4. See Section 8.

---

## 3. Simulation Results — Linear Encoding Jitter

A Monte Carlo simulation (200 runs, 100 frames, varied jitter) characterised
realistic frame arrival patterns for the primary linear encoding use case
(vspipe / ffmpeg pipe with BestSource source plugin).

Model: each frame dispatched at time = `frame_number + uniform_random(0,
jitter_max)`. Frames arrive at `cnr3_get_frame` in delivery-time order.

**Key results (jitter sweep, 500 runs each):**

| Jitter range | Avg max gap | p95 max gap | p99 max gap | Abs max gap |
|---|---|---|---|---|
| 0..2  | 2.7  | 3  | 3  | 3  |
| 0..4  | 4.7  | 6  | 7  | 7  |
| 0..6  | 6.5  | 8  | 9  | 9  |
| 0..8  | 8.2  | 10 | 11 | 12 |
| 0..10 | 10.0 | 12 | 12 | 14 |
| 0..12 | 11.6 | 14 | 15 | 16 |
| 0..16 | 15.2 | 18 | 19 | 20 |
| 0..24 | 22.0 | 24 | 26 | 29 |
| 0..32 | 28.9 | 32 | 34 | 34 |

For observed BestSource jitter of 4–6 frames, worst-case reorder window
is approximately 9 frames at p99. `CNR3_HOT_ZONE_FORWARD_RADIUS = 10`
covers this with headroom. `CNR3_REORDER_WINDOW = 32` is adequate for
jitter up to approximately `jitter_max=24` at p99.

---

## 4. Algorithm Overview

### 4.1 Hot Zone Tracking

The cache manager maintains a fixed-size array of hot zones. Each hot
zone represents a contiguous range of frame numbers currently active
(one or more in-flight computations work within that range).

A hot zone has:
- **active** flag
- **low** frame number boundary (inclusive)
- **high** frame number boundary (inclusive)
- **last_observed_frame** — most recently arrived frame number that
  fell within or caused this zone
- Diagnostic counters: `hit_count`, `slide_count`, `merge_count`,
  `retirement_count`, `prune_protection_count`

Discrete hot zones allow multiple simultaneous active ranges to be
represented independently. A jump produces two zones that coexist until
the old zone goes cold.

### 4.2 Hot Zone Lifecycle — Sliding (Both Modes)

#### 4.2.1 Sliding rule (both modes)

For an arriving frame `F`:

1. Find the nearest active zone Z such that `F` is within
   `CNR3_HOT_ZONE_JUMP_THRESHOLD` of Z's range. If multiple qualify,
   pick the one with smallest absolute distance from F to the nearest
   boundary.

2. If found, slide Z:
   ```
   Z.low  = max(0, F - CNR3_HOT_ZONE_BACK_RADIUS)
   Z.high = F + CNR3_HOT_ZONE_FORWARD_RADIUS
   Z.last_observed_frame = F
   ```
   Increment `slide_count` if bounds moved, or `hit_count` if not.

3. If no Z within threshold, this is a jump event. Allocate a new zone
   (Section 4.2.3).

#### 4.2.2 Why sliding is safe in both modes

Safety relies on two mechanisms working together:

- **`addFrameRef` discipline (Section 4.7)** — a walk that has already
  looked up a predecessor holds a caller-owned reference. Even if a slide
  moves the zone past that predecessor and a prune evicts the cache slot,
  the walk's owned reference keeps the underlying VSFrame alive.

- **Rolling predecessor reference pattern (Section 4.5.1)** — walks hold
  an owned reference to the current predecessor and transition ownership
  across iterations without ever holding zero references to the current
  predecessor.

Under normal sequential linear encoding in fmParallelRequests, the working
spread of concurrent requests is much smaller than `BACK_RADIUS=50`. With
16–32 threads and jitter ~6, the spread is ~22–38 frames. The slid zone
always covers all in-flight predecessor needs.

The pathological case — a walk stalls while concurrent walks slide the
zone forward — produces extra recovery work (checkpoint recovery), not
incorrect output. The diagnostic counter `predecessor_missing_when_expected`
detects this empirically. Non-zero triggers mandatory non-checkpoint
pinning (Section 4.4).

Full discussion in Appendix A.

#### 4.2.3 New zone allocation

When `F` is outside all active zones by more than `JUMP_THRESHOLD`:

1. Look for a free (inactive) zone slot.
2. If found, initialise:
   ```
   slot.low  = max(0, F - CNR3_HOT_ZONE_BACK_RADIUS)
   slot.high = F + CNR3_HOT_ZONE_FORWARD_RADIUS
   slot.last_observed_frame = F
   slot.active = true
   ```
   Increment `hot_zone_allocations`.
3. If no free slot: attempt retirement (4.2.4). If retirement fails,
   merge the two closest zones (4.2.5).

#### 4.2.4 Retirement (mode-specific)

**fmUnordered (eager retirement):**

When a new `arInitial` fires, the previous `arAllFramesReady` has
completed. All stale zones can be retired immediately before allocating
a new zone. In practice fmUnordered typically operates with at most one
active zone, which slides forward in normal linear operation and is
replaced (retire + new alloc) on a jump.

**fmParallelRequests (lazy retirement):**

Multiple requests may be in flight. A zone is eligible for lazy
retirement only when:
- No live frames remain in either pool within its `[low, high]` range,
  AND
- No pinned checkpoint exists within its range (conservative proxy for
  "no recovery walk is in progress within this zone").

Retirement is attempted only when a new zone allocation needs a free
slot and none is available. Spurious retention is safe; the cost is
modest increase in zone-slot pressure.

If the lazy proxy proves too conservative (zones never retire, slots
fill, merges happen too frequently), add `active_request_count` per zone
(incremented at `arInitial`, decremented at `arAllFramesReady`/`arError`)
for exact retirement eligibility.


**fmParallel (full multithreading):**

fmParallel is only potentially out of scope for early to late iteratative development
in terms of coding.
    
Important Notes (repeated in another section):
    To be very clear, **fmParallel** is specifically the final operational target,
    hence design and coding should lead toward running safe under fmParallel although
    iterative design/development may pass through fmUnordered and fmParallelRequests
    as interim stepping stones.
    It is conjectured that the cache design is, with correct mutexes in the correct
    places, orders and depths, compatible with fmParallel; alignment with this will
    be subject to later review.
    **fmParallel warning:** `old_strict_cache.next_needed` and
    `old_strict_cache.prev_output` are not final fmParallel output authority.
    Do not introduce design or code assumptions tied to these fields that would
    block migration to full fmParallel authority.
  
#### 4.2.5 Zone merge

When all slots are full and no zone is eligible for retirement:

1. Find the two zones with the smallest gap between boundaries.
2. Merge:
   ```
   merged.low  = min(Z1.low,  Z2.low)
   merged.high = max(Z1.high, Z2.high)
   merged.last_observed_frame = max(Z1.last_observed_frame,
                                     Z2.last_observed_frame)
   ```
3. Mark one slot inactive; store merged in the other.
4. Increment `merge_count`.
5. Use the freed slot for the new zone allocation.

Merging is conservative — no frames lose protection. Log the merge
action including zone frame ranges for diagnostics.

### 4.3 Pruning Policy — Hot Zone Aware (Phase-Guarded)

#### 4.3.1 Non-Checkpoint Pool Pruning

**Phase A — before non-checkpoint pinning exists (Phases CMS02-D
through CMS02-H):**

1. Call `retire_cold_hot_zones_externally_locked` (lazy retirement
   pass, mode-aware).
2. Collect non-checkpoint frames whose frame number falls outside every
   active hot zone's `[low, high]` range. These are eviction candidates.
3. Among candidates, find the one with the greatest minimum distance
   from any active hot zone boundary. Evict it via the single remove
   helper (RC2).
4. Repeat until `non_checkpoint_pool.size() <= CNR3_OUTPUT_CACHE_CAPACITY`
   or no candidates remain.
5. If no candidates remain and the pool exceeds the overflow limit, do
   not evict further. The pool may temporarily exceed the soft target,
   up to the hard ceiling.

**Phase B — after non-checkpoint pinning (Phase CMS02-I or later,
only if promotion criteria are met):**
Identical to Phase A except step 2 also requires `pin_count == 0`.

For typical pool sizes (100–300 frames), a linear scan to find the
maximum-distance candidate on each iteration is acceptable.

#### 4.3.2 Checkpoint Pool Pruning

Apply hot-zone-aware filtering with the existing `pin_count` check:

1. A checkpoint is a candidate if: frame number ≠ 0 (frame 0 is never
   pruned), `pin_count == 0`, AND frame number falls outside every
   active hot zone's `[low, high]`.
2. Evict the candidate with the greatest distance from any hot zone
   boundary first (via the single remove helper).
3. Continue until `checkpoint_pool.size() <= CNR3_CHECKPOINT_MIN_RETAIN`
   or no candidates remain.

Checkpoints within hot zones or pinned are retained regardless of
`CNR3_CHECKPOINT_MAX_RETAIN`. The retain limits are soft triggers for
when prune runs, not hard caps on what can be retained.

**Why checkpoints are retained longer:** Checkpoints anchor recovery
chains. A checkpoint inside or near an active hot zone may be needed as
a recovery anchor. With `BACK_RADIUS=50` and `CHECKPOINT_INTERVAL=10`,
a hot zone holds at most 5 checkpoints. With 5 active zones, up to 25
checkpoints could be protected — well within `MAX_RETAIN=32`.

### 4.4 Non-Checkpoint Frame Pinning — Deferred

Non-checkpoint pinning remains the deterministic solution to FM1 if
hot-zone-aware pruning is shown to be insufficient. The first
implementation defers non-checkpoint pinning.

**Mandatory promotion criterion:**

Non-checkpoint pinning becomes mandatory — not optional, not deferred
further — if any of the following are observed during realistic test runs:

- `predecessor_missing_when_expected` is non-zero in any realistic
  VHS/VHS-C encode test.
- Recovery repeatedly recomputes frames that were recently cached.
- fmParallelRequests testing reveals a race between prune and active
  predecessor use that hot zones and `addFrameRef` do not cover.
- Hot-zone settings required to prevent the above become so broad they
  defeat pruning (e.g., back radius must exceed 200 to be safe).

**Structural change if added later:**

Change `non_checkpoint_pool` from `std::map<int, const VSFrame*>` to
`std::map<int, Cnr3NonCheckpointSlot>` where
`Cnr3NonCheckpointSlot = { const VSFrame* frame; int pin_count = 0; }`.
Mirror the existing checkpoint pin/unpin pattern.

### 4.5 Bounded Warm-Up Recovery — No-Prior-Checkpoint Case

When a request arrives for frame N and no cached output[N-1] exists and
no usable nearest-prior checkpoint exists:

```
start = max(0, N - CNR3_OUTPUT_CACHE_CAPACITY)
output[start] = source-copy initialisation (no predecessor blend,
   deliberate approximation — documented trade-off)
output[start+1..N] computed using fill-holes-only + rolling predecessor
```

#### 4.5.1 Rolling Predecessor Reference Pattern

A recovery walk maintains an owned reference to the current predecessor
through each iteration. The reference is transitioned (not
released-then-reacquired) when moving from iteration K to K+1.

```text
prev_ref = nullptr

if cache hit at start:
    prev_ref = find_frame_and_add_ref(start)
else:
    new_frame = initialise_from_source(start)  // source-copy semantics
    store_frame(start, new_frame)
       // cache takes its own addFrameRef
    prev_ref = new_frame
       // walk retains original computed ref

for K in start+1 .. N:
    cached = find_frame_and_add_ref(K)
    if cached != nullptr:
        // Fill-holes-only: cache hit, skip computation
        freeFrame(prev_ref)
        prev_ref = cached
        continue

    // Cache miss: compute output[K] from prev_ref
    new_frame = compute_blend(prev_ref, source[K])
    store_frame(K, new_frame)
       // cache may take independent addFrameRef (first-in-best-dressed:
       // if already cached by concurrent walk, store returns success
       // without taking addFrameRef)
    freeFrame(prev_ref)
    prev_ref = new_frame
       // walk retains its own computed ref

// end of loop: see Section 4.5.2 for final-frame handling
```

**Key properties:**
- Walk always holds exactly one owned reference to the current
  predecessor.
- New predecessor acquired before old one released — no zero-ref window.
- Concurrent prune evicting a cache slot cannot damage the walk.
- Pattern works identically in fmUnordered and fmParallelRequests.

**On error paths:** if any step fails (`store_frame` returns false at
ceiling, blend fails, etc.), the walk must `freeFrame(prev_ref)` and
`freeFrame(new_frame)` (if held) before returning. The
`Cnr3OwnedFrameRef` RAII wrapper handles this automatically when implemented.
Until then, explicit `freeFrame` on every exit path is required.

#### 4.5.2 Final-Frame Ownership Transfer

At the end of a recovery walk, `prev_ref` normally owns the last output
frame computed or found by the walk. Two cases must be distinguished:

**Case A — `prev_ref` is an intermediate predecessor only:** The walk
has computed output[N] and stored it. `prev_ref` holds the last
predecessor in the rolling sequence. Call `freeFrame(prev_ref)`.

**Case B — `prev_ref` is the requested output frame N being returned
to VapourSynth via `getFrame`:** Ownership transfers when the walk
returns the VSFrame pointer. The walk must NOT call `freeFrame(prev_ref)`
after the transfer — that would be a double-free.

Required idiom when `Cnr3OwnedFrameRef` is implemented (`release()`);
until then, equivalent explicit handling is required on every exit path:

```cpp
if (prev_ref_is_requested_output_frame) {
    // Transfer ownership to VapourSynth.
    // Wrapper destructor will NOT freeFrame.
    return prev_ref.release();
}
// else: RAII destructor calls freeFrame at scope exit.
```

This idiom makes the transfer auditable and prevents accidental
double-free.

#### 4.5.3 Bounded Checkpoint Search Contract

**Settled design decision (CMS06.4). Must not be changed without explicit
review. See also Section 13.10.**

When a bounded recovery plan is being prepared for frame N with recovery
bound B (maximum forward frame count), the checkpoint search must be
bounded by the recovery interval itself — not merely by post-search
plan acceptance.

**Required search contract:**

```text
requested_frame    = N
max_forward_count  = B
lower_bound        = max(0, N - B)

Search for the greatest checkpoint C such that:
    lower_bound <= C <= N

If such C exists:
    pin C and return a bounded checkpoint-start recovery plan.

If no such C exists:
    return false without pinning any checkpoint.
    caller must treat the request as needing bounded warm-up.
```

**Worked examples (B = 2, checkpoints = {0, 10}):**

```text
requested_frame = 15  search interval [13, 15]
    no checkpoint in [13, 15]
    -> bounded plan: false; warm-up needed; no pin taken

requested_frame = 12  search interval [10, 12]
    checkpoint 10 is within [10, 12]
    -> bounded plan: true; selected checkpoint = 10; pin 10

requested_frame = 11  search interval [9, 11]
    checkpoint 10 is within [9, 11]
    -> bounded plan: true; selected checkpoint = 10; pin 10

requested_frame = 10  search interval [8, 10]
    checkpoint 10 is within [8, 10]
    -> bounded plan: true; selected checkpoint = 10; pin 10

requested_frame = 9   search interval [7, 9]
    no checkpoint in [7, 9]
    (checkpoint 10 is above N; checkpoint 0 is below lower_bound)
    -> bounded plan: false; warm-up needed; no pin taken
```

**Why not search-then-reject:**

The rejected alternative is to call the existing unbounded
`find_and_pin_nearest_prior_checkpoint()` helper, then check whether the
found checkpoint falls within the recovery interval, and unpin if not.

This is not acceptable because:
- It creates unnecessary pin/unpin churn for checkpoints already known
  to be out of scope before pinning.
- It may wander into older retained regions or other hot zones, creating
  surprising pin side-effects.
- It obscures diagnostics: a pin followed immediately by an unpin
  appears as spurious checkpoint activity.
- Under fmParallelRequests and fmParallel, out-of-scope pin/unpin churn
  creates unnecessary contention.

**Implementation consequence:**

`prepare_bounded_recovery_plan()` must use the bounded helper
`cnr3_output_cache_find_and_pin_checkpoint_in_interval()` (Section 9.2.G2).
The unbounded `cnr3_output_cache_find_and_pin_nearest_prior_checkpoint()`
must not be called directly from bounded recovery planning.

#### 4.5.4 Bounded-Start Reset/Start Semantics (S > 0)

**Settled design policy (CMS06.6). See also Section 13.11.**

When a bounded warm-up range begins at start frame S > 0 and no valid
predecessor or checkpoint is available for S − 1, local output[S] uses
**explicit reset/start semantics**.

```text
This is a bounded approximation start.
It is NOT exact full-history recursion from frame 0.
It must never be described or logged as exact full-history recursion.
```

**Implementation consequence:**

The start frame S must be processed using the existing reset/start
processing semantics (the same path used for frame 0), not by inventing
new manual copy or pixel logic. The subsequent recursive steps S+1..N
must use the existing explicit-predecessor processing boundary.

**Required diagnostic clarity:**

Logs and summaries for bounded-start work must distinguish:

```text
- actual_source_frame
- warmup_start_frame
- processing_frame_number
- predecessor_frame_number
- bounded_start_uses_frame0_reset_path (or equivalent flag)
```

This honesty requirement exists so that future review can always tell
whether a frame was produced by exact recursion or by bounded
approximation, without re-deriving it from code.

### 4.6 Hard Ceiling and Abort Policy — Byte-Budget Based

#### 4.6.1 Ceiling Calculation

At `cnr3_create()` time, after `Cnr3Data` construction:

```cpp
static int cnr3_output_cache_subsampled_dimension(int full_size,
                                                   int subsampling_shift)
{
    // ceil(full_size / (1 << subsampling_shift))
    // Conservative for odd dimensions; never underestimates.
    return (full_size + ((1 << subsampling_shift) - 1)) >> subsampling_shift;
}

int64_t estimated_frame_bytes = 0;
const int bytes_per_sample = (vi->format.bitsPerSample + 7) / 8;
const int sub_w = vi->format.subSamplingW;
const int sub_h = vi->format.subSamplingH;
for (int p = 0; p < vi->format.numPlanes; ++p) {
    const int pw = (p == 0) ? vi->width
                             : cnr3_output_cache_subsampled_dimension(
                                   vi->width, sub_w);
    const int ph = (p == 0) ? vi->height
                             : cnr3_output_cache_subsampled_dimension(
                                   vi->height, sub_h);
    estimated_frame_bytes += (int64_t)pw * ph * bytes_per_sample;
}
const int candidate_ceiling =
    (int)(CNR3_CACHE_BYTE_BUDGET / estimated_frame_bytes);
const int active_ceiling = std::clamp(candidate_ceiling,
                                       CNR3_CACHE_MIN_HARD_CEILING,
                                       CNR3_CACHE_MAX_HARD_CEILING);
```

This formula works for accepted planar YUV formats (4:2:0, 4:2:2, 4:4:0,
4:4:4). CNR3 accepts three-plane YUV only; grey is not in scope.

**Important disambiguation:** Standard PAL VHS source is 720×576, not
1440×576. At 1 GiB budget, 720×576 YUV420P8 gives candidate_ceiling ≈
1,726, correctly clamped to 1000. A genuine 1440×576 YUV420P8 clip gives
≈ 863, not clamped. If a log shows `active_ceiling=1000` for a clip
described as 1440×576, confirm the actual clip dimensions — it is likely
720×576. No code error exists in the ceiling calculation.

**Worked examples (`CNR3_CACHE_BYTE_BUDGET = 1 GiB`):**

| Format                | bytes/frame | candidate | active (clamped) |
|---|---|---|---|
| 4:2:0 8-bit  720×576  | 622,080     | 1,726     | **1000** (MAX)   |
| 4:2:2 8-bit  720×576  | 829,440     | 1,294     | **1000** (MAX)   |
| 4:2:0 16-bit 720×576  | 1,244,160   | 863       | 863              |
| 4:2:2 16-bit 720×576  | 1,658,880   | 647       | 647              |
| 4:2:0 8-bit  1920×1080| 3,110,400   | 344       | 344              |
| 4:2:0 16-bit 1920×1080| 6,220,800   | 172       | 172              |
| 4:2:0 8-bit  1440×576 | 1,244,160   | 863       | 863              |

#### 4.6.2 Abort Policy

A store is allowed if `total_live_refs_after_store <= active_ceiling`.
Rejected if it would cause `total_live_refs_after_store > active_ceiling`
AND prune cannot free any frame.

When rejected:
1. Store returns `false` without taking `addFrameRef` (RC3 preserved).
2. Increment `cache_ceiling_hard_aborts`.
3. The calling `getFrame` path executes cleanup discipline (4.6.3) then
   returns a VS filter error:
   *"CNR3: cache ceiling reached ([N] frames). CNR3 is designed for
   near-linear access. Large random seeks in rapid succession may exceed
   cache capacity."*

`cnr3_output_cache_would_exceed_ceiling_externally_locked()` returns true
iff a subsequent store would cause
`total_live_refs_after_store > active_ceiling`.

#### 4.6.3 Cleanup Discipline on Ceiling Abort

A ceiling abort may leave already-successfully-stored frames in the cache
(those frames are valid outputs). The failure path must not leave any
temporary runtime state unreleased:

- Any checkpoint pinned during the failed recovery: unpin exactly once.
- Any caller-owned VSFrame references held by the recovery walk
  (including `prev_ref`): `freeFrame` exactly once.
- Any source frame obtained from VapourSynth: release.
- Any destination frame allocated but not returned: release.
- Hot zone state: no rollback. A zone allocated for a failed request will
  be retired naturally when its range becomes cold.

After cleanup, reference counters remain balanced.

### 4.7 addFrameRef and Pinning — Separate Concerns

The cache manager has three distinct protection mechanisms:

| Mechanism | Protects against | Holder | Lifetime |
|---|---|---|---|
| **Hot zone membership** | Slot eviction by prune | Cache manager | Until zone slides/retires past frame |
| **Checkpoint `pin_count`** | Slot eviction by prune (checkpoints) | Recovery walks | Pin/unpin pair on every path |
| **`addFrameRef`** | Underlying VSFrame being freed | Caller of lookup helper | Until `freeFrame` by caller |

Hot-zone protection and `pin_count` are prune-side mechanisms. They
prevent the cache from evicting the slot. `addFrameRef` is independent
— it ensures the VSFrame's pixel data remains valid for the holder even
if the cache decides to evict.

Key insight:
> `addFrameRef` protects a frame *already found*. It does not make a
> missing predecessor appear.

The rolling predecessor reference pattern (Section 4.5.1) addresses this
by ensuring the walk always holds a ref to its current predecessor before
it would be needed as input.

### 4.8 arInitial vs. Cache-Hit Hot Zone Update

Hot zone updates fire at `arInitial` for every arriving frame request,
regardless of whether the request later results in a cache hit or
computation. This is deliberate: a cache hit still represents activity
near that frame number, and the hot zone should reflect the request
stream's working position.

**[CMS06.2 — RESOLVED]** The current committed code calls
`cnr3_output_cache_update_hot_zones()` from `arInitial`, before
`requestFrameFilter()`. This is correct. Do not move hot-zone updates
back to `arAllFramesReady`. The `arInitial` placement is a safety
prerequisite for fmParallelRequests and fmParallel. See Section 14.4
and Section 13.3.

Diagnostic counters distinguish:
- `hot_zone_updates_at_arInitial` — total `arInitial` calls that
  updated a hot zone.
- `cache_hits_at_arAllFramesReady` — requests served from cache without
  computation.
- `recoveries_started_at_arAllFramesReady` — requests requiring a
  recovery walk.

### 4.9 First-In-Best-Dressed Store Idempotency

`cnr3_output_cache_store_frame()` is idempotent by frame number.

When storing `output[N]`:

1. Lock the cache mutex.
2. Check `cache_index` for frame number `N`.
3. **If already exists (duplicate-store case):**
   - Do not replace the existing cached frame.
   - Do not take an additional cache-owned `addFrameRef`.
   - Do not mutate either pool.
   - Do not disturb the existing checkpoint/non-checkpoint classification.
   - Increment `store_skipped_already_cached`.
   - Increment `duplicate_store_computed_but_discarded` **only if** the
     duplicate frame was actually computed before the duplicate was
     detected (do not increment it for a pure already-cached skip where
     no duplicate computation occurred).
   - Return `true`. The cache already contains an authoritative frame for
     this frame number, but the cache has **not** taken ownership of the
     caller's supplied frame.
   - **Hard invariant (CMS06.7):** A `true` return means the requested
     frame number is safely represented in the cache, whether by new
     insertion or by an already-existing first-in-best-dressed frame. In
     the duplicate case the caller still owns its computed/local frame and
     must call `freeFrame()` on every exit path, unless a later phase
     explicitly proves and documents a different ownership transfer. A
     duplicate/already-cached frame number is a first-in-best-dressed
     success case, not a hard failure.
4. **If does not exist (normal case):**
   - Check ceiling (Section 4.6.2). If would exceed AND prune cannot
     free: increment `cache_ceiling_hard_aborts`, return false without
     taking `addFrameRef` (RC3 preserved).
   - `addFrameRef(frame)`. Increment `cache_addframeref_total`.
   - Insert into the appropriate pool. Update `cache_index`.
   - If insertion fails: `freeFrame(frame)`, increment
     `cache_freeframe_total` (RC3 rebalance). Return false.
   - Run `prune_after_store`.
   - Return success.

**Why idempotency matters:** Without it, two overlapping recovery walks
both computing `output[N]` and racing to store would either overwrite
(leaking the first frame's cache-side ref) or double-reference the same
slot. Either breaks the ref-count invariant (FM7). With idempotency,
the first store wins; the second is a no-op from the cache's perspective.

**Diagnostic interpretation:** High `duplicate_store_computed_but_discarded`
indicates overlapping recovery walks are common. This is a candidate for
later duplicate-work suppression. Not implemented in this iteration.

**Decision-log mirror note (CMS06.7):** Any decision-log entry (handover
Document B) that mirrors first-in-best-dressed duplicate-store semantics
must carry this implementation consequence:
`cnr3_output_cache_store_frame()` returns `true` for duplicate/already-cached
frame numbers; the first stored frame remains the source of truth; in the
duplicate case the cache does not take ownership of the caller's supplied
frame, so the caller still owns its local frame and must release it with
`freeFrame()` on every exit path — exactly as it must after a new insertion
where the cache took its own independent `addFrameRef`. (The decision log
itself lives in handover Document B, not in this design authority.)

### 4.10 Sequential Fast Path — Cached Predecessor Authority

**Status: Proven and activated through CMS02-H15.5 (CMS06.8).**

After CMS02-H15.5, the selected output-cache authority path has a proven
sequential fast path for eligible frames. This is the hot path: when the
immediate predecessor output is already cached, there is no need to
recompute a bounded window.

**Eligibility (all must hold):**
- requested frame N must be greater than 0;
- `output_cache[N-1]` must be found with
  `cnr3_output_cache_find_frame_and_add_ref()`;
- source frame N must have been requested in `arInitial` and must be
  retrievable in `arAllFramesReady` (VS-LIFECYCLE-01, Section 2.3);
- output N must be computed through the existing explicit-predecessor
  processing boundary;
- all caller-owned references must have a release or transfer path;
- `old_strict_cache` state must not be mutated or used as selected output
  authority.

**Fast-path operation (H15.5 committed behaviour — predecessor looked up
in `arAllFramesReady`):** The forward reserved-predecessor variant that
removes the `arAllFramesReady` re-lookup is specified in Section 4.10.1 and
is proven from H15.6B.2 onward.
```text
1. Look up output_cache[N-1]; take a caller-owned predecessor reference.
2. Retrieve source frame N.
3. Allocate local output frame N.
4. Compute output N using process_cnr3_frame_with_explicit_previous_output()
   or the currently named equivalent explicit-predecessor boundary.
5. Store output N in output_cache. Store idempotency still applies
   (Section 4.9).
6. Release the local output reference after the store path has taken any
   cache-owned reference it needs, unless that local reference is
   explicitly transferred by a later proven phase.
7. Release source frame N.
8. Release predecessor lookup reference N-1.
9. Look up output_cache[N]; transfer that caller-owned lookup reference as
   the returned frame.
```

**Frame 0 ineligibility:** Frame 0 has no predecessor. It must use
reset/start or bounded-warmup normal-path handling unless a later phase
explicitly supersedes that handling. In the H15.5 proof, frame 0 returned
through `OUTPUT-CACHE-AUTHORITY-NORMAL-PATH-RETURN` while frames 1..19
returned through `OUTPUT-CACHE-AUTHORITY-SEQUENTIAL-FAST-PATH-RETURN`.

**Why this rule matters:** It prevents future work from falling back to
bounded-window recomputation in the hot sequential case when a valid
cached predecessor is already available. It also keeps the fast path
inside the output-cache authority model, never reaching back into old
strict state (Section 13.17).

**Proof-coverage scope (CMS06.9):** The sequential fast path is proven
through H15.5 for the hot sequential case (N > 0, `output_cache[N-1]`
present). The complementary **predecessor-missing fallback case** — N > 0
with `output_cache[N-1]` absent, where the fast path must decline and a
fallback path must compute/recover output N, store it, and return it from
`output_cache` without using or mutating old strict state — is settled by
design but **not yet proven** in the selected output-authority path. It is
covered by H16.3 (fallback return-transfer proof) and H16.4 (out-of-order
fallback validation) in Section 8. Active arInitial source-request
reduction (H15.6B.3) must not precede the fallback proof, because
under-requesting source frames before fallback eligibility is fully sorted
could starve a fallback path (VS-LIFECYCLE-01, Section 2.3).

### 4.10.1 Reserved-Predecessor Model for Source-Request Reduction (Forward Design)

**Status: Settled design (CMS06.10). Proven progressively in H15.6B.1
through H15.6B.3. Not yet in committed behaviour.**

H15.6B reduces the `arInitial` source request for sequential fast-path
candidates from the conservative bounded-warmup window to source N only.
That reduction is only safe if the cached predecessor `output_cache[N-1]`
that justified the reduction is guaranteed to remain usable in
`arAllFramesReady` of the same activation. The naive form — check `N-1` in
`arInitial`, reduce, re-look-up `N-1` in `arAllFramesReady` — has a
time-of-check/time-of-use gap: if `N-1` is removed in the interval, the
bounded-warmup fallback would require source frames `N-2 .. N` that were
never requested in `arInitial`, which VS-LIFECYCLE-01 forbids.

**The reservation mechanism closes the gap by ownership, not by ordering:**

```text
arInitial (classification + reservation):
  call cnr3_output_cache_find_frame_and_add_ref(output_cache, N-1, vsapi)
    (atomic find-and-addref under cache_mutex)
  if it returns a frame:
    store the caller-owned ref in frameData (reserved_predecessor_frame)
    classify as class B (sequential fast-path eligible)
    H15.6B.3: reduce this request's source plan to source N only
  if it returns nullptr:
    do not reserve; classify as class C (predecessor missing / fallback)
    keep the conservative bounded-warmup source window

arAllFramesReady (consumption):
  if frameData holds a reserved predecessor ref:
    use it directly as the predecessor for computing output N
    do NOT re-look up output_cache[N-1]
    release the ref exactly once after use and set the field to nullptr
       (single-ownership / null-on-consume, Section 13.18)
```

**Why the held ref is sufficient (Appendix B property):** Once
`find_frame_and_add_ref` succeeds, the caller owns an independent
`addFrameRef` on the predecessor VSFrame. If the cache slot for `N-1` is
pruned or removed in the gap, the remove helper releases only the
*cache-owned* ref and erases the slot/index entry; it cannot free the
VSFrame while the caller-owned ref is outstanding. The predecessor
therefore remains valid for the fast path regardless of whether its cache
slot survived, and regardless of scheduling mode. This is the same
load-bearing property that makes sliding-zone pruning safe for in-flight
recovery walks.

**Relationship to VS-LIFECYCLE-01:** The reserved predecessor is a
cache-owned *output* frame referenced via `addFrameRef`, not a source frame
retrieved with `getFrameFilter`. VS-LIFECYCLE-01 governs source-frame
request/retrieve within a single callback activation and is not engaged by
carrying an output-frame reference across `arInitial → arAllFramesReady`.
Carrying per-request state across the two callbacks is the designed purpose
of `frameData`, which already carries the source-request plan.

**`frameData` becomes a frame owner:** Adding a reserved predecessor ref
makes `frameData` an owner of a caller-owned VapourSynth reference. Its
destroy/release path must release a non-null reserved ref on every exit
path. See Section 13.18 for the ownership rule, the single-ownership /
null-on-consume rule, the loss diagnostic, and the rejected alternative.

---

## 5. Constants

```
// --- Soft pruning targets ---

CNR3_OUTPUT_CACHE_CAPACITY        = 100
CNR3_OUTPUT_CACHE_OVERFLOW_FACTOR = 1.1
    Overflow threshold = 110 frames.
    Prune fires when pool size strictly exceeds 110 (i.e. at 111+).

// --- Hard ceiling (byte-budget based) ---

CNR3_CACHE_BYTE_BUDGET            = 1024 * 1024 * 1024  // 1 GiB
    Nominal byte budget used only at filter creation to derive
    active_ceiling. Runtime cache limit is a simple frame count.
    The 1 GiB value provides headroom for recursive recovery history
    under VapourSynth request jitter and modest seeks.

CNR3_CACHE_MIN_HARD_CEILING       = 150 frames
    Lower bound on active_ceiling. Intentional even if large formats
    exceed the nominal byte budget, because the recursive recovery
    design needs enough frame history to be useful and safe.

CNR3_CACHE_MAX_HARD_CEILING       = 1000 frames

// --- Checkpoints ---

CNR3_CHECKPOINT_INTERVAL          = 10
    Promote every 10th frame (and frame 0) to checkpoint pool.

CNR3_CHECKPOINT_MAX_RETAIN        = 32
    Soft trigger: checkpoint prune runs when pool exceeds this.
    Checkpoints in hot zones are retained regardless of this limit.

CNR3_CHECKPOINT_MIN_RETAIN        = 10
    Prune back to this count when eligible candidates exist.

// --- Hot zones ---

CNR3_HOT_ZONE_FORWARD_RADIUS      = 10
    Frames ahead of hot zone high boundary protected from pruning.
    Supported by simulation: covers p99 BestSource jitter up to
    approximately jitter_max=8.

CNR3_HOT_ZONE_BACK_RADIUS         = 50
    Frames behind hot zone low boundary protected from pruning.
    Covers 5 checkpoint intervals of backward history.
    Subject to empirical tuning after Phase CMS02-E.

CNR3_MAX_HOT_ZONES                = 5
    Maximum simultaneous active hot zones. Covers 1 linear encoding
    zone plus up to 4 concurrent jump zones.

CNR3_HOT_ZONE_JUMP_THRESHOLD      = FORWARD_RADIUS + BACK_RADIUS + 1
                                  = 61
    A new frame request allocates a new hot zone if it falls outside
    all existing zones by more than this threshold. Within this
    distance, the nearest zone is slid instead.
```

---

## 6. Diagnostics — Definitive Counter Specification

All counters are `int64_t` members of `Cnr3OutputCacheStats`.

**Hot zone counters:**
- `hot_zone_allocations`
- `hot_zone_slides` (bounds actually moved on update)
- `hot_zone_hits` (bounds already covered F; no movement needed)
- `hot_zone_merges`
- `hot_zone_retirements`
- `hot_zone_new_zone_requests`
- `hot_zone_max_active_observed`
- `hot_zone_updates_at_arInitial`

**Pruning counters:**
- `non_checkpoint_prune_skipped_in_hot_zone`
- `non_checkpoint_prune_skipped_pinned`
  (RESERVED — only meaningful after Phase CMS02-I if pinning added)
- `checkpoint_prune_skipped_in_hot_zone`
- `prune_no_candidate_exists`
- `cache_ceiling_hard_aborts`

**Recovery counters:**
- `bounded_warmup_recovery_count`
- `bounded_warmup_recovery_last_start_frame`
- `bounded_warmup_recovery_last_length`
- `recovery_frames_computed`
- `recovery_frames_skipped_already_cached`
- `holes_filled`
- `duplicate_computation_avoided`
- `nearest_checkpoint_recovery_count`
- `no_prior_checkpoint_recovery_count`
- `max_recovery_chain_length_observed`

**Cache operation counters:**
- `cache_hits_at_arAllFramesReady`
- `cache_misses`
- `recoveries_started_at_arAllFramesReady`
- `predecessor_missing_when_expected`
  *** CRITICAL — non-zero triggers mandatory non-checkpoint pinning
  promotion (Section 4.4). Prominent warning regardless of gate setting.
- `checkpoint_missing_when_expected`
- `max_live_cached_frames_observed`
- `max_non_checkpoint_pool_size_observed`
- `max_checkpoint_pool_size_observed`

**Store/duplicate counters:**
- `store_skipped_already_cached`
- `duplicate_store_computed_but_discarded`
  (verbose name deliberate — makes clear computation was wasted even
  though cache state remained correct)

**Reserved-predecessor counters (CMS06.10 — H15.6B reservation model,
Section 4.10.1 and Section 13.18):**
- `reserved_predecessor_acquired`
  (incremented when `find_frame_and_add_ref(N-1)` succeeds in `arInitial`
  and the ref is stored in `frameData`)
- `reserved_predecessor_consumed`
  (incremented when the fast path consumes the carried ref in
  `arAllFramesReady` and nulls the `frameData` field)
- `reserved_predecessor_released_by_cleanup`
  (incremented when `frameData` cleanup releases a still-non-null reserved
  ref — e.g. an error path before consumption)
- `reserved_predecessor_expected`
  (set when a request was classified class B and reduced)
- `reserved_predecessor_present`
  (set when the carried ref is actually available at consumption time)
- `reduced_fastpath_predecessor_lost`
  *** CRITICAL — must read 0. Non-zero means a request was reduced on the
  expectation of a carried predecessor that was then absent at consumption:
  a lost owned ref or a failed `frameData` carry, i.e. a discipline-failure
  invariant breach, never normal operation. Prints a prominent warning
  regardless of diagnostic gate setting (same policy tier as
  `predecessor_missing_when_expected`).
- Reservation balance invariant at quiescent points:
  `reserved_predecessor_acquired ==
   reserved_predecessor_consumed + reserved_predecessor_released_by_cleanup`

**Cache-side reference-count counters:**
- `cache_addframeref_total`
- `cache_freeframe_total`
- Invariant check at quiescence and shutdown:
  `cache_addframeref_total - cache_freeframe_total ==
   non_checkpoint_pool.size() + checkpoint_pool.size()`

**Caller-side reference-count counters (development diagnostic):**
- `lookup_owned_ref_acquired_total`
  (incremented inside `find_frame_and_add_ref` on success)
- `lookup_owned_ref_released_total`
  (incremented when a caller-owned lookup reference is `freeFrame`d)
- `lookup_owned_ref_transferred_total`
  (incremented when a caller-owned lookup reference is transferred to
  VapourSynth or another owner via `release()`)
- Caller-side diagnostic invariant at quiescent points:
  `acquired == released + transferred`
  Not part of the cache-side invariant; caller-side discipline only.

**Duplicate/recompute waste summary (near-term required implementation):**

The raw counters already exist and are printed in the machine-readable
output-cache summary:
- `store_attempts`
- `store_successes`
- `store_skipped_already_cached` (duplicate_skipped_already_cached)
- `duplicate_store_computed_but_discarded`

A required human-readable formatted block must be added as a near-term
implementation task (see Section 13.9). The block should appear at shutdown
in `cnr3_free` when `d->debug` is active, and must show:
- Frames computed exactly once (unique computations).
- Frames computed more than once (wasted duplicate work).
- Total duplicate computation count.
- Percentage of total computations that were wasted.

This block is diagnostic only. It must not affect output authority or
frame scheduling.

**Debug output policy:**
- Default: headline counters at `cnr3_free`.
- Dev diagnostics enabled: all counters plus hot zone state.
- Per-event verbose output guarded behind
  `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`.
- **No diagnostic output to stdout under any circumstances.**
- `predecessor_missing_when_expected > 0` prints prominent warning
  regardless of diagnostic gate setting.
- Ref-balance failure at shutdown prints prominent warning regardless
  of diagnostic gate setting.

---

## 7. Worked Examples

### Example A — Linear Encoding, No Jumps (fmUnordered, sliding)

Setup: 32-thread encode, BestSource jitter up to 6 frames. Cache empty.

| Arrival | Action | Zone 0 after | Pool size |
|---|---|---|---|
| F=0   | Allocate zone 0 | low=0, high=10 | 1 |
| F=50  | Slide | low=0, high=60 | ~50 |
| F=60  | Slide | low=10, high=70 | ~60 |
| F=100 | Slide | low=50, high=110 | ~100 |
| F=110 | Slide | low=60, high=120 | ~110 |
| F=111 | Slide; **prune fires** (111 > 110) | low=61, high=121 | back to ~100 |

Prune candidates: frames outside `[61, 121]`. Evict furthest-from-zone
first via single remove helper (RC2).

Predecessor for current computation always within zone. No predecessor
failures.

### Example B — Small Forward Jump Within JUMP_THRESHOLD

Setup: at F=80, zone 0 = `low=30, high=90`. F=95 arrives.

Distance from zone high (90): 5 frames. 5 ≤ 61. Within threshold.
Slide zone 0: `low = max(0, 95-50) = 45`, `high = 95+10 = 105`.

Cache lookup: output[94] may be present (hit) or absent (miss). On hit,
walk uses it via `find_frame_and_add_ref`. On miss, nearest checkpoint
found and pinned, rolling-predecessor walk fills holes, checkpoint
unpinned on every exit path.

### Example C — Large Forward Jump (fmParallelRequests, sliding)

Setup: sequential encoding at F=200 with three in-flight walks (200,
201, 202). Zone 0 last slid to F=202: `low=152, high=212`.

F=600 arrives. Distance from zone 0 high (212): 388 > 61. Jump detected.
Allocate zone 1: `low=550, high=610`.

Zone 0 remains active. In-flight walks for 200/201/202 have predecessors
within `[152, 212]`. Each walk holds `prev_ref` for its current
predecessor (Section 4.5.1). Even if prune fires and evicts a cache
slot, the walk's owned reference keeps the underlying VSFrame alive.

Bounded recovery for F=600: `start = max(0, 600-100) = 500`. Walk uses
rolling predecessor pattern. Frames 500–549 stored but outside both
zones — prunable. Walk has already transitioned `prev_ref` past those
frames; prune evicting them does not corrupt the walk.

Pre-jump walks complete. Zone 0 lazy-retired when no live frames remain
in its range and no pinned checkpoint is within it. Steady state: one
active zone around F=600.

### Example D — No-Prior-Checkpoint Recovery (fmUnordered, cold seek)

Setup: fresh instance, user seeks to F=800. Cache empty.

F=800 arrives. No active zones. Allocate zone 0: `low=750, high=810`.

`find_and_pin_nearest_prior_checkpoint` returns false. Increment
`no_prior_checkpoint_recovery_count`.

Bounded warm-up:
- `start = max(0, 800-100) = 700`
- output[700] = source-copy initialisation (deliberate approximation;
  no predecessor available)
- `prev_ref` = the walk's own ref to output[700]
- For K = 701..800: fill-holes-only walk using rolling predecessor
- At K=800: `prev_ref` holds the requested output frame. Return via
  `prev_ref.release()` — ownership transfers to VapourSynth.

Subsequent seeks to 700..800 range use checkpoints as anchors.
Cold-start approximation is confined to output[700].

### Example E — Hard Ceiling Abort

Setup: 16-bit 4:2:2 input. `estimated_frame_bytes ≈ 1.66 MB`.
`active_ceiling = floor(1 GiB / 1.66 MB) ≈ 647` (clamped to `[150,
1000]`).

User makes 7 rapid large seeks before any recovery completes. Seven
concurrent recovery walks each generating ~101 frames = ~707 total
demand. Ceiling = 647.

After ~647 stores, the next store would cause
`total_live_refs_after_store > 647`. Ceiling check fires. Prune: no
candidates (all frames within active hot zones). Store returns false
without taking `addFrameRef` (RC3). Increment `cache_ceiling_hard_aborts`.

Cleanup (Section 4.6.3): walk `freeFrame`s `prev_ref` and any other
held references, unpins any pinned checkpoint, releases any
source/destination frames. VS filter error returned. Filter remains
valid. Reference counters balanced.

### Example F — Fill-Holes-Only Avoiding Redundant Compute

Setup: output[150] already cached. Recovery walk from checkpoint[145]
toward target N=155 reaches K=150.

`find_frame_and_add_ref(150)`: cache hit. Increment
`recovery_frames_skipped_already_cached` and
`lookup_owned_ref_acquired_total`. Walk transitions: `freeFrame(prev_ref)`
(which held output[149]; increment `lookup_owned_ref_released_total`),
then `prev_ref = cached_150`. Skip computation. Continue loop to K=151.

### Example G — Duplicate Store Race (first-in-best-dressed)

Setup: two concurrent recovery walks A and B both compute output[200]
and race to store.

Walk A's `store_frame(200, frameA)` acquires mutex first:
- `cache_index[200]` does not exist → normal store path.
- `addFrameRef(frameA)`. Insert into pool. Update index.
- Increment `cache_addframeref_total`. Return success.
- Walk A then `freeFrame(frameA)` (its walk-side ref released).
- Cache holds the only ref to frameA.

Walk B's `store_frame(200, frameB)` acquires mutex:
- `cache_index[200]` now exists (frameA is the source of truth).
- First-in-best-dressed: return success without taking `addFrameRef`.
- Increment `store_skipped_already_cached` and
  `duplicate_store_computed_but_discarded`.
- Walk B then `freeFrame(frameB)` (its walk-side ref released).
- frameB's underlying VSFrame is destroyed. frameA remains in cache.

Reference counters balanced throughout. No leak, no double-free.

---

## 8. Phased Implementation Sequence

**Current state:** Phases CMS02-A through CMS02-E are complete. CMS02-F
cache-hit return is substantially implemented. CMS02-G proof sub-phases
through `CMS02-G / SubPhase G10D.8 / output-authority-transition-readiness-review`
are complete (all proof paths disabled in normal committed state).
See Section 14 for exact completion status.
Latest committed phase label: `Complete CMS02-G.10D.7 recovery-return-decision-dry-run`
Latest observed proof edit marker: `CMS02-G10D7-recovery-return-decision-dry-run-v1`

#### Phase CMS02-A — Documentation, constants, renames
**Status: Partially complete.** See Section 14.2 for what remains.
Remaining work: update stale comment in `cnr3_output_cache_manager.h`
(Section 13.2).

#### Phase CMS02-B — Hot zone structures and passive diagnostics
**Status: Complete.**

#### Phase CMS02-C — Hot zone update helpers
**Status: Complete.** Hard-wired `FmUnordered`. All zone lifecycle
events instrumented.

#### Phase CMS02-D — Hot zone aware prune candidate selection
**Status: Complete.** Hot-zone-aware candidate selection in prune loops.
Ceiling check and hard abort in store. First-in-best-dressed idempotency.
**Design Compliance Review: required before CMS02-E was started.**

#### Phase CMS02-E — Store/prune-only runtime proving
**Status: Complete.** Frames stored into `output_cache` after existing
strict-streaming path. `prune_after_store` called. Output cache not yet
output-authoritative. Ref-balance counters confirmed working.
**Design Compliance Review: complete.**

#### Phase CMS02-F — Cache-hit reuse under fmUnordered
**Status: Substantially implemented. Verify against current committed source.**

In source snapshots reviewed, the following CMS02-F mechanisms are implemented:
- `cnr3_output_cache_find_frame_and_add_ref()` — implemented.
- `arAllFramesReady` cache-hit lookup — implemented; first check before
  source-frame retrieval.
- `cnr3_output_cache_note_lookup_ref_transferred()` — implemented; called
  before returning cached frame.
- `CACHE-HIT-RETURN` log label and summary — implemented.
- Cache misses still fall through to source-frame retrieval and
  strict-streaming/new-computation path.

Still open or unverified:
- Full output-cache authority for cache misses — not yet transferred;
  misses still use strict-streaming computation.
- `Cnr3OwnedFrameRef` RAII wrapper — not implemented; explicit ref
  handling is the current acceptable approach (Section 2.2).
- Proof evidence in logs — verify `cache_hits_at_arAllFramesReady` and
  caller-side ref-balance counters in current committed test run.

CMS02-F is a prerequisite before CMS02-G becomes output-authoritative.
**End-of-phase: Design Compliance Review (mandatory before CMS02-G).**

#### Phase CMS02-G — Checkpoint recovery and hole filling (fmUnordered)
**Status: Proof scaffolding in progress. Output authority unchanged.**

Sub-phases completed (all proof paths disabled in normal committed state).
Expanded naming: `CMS02-G / SubPhase G10D.N / short-intent-name`. Compact
form `CMS02-G.10D.N` used in table for readability.

| Compact label | Expanded sub-phase name | Status | Notes |
|---|---|---|---|
| G.7A | CMS02-G / SubPhase G7A / source-request-plan-skeleton | Complete | Proof disabled in committed state |
| G.7B | CMS02-G / SubPhase G7B / lifecycle-proof | Complete | Proof disabled in committed state |
| G.7C | CMS02-G / SubPhase G7C / widened-source-request-proof | Complete | Proof disabled in committed state |
| G.8A | CMS02-G / SubPhase G8A / decision-walk-skeleton | Complete | Proof disabled in committed state |
| G.8B | CMS02-G / SubPhase G8B / checkpoint-selection-ref-rollover | Complete | Checkpoint rollover observed |
| G.8C | CMS02-G / SubPhase G8C / pre-store-probe | Complete | Probe moved pre-store; disabled state clean |
| G.8D | CMS02-G / SubPhase G8D / would-compute-detection | Complete | `would_compute=1` proven; disabled |
| G.9AB | CMS02-G / SubPhase G9AB / source-frame-set-acquire-release | Complete | Proof disabled in committed state |
| G.10ABC | CMS02-G / SubPhase G10ABC / dry-run-compute-orchestration | Complete | No real frames; no output authority change |
| G.10D.1 | CMS02-G / SubPhase G10D.1 / local-single-frame-compute-proof | Complete | Proof disabled in committed state |
| G.10D.2 | CMS02-G / SubPhase G10D.2 / local-bounded-walk-compute-proof | Complete | Proof disabled in committed state |
| G.10D.3 | CMS02-G / SubPhase G10D.3 / diagnostics-cleanup-proof | Complete | Proof disabled in committed state |
| G.10D.4 | CMS02-G / SubPhase G10D.4 / proof-scaffold-cleanup-review | Complete | Proof disabled in committed state |
| G.10D.5 | CMS02-G / SubPhase G10D.5 / local-bounded-walk-store-proof | Complete | Proof disabled in committed state |
| G.10D.6 | CMS02-G / SubPhase G10D.6 / recovery-store-sample-difference-measurement | Complete | `exact_match` diagnostic proven |
| G.10D.7 | CMS02-G / SubPhase G10D.7 / recovery-return-decision-dry-run | Complete | `actual_returned_recovered_output=0`; dry-run only |
| G.10D.8 | CMS02-G / SubPhase G10D.8 / output-authority-transition-readiness-review | Complete | Readiness reviewed; not yet transferred |
| G.10D.9+ | CMS02-G / SubPhase G10D.9+ / (next sub-phase) | **Next** | First actual recovered-frame return to VapourSynth |

Full implementation goals (when output authority is transferred):
- `find_and_pin_nearest_prior_checkpoint` for out-of-order requests.
- Implement rolling predecessor reference pattern (Section 4.5.1).
- Implement final-frame ownership transfer (Section 4.5.2).
- Fill missing frames ascending using fill-holes-only rule.
- Skip frames already present via first-in-best-dressed store.
- Unpin checkpoint on every exit path.
**End-of-phase: Design Compliance Review.**

#### Phase CMS02-G / SubPhase G10ABC / dry-run-compute-orchestration
**Status: Complete.** (Was: "Next recommended phase after CMS02-G.9AB.")

Purpose: prove the future recovery compute orchestration shape without
actual recovered-frame computation.

**Allowed in G.10ABC:**
- Prepare bounded recovery plan.
- Identify checkpoint and walk range.
- Inspect source-frame-set availability.
- Log would-compute steps and predecessor requirements.
- Prove cleanup paths.
- Disable all proof gates before normal commit.

**Not allowed in G.10ABC:**
- Allocate recovered output frames.
- Call `process_cnr3_frame()` for recovery computation.
- Store recovered outputs in the output cache.
- Return recovered outputs to VapourSynth.
- Mutate `d->old_strict_cache.prev_output`.
- Mutate `d->old_strict_cache.next_needed`.
- Change output authority.
- Enable fmParallelRequests or fmParallel.

Cross-reference: the G.10D precondition (Section 13.4) must be satisfied
before G.10ABC transitions to G.10D.

**End-of-phase: Design Compliance Review.**

#### Phase CMS02-G / SubPhase G10D.1–G10D.8 — Local recovery compute proofs
**Status: Complete through G10D.8.** All proof paths disabled in committed state.

G10D.1 through G10D.8 have progressively proven: local single-frame
computation, bounded-walk computation, diagnostics/cleanup, proof scaffold
review, bounded-walk store, recovery-store sample-difference measurement
(`exact_match` diagnostic), recovery-return decision dry-run
(`actual_returned_recovered_output=0`, `output_authoritative=0`), and
output-authority-transition readiness review.

The G-PAR-PRED-BOUNDARY-01 precondition (Section 13.4) was satisfied
during G10D work. The safe processing boundary with explicit predecessor
input is implemented.

#### Phase CMS02-G / SubPhase G10D.9+ — First actual recovered-frame return
**Status: Next. Preconditions satisfied.**

Purpose: return a locally computed recovered frame to VapourSynth from the
output cache for the first time, with full output-authority transfer for
recovered frames proven.

**Still required before full output authority transfers:**
- Recovered outputs stored as authoritative in output cache.
- Recovered outputs returned to VapourSynth (not just dry-run candidates).
- Output authority formally transferred from strict-streaming path.
- Design Compliance Review completed.

**End-of-phase: Design Compliance Review.**

#### Phase CMS02-H — Bounded warm-up recovery (fmUnordered)
**Status: Not started. H2A and H2B must precede H3 and later.**

The CMS02-H sequence includes the following sub-phases. H2A and H2B
are inserted before H3 following a design review that identified the
bounded checkpoint search contract gap (see Section 4.5.3).

#### CMS02-H / SubPhase H2A / bounded-checkpoint-search-contract-review
**Status: Superseded by H16.1 (CMS06.9).** The obligation is retained, not
dropped: H16.1 carries the bounded checkpoint-search contract closeout.
The original H2A description is preserved below for reference.

Purpose (original): review and confirm the bounded checkpoint search
contract (Section 4.5.3) before any implementation. Design confirmation
only — no code changes in this sub-phase.

Confirm:
- The search interval is `[max(0, N - B), N]`.
- The helper finds the greatest C in that interval.
- No checkpoint outside the interval is pinned.
- If no checkpoint in interval, return false with no pin.
- The unbounded helper must not be used inside
  `prepare_bounded_recovery_plan()`.

**End-of-sub-phase: written confirmation that contract is understood.**

#### CMS02-H / SubPhase H2B / bounded-checkpoint-search-helper-proof
**Status: Superseded by H16.2 (CMS06.9).** The obligation is retained, not
dropped: H16.2 carries the bounded checkpoint-search helper proof. The
original H2B description (including post-store proof placement) is
preserved below for reference.

Purpose (original): implement
`cnr3_output_cache_find_and_pin_checkpoint_in_interval()`
(Section 9.2.G2) and prove its behaviour with a small diagnostic bound.

**Proof placement — post-store, not pre-store:**
The H2B proof must run after `cnr3_output_cache_store_frame()` and
`cnr3_output_cache_prune_after_store()` for the current frame, not before.
This is distinct from the existing H2 pre-store diagnostic probe:

```text
H2 pre-store probe (existing, do not alter):
    frame 0: fires before store; checkpoint 0 not yet in cache
             -> no prior checkpoint; no plan; warm-up needed

H2B post-store proof (new):
    frame 0: fires after store; checkpoint 0 now in cache
             -> checkpoint 0 found in [0,0]; plan available
```

This is a timing distinction, not a contradiction. The two probes coexist.
Do not alter the existing H2 pre-store diagnostic scaffold to accommodate
H2B. Add H2B proof placement after store/prune independently.

Proof expectations (20-frame sequential test, bound B = 2,
checkpoints at every 10th frame: {0, 10}, proof runs post-store):

```text
frame 0:  search [0,0]  -> checkpoint 0 in interval -> plan available
frame 1:  search [0,1]  -> checkpoint 0 in interval -> plan available
frame 2:  search [0,2]  -> checkpoint 0 in interval -> plan available
frame 3:  search [1,3]  -> no checkpoint in [1,3]   -> warm-up needed
...
frame 9:  search [7,9]  -> no checkpoint in [7,9]   -> warm-up needed
frame 10: search [8,10] -> checkpoint 10 in interval -> plan available
frame 11: search [9,11] -> checkpoint 10 in interval -> plan available
frame 12: search [10,12]-> checkpoint 10 in interval -> plan available
frame 13: search [11,13]-> no checkpoint in [11,13] -> warm-up needed
...
frame 19: search [17,19]-> no checkpoint in [17,19] -> warm-up needed
```

Proof must confirm:
- Out-of-window checkpoints are never pinned.
- Successful bounded plans are unpinned on proof cleanup.
- Failed bounded plans leave no pins behind.
- Pin counts and cache/ref diagnostics remain clean throughout.
- Disable all proof gates before normal commit.

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H3 / bounded-warmup-plan-diagnostic
**Status: Complete (post-store diagnostic scaffold, proof disabled in
committed state).**

H3 is a post-store diagnostic that runs in `arAllFramesReady` after
store/prune. It can see checkpoint N if frame N was just stored. H3
diagnostics confirm: `would_request_source_frames=0`,
`would_retrieve_source_frames=0`, `would_compute_warmup_outputs=0`,
`output_authoritative=0`. H3 must not be altered.

#### CMS02-H / SubPhase H4 / bounded-warmup-source-frame-set-request-acquire-release
**Status: Complete / PASS. Proof paths disabled in committed state.**
Full proof evidence preserved in Section 14.7. Final edit marker:
`CMS02-H4-bounded-warmup-source-frame-set-request-acquire-release-v1-PASSED`.
The specification below is retained for design reference.

**Purpose:** Prove that a bounded warm-up source-frame set can be
requested in `arInitial`, retrieved in `arAllFramesReady`, held locally,
and released safely — without compute, store, return, or output-authority
change.

**Implementation choice — Option B (locked):**

Use a dedicated H4 plan structure. Do not repurpose the G-phase
`Cnr3ForDebugOnlyRecoverySourceRequestPlan`. The G-phase structure is
semantically checkpoint-recovery-specific and must remain so.

```text
Reuse the lifecycle pattern.
Do not reuse the semantic structure.
```

The H4 plan structure should be named along these lines:
    `Cnr3ForDebugOnlyBoundedWarmupSourcePlan`
or similar — clearly H4/warm-up specific, not recovery-plan specific.

It must be modelled on the proven G-phase lifecycle shape:
```text
arInitial:
    create H4 plan covering [max(0, N - proof_bound), N]
    store plan in frameData
    call requestFrameFilter() for each frame in the plan range

arAllFramesReady:
    read H4 plan from frameData
    call getFrameFilter() for each planned frame
    hold retrieved frames in a local per-invocation frame set
    release every retrieved frame before returning (every exit path)
    destroy H4 plan
```

**Why Option B over Option A:**

Option A (reuse G-phase structure) risk: dual-meaning structure creates
latent maintenance confusion not caught by any current proof.
Option B (dedicated H4 structure) risk: more code; possible copy/paste
ownership mistake. This risk is front-loaded and immediately caught by
the 57/57/57/0 proof balance check.
Option B is the correct engineering choice for this project.

**Conservative request window:**

```text
source_request_first = max(0, requested_frame - proof_bound)
source_request_last  = requested_frame
Request every source frame in [source_request_first, source_request_last].
```

This is deliberately conservative. It may request source frames for
frames whose outputs are already cached. This is acceptable in H4 because
H4 is proving ownership, not optimising request volume. Conservative
source requests do not violate first-in-best-dressed (Section 2.1).

**H3/H4 timing distinction (must not be conflated):**

```text
H3 post-store diagnostic (arAllFramesReady, AFTER store/prune):
    frame 10: checkpoint 10 just stored -> plan available, no source
              requests needed.

H4 arInitial request decision (BEFORE store/prune):
    frame 10: checkpoint 10 does not exist yet -> conservatively request
              source frames [8, 9, 10].
```

Do not alter H3 to accommodate H4. They coexist independently.

**What H4 must prove:**

```text
1. arInitial requests [max(0, N-B) .. N] for each frame N.
2. arAllFramesReady retrieves every H4-requested source frame.
3. Every retrieved frame held in local per-invocation frame set only.
4. Every retrieved frame released before return, on every exit path.
5. source_frames_requested_total == source_frames_retrieved_total
                                 == source_frames_released_total
6. source_frame_release_balance == 0 at end of each frame and shutdown.
7. partial_acquire_failures == 0.
8. proof_failures == 0.
9. would_compute_warmup_outputs == 0.
10. would_store_warmup_outputs == 0.
11. would_return_warmup_output == 0.
12. output_authoritative == 0.
```

**Expected proof summary (20-frame sequential run, B = 2):**

```text
frame 0:       request/retrieve/release [0]       count = 1
frame 1:       request/retrieve/release [0..1]    count = 2
frames 2-19:   request/retrieve/release [N-2..N]  count = 3 each

source_frames_requested_total  = 1 + 2 + (18 * 3) = 57
source_frames_retrieved_total  = 57
source_frames_released_total   = 57
source_frame_release_balance   = 0
```

**Not allowed in H4:**

```text
- Discover/request/retrieve source frames inside arAllFramesReady
  (VS-LIFECYCLE-01 violation).
- Use H3's post-store checkpoint decision to determine arInitial requests.
- Alter the H3 post-store diagnostic scaffold.
- Use or repurpose Cnr3ForDebugOnlyRecoverySourceRequestPlan for H4.
- Compute any warm-up output frame.
- Store any warm-up output frame in the output cache.
- Return any warm-up output frame to VapourSynth.
- Change output authority (output_authoritative must remain 0).
- Enable fmParallelRequests or fmParallel.
- Modify d->old_strict_cache.prev_output or next_needed.
```

**H4 proof gates must be disabled before normal commit.**

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H5 / bounded-warmup-local-compute-proof
**Status: Complete / PASS. Proof paths disabled in committed state.**

H5 proved local bounded warm-up computation using the H4 source-frame
request/acquire/release lifecycle and the existing explicit-predecessor
frame-processing boundary. H5 covered:

```text
H5.1 / zero-start local rolling compute proof
    Proved local compute from 0..N.

H5.2 / bounded-start policy review/proof
    Proved S > 0 bounded-start behaviour using explicit reset/start
    semantics (Section 4.5.4).
```

H5 did not store warm-up outputs, did not return warm-up outputs, did not
change output authority, and did not mutate old strict-streaming state.
Full proof evidence preserved in Section 14.7. Final edit marker:
`CMS02-H5-bounded-warmup-local-compute-proof-v1-PASSED`.

The H6 through H15.5 sub-phases below are complete / PASS. H6 retains its
original PASS criteria and proof-summary field requirements (CMS06.7) for
reference. H15.6A is the next recommended phase.

#### CMS02-H / SubPhase H6 / bounded-warmup-store-proof
**Status: Complete / PASS.**
Proved bounded-warmup local outputs can be stored with
first-in-best-dressed duplicate-store semantics and caller-side
local-frame release discipline.

**PASS criteria — duplicate counters (CMS06.7, retained):** Duplicate
counters must be observed and explained if duplicate stores occur, but
non-zero duplicate counters are not mandatory for PASS when the test
pattern produces no duplicate store attempts.

**Proof summary fields (CMS06.7, retained):** local_outputs_available_for_store,
store_attempts, store_successes, store_failures,
duplicate_skipped_already_cached, duplicate_computed_but_discarded,
local_outputs_released, local_output_release_balance,
would_return_warmup_output (0), output_authoritative (0),
mutates_old_strict (0). Use source counter names where they differ.

#### CMS02-H / SubPhase H7 / bounded-warmup-return-decision-dry-run
**Status: Complete / PASS.**
Proved return-decision shape without transferring/returning output.

#### CMS02-H / SubPhase H8 / bounded-warmup-return-transfer-proof
**Status: Complete / PASS.**
Proved lookup-ref transfer/return path for bounded warm-up output.

#### CMS02-H / SubPhase H9 / bounded-warmup-authority-integration-proof
**Status: Complete / PASS.**
Integrated output-cache authority proof path with selected plan selection.

#### CMS02-H / SubPhase H10 / old-strict-state-bypass-proof
**Status: Complete / PASS after plan-selection fix.**
Proved selected path can bypass old strict state.

#### CMS02-H / SubPhase H11 / old-strict-quarantine-proof
**Status: Complete / PASS.**
Proved old strict state is not output/predecessor/return authority and is
not mutated by the selected path.

#### CMS02-H / SubPhase H13 / old-strict-streaming-gate-quarantine-proof
**Status: Complete / PASS.**
Proved old strict `next_needed` streaming gate does not reject the
selected out-of-order proof path.

(Note: there is no separate H12 sub-phase in the implemented sequence;
H11 and H13 cover the old-strict quarantine work.)

#### CMS02-H / SubPhase H14.1–H14.5 / selected output-cache authority normalisation
**Status: Complete / PASS.**
Normalised selected output-cache authority path naming from temporary
cutover language toward normal-path and output-cache-authority helper
naming.

#### CMS02-H / SubPhase H15.1 / output-cache authority normal-path scaffold
**Status: Complete / PASS.**
Proved selected normal-path labels and gates without behavioural
regression.

#### CMS02-H / SubPhase H15.2 / sequential predecessor-cache reuse probe
**Status: Complete / PASS.**
Proved cached output N−1 is available and lookup refs can be released
cleanly in sequential operation.

#### CMS02-H / SubPhase H15.3 / sequential fast-path dry run
**Status: Complete / PASS.**
Proved that eligible sequential frames would reuse predecessor N−1,
request current source N only, and compute current output N only.

#### CMS02-H / SubPhase H15.4 / sequential fast-path compute/store proof
**Status: Complete / PASS.**
Proved compute/store using cached output N−1 plus source N, while still
falling through to the existing normal return path.

#### CMS02-H / SubPhase H15.5 / sequential fast-path return-transfer proof
**Status: Complete / PASS.**
Proved eligible sequential frames after frame 0 can compute, store, look
up, transfer, and return through
`OUTPUT-CACHE-AUTHORITY-SEQUENTIAL-FAST-PATH-RETURN`. See Section 4.10 for
the codified rule and Section 14.8 for proof evidence.

The H15.6/H15.7 sequence in CMS06.8 has been refined (CMS06.9). The
previous plan would have reduced arInitial source requests before the
predecessor-missing fallback case is proven, risking under-requesting
source frames for a fallback path. The revised sequence below interposes a
classification probe and defers active reduction until fallback proof
coverage exists.

#### CMS02-H / SubPhase H15.6A / arInitial request classification probe
**Status: Next recommended phase. No behaviour change.**

Purpose: prove that `arInitial` can classify each request as one of:

```text
A. frame 0
B. sequential fast-path candidate (N > 0, output_cache[N-1] expected)
C. predecessor missing / fallback needed
D. non-sequential / uncertain request
```

For classes A, C, and D, the conservative bounded-warmup source request
plan must be kept. For class B, the probe may log that a future phase would
request only source N. This phase must not change the requested frame set;
it proves the classification does not accidentally starve fallback paths.

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H15.6B / active source-plan reduction — restructured (CMS06.10)

**Superseded-draft warning (CMS06.11):** Do not use the earlier
fail-closed-only H15.6B active source-request reduction patch as the coding
baseline. It is superseded (CMS06.10-9). H15.6B implementation starts at
H15.6B.1 against CMS06.10/CMS06.11, using the reserved-predecessor model
(Section 4.10.1, Section 13.18).

The single H15.6B sub-phase is replaced by a three-way split adopting the
reserved-predecessor model (Section 4.10.1, Section 13.18). The split keeps
frame-ownership lifecycle, predecessor-sourcing behaviour, and
source-request behaviour each separately provable (durable rule 13.14). The
earlier fail-closed-only draft patch is retired as superseded (CMS06.10-9);
H15.6B coding starts from H15.6B.1.

##### CMS02-H / SubPhase H15.6B.1 / arInitial predecessor reservation lifecycle proof
**Status: Pending CMS06.10 adoption. No source-request reduction; no
fast-path consumption change.**

Purpose: prove the reserved-predecessor *carry lifecycle* in isolation.

```text
- Upgrade frameData to own a reserved predecessor VSFrame* field.
- Upgrade the frameData destroy/release path to release a non-null
  reserved ref with freeFrame() and record
  cnr3_output_cache_note_lookup_ref_released() on EVERY exit path
  (success, fallback, setFilterError, partial-acquire, compute/store
  failure, unexpected-activation fallback, any early return after
  frameData detach).
- For class-B candidates, acquire output_cache[N-1] in arInitial via
  cnr3_output_cache_find_frame_and_add_ref() and store the ref in frameData.
- Carry the ref across arInitial -> arAllFramesReady.
- Release it via the cleanup path (consumption is NOT yet wired).
- Do NOT reduce the source request.
- Do NOT change how the fast path sources its predecessor.
```

Prove:
```text
- reserved_predecessor_acquired increments for class-B candidates;
- reserved_predecessor_released_by_cleanup matches acquisitions
  (consumption path not yet active, so cleanup releases all);
- reservation balance invariant holds (Section 6);
- lookup_ref_balance returns to 0;
- no checkpoint pin activity is introduced (reservation is addref, not pin);
- find_frame_and_add_ref() is never called while holding cache_mutex;
- output_authoritative behaviour unchanged from H15.5;
- mutates_old_strict=0.
```

**End-of-sub-phase: Design Compliance Review.**

##### CMS02-H / SubPhase H15.6B.2 / reserved-predecessor fast-path consumption proof
**Status: Pending H15.6B.1. No source-request reduction yet.**

Purpose: consume the carried ref as the actual fast-path predecessor and
prove the single-ownership / null-on-consume rule.

```text
- In arAllFramesReady, when frameData holds a reserved predecessor ref,
  use it directly as the predecessor for computing output N.
- Eliminate the arAllFramesReady re-lookup of output_cache[N-1] for the
  reserved case.
- On successful consumption: release the ref (or transfer as designed),
  then set the frameData field to nullptr.
- frameData cleanup releases the ref only if the field is still non-null.
- Keep conservative source requests (still request the bounded-warmup
  window; reduction is H15.6B.3).
```

Prove (single-ownership / null-on-consume, Section 13.18):
```text
- reserved_predecessor_consumed increments on the fast path;
- the field is nulled on consume so cleanup does not double-release;
- no double-release: cache addframeref/freeframe balance and
  lookup_ref_balance both return to 0;
- no leak: reservation balance invariant holds
  (acquired == consumed + released_by_cleanup);
- error interleavings between consume and frameData destroy are covered
  (force at least one error path after acquisition but before consume);
- reduced_fastpath_predecessor_lost=0;
- mutates_old_strict=0.
```

Required PASS evidence fields (CMS06.11) — consumed path:
```text
reserved_predecessor_expected=1
reserved_predecessor_present_before_consume=1
reserved_predecessor_consumed=1
reserved_predecessor_field_null_after_consume=1
reserved_predecessor_released_by_cleanup=0   (for the consumed refs)
reserved_predecessor_double_release_prevented=1
```

Required PASS evidence fields (CMS06.11) — unconsumed / forced-error path:
```text
reserved_predecessor_consumed=0
reserved_predecessor_released_by_cleanup=1
reserved_predecessor_field_null_after_cleanup=1
```

In both cases the caller-side lookup-ref invariant must hold:
`lookup_owned_ref_acquired_total == lookup_owned_ref_released_total +
lookup_owned_ref_transferred_total`, with the reserved predecessor counted
as **released**, not transferred (it is an input, not the returned frame).

**End-of-sub-phase: Design Compliance Review.**

##### CMS02-H / SubPhase H15.6B.3 / active sequential source-request reduction
**Status: Pending H15.6B.2 evidence AND H16.3 fallback proof.**

Behaviour change, narrow. For frames classified as sequential fast-path
eligible (class B, i.e. a reserved predecessor was acquired in `arInitial`):
request only source N. For all other classes (A frame-0, C
predecessor-missing/fallback, D non-sequential/uncertain): keep the
bounded-warmup source window.

```text
Precondition 1: H15.6B.2 reserved-predecessor consumption is proven, so a
  class-B request no longer depends on an arAllFramesReady re-lookup of N-1.
Precondition 2: the predecessor-missing fallback case is proven (H16.3),
  because reducing source requests before fallback eligibility is fully
  sorted could starve a fallback path (VS-LIFECYCLE-01, Section 2.3).
```

Prove:
```text
- class-B requests reduce to source N only; other classes stay conservative;
- the reserved predecessor (not a re-lookup) supplies the fast-path
  predecessor for every reduced request;
- reduced_fastpath_predecessor_lost=0 across sequential AND out-of-order
  patterns (the fail-closed branch must remain unreached);
- all ownership balances clean; mutates_old_strict=0.
```

If `reduced_fastpath_predecessor_lost` ever increments, treat it as an
invariant breach (Section 13.18), not expected operation: stop and
investigate the lost ref / failed carry.

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H16.1 / bounded-checkpoint-search-contract-closeout
**Status: Pending. Carries the former H2A obligation.**

Purpose: close out the bounded checkpoint-search contract as an
implementation/proof item (the contract itself is already settled design
authority — Section 4.5.3). Confirm:

```text
- the CMS06.7/Section 4.5.3 bounded checkpoint-search contract remains current;
- whether the current committed code has the bounded helper
  cnr3_output_cache_find_and_pin_checkpoint_in_interval() (Section 9.2.G2);
- the unbounded nearest-prior helper is not used inside bounded recovery planning.
```

If the bounded helper is absent, H16.1 records that H16.2 must implement
it. This formally closes SubPhase H2A.

**End-of-sub-phase: written confirmation; Design Compliance Review.**

#### CMS02-H / SubPhase H16.2 / bounded-checkpoint-search-helper-proof
**Status: Pending H16.1. Carries the former H2B obligation.**

Purpose: implement (if absent) and prove
`cnr3_output_cache_find_and_pin_checkpoint_in_interval()` (Section 9.2.G2).
Proof placement is post-store, distinct from the older pre-store
diagnostic probe (see the preserved H2B description above). Prove:

```text
- search interval = [max(0, N - B), N];
- the greatest checkpoint in the interval is selected;
- out-of-window checkpoints are never pinned;
- failed searches leave no pin;
- successful searches unpin on cleanup;
- pin counts remain balanced.
```

This formally closes SubPhase H2B.

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H16.3 / predecessor-missing fallback return-transfer proof
**Status: Pending H16.2. This is the key fallback-coverage proof.**

Purpose: force and prove the case the sequential fast path does not cover:

```text
N > 0
output_cache[N-1] is missing
fast path declines authority
fallback computes or recovers output N
   (bounded warm-up and/or checkpoint-start recovery, per Sections 4.5, 4.5.3, 4.5.4)
output N is stored in output_cache
output N is looked up and transferred as the returned frame
old_strict_cache state is not mutated or used as authority
```

This proves predecessor-missing fallback authority within the
output-cache model. Until H16.3 passes, full predecessor-missing fallback
authority must not be claimed (Section 4.10 proof-coverage scope).

**End-of-sub-phase: Design Compliance Review.**

#### CMS02-H / SubPhase H16.4 / out-of-order fallback validation
**Status: Pending H16.3.**

Purpose: validate fast-path / fallback selection under out-of-order
request patterns, for example:

```text
[1, 0, 3, 2]
[0, 2, 1, 3]
[5, 0, 1, 2]
```

Expected:

```text
if output_cache[N-1] exists  -> fast path may return (Section 4.10);
if output_cache[N-1] missing -> fallback path returns, not old strict.
```

**End-of-sub-phase: Design Compliance Review.**

#### Phase CMS02-I — Empirical review: non-checkpoint pinning decision
After realistic VHS/VHS-C encode tests and synthetic jump tests:
- Inspect all Section 6 counters, especially
  `predecessor_missing_when_expected` and ref-balance counters.
- If mandatory promotion criteria (Section 4.4) are met: implement
  non-checkpoint pinning before proceeding.
- If criteria are not met: document findings and proceed to CMS02-J.
**End-of-phase: Design Compliance Review.**

#### Phase CMS02-J0 — Pre-fmParallelRequests cleanup and observability review
**Status: Mandatory future checkpoint. Must precede CMS02-J.**

CMS02-J must not start until CMS02-J0 has been evaluated and performed,
or until specific intentional deferrals have been explicitly documented
with reasons, scope, and expected safety impact.

CMS02-J0 must review at least:

```text
- obsolete proof-only scaffolds;
- accumulated proof gates and proof-only data structures;
- diagnostic verbosity and compile-time gating;
- safety/health counters that should remain non-gated;
- high-volume traces and temporary maps that should be gated or removed;
- source lifecycle observability;
- hot-zone observability;
- checkpoint and non-checkpoint recovery observability;
- fill-holes, duplicate, and first-in-best-dressed observability;
- cache store/prune/remove/clear/ceiling observability;
- lookup-ref transfer/release observability;
- cache addFrameRef/freeFrame balance;
- missing predecessor/checkpoint/refusal diagnostics;
- memory diagnostics and summaries;
- whether mature proof/diagnostic helpers should be moved out of
  vapoursynth-Cnr3.cpp into dedicated diagnostic/observability
  translation units.
```

See Section 13.15 for the named checkpoint rule and Section 13.16 for the
compile-time diagnostics consolidation deliverable.

#### Phase CMS02-J — fmParallelRequests wiring and proving
Only after:
- CMS02-H is complete through the required output-cache authority
  readiness point;
- CMS02-I empirical non-checkpoint pinning decision is complete;
- CMS02-J0 pre-fmParallelRequests cleanup and observability review has
  been evaluated and performed, or specific deferrals have been
  explicitly documented.
- `cnr3_output_cache_update_hot_zones()` is already called from `arInitial`
  (confirmed in current code — this prerequisite is satisfied).
- Wire fmParallelRequests path: same sliding update helper (already
  implemented), retirement helper invoked with `FmParallelRequests`.
- Test concurrent jump scenarios.
- Validate retirement with pinned-checkpoint proxy.
- Decide on `active_request_count` per zone if retirement proves too
  conservative.
**End-of-phase: Design Compliance Review.**

#### Full fmParallel — final operational target; deferred pending fmParallelRequests proving.
Design and coding must not introduce shared current-request state or
ordering assumptions that would block future fmParallel compatibility.

---

## 9. Structural Changes — Current Naming

### 9.1 Current Active Naming

**[CONFIRMED CMS06 — derived from reading uploaded source files. The
inline document versions (vapoursynth-Cnr3.cpp, cnr3_output_cache_manager
.h/.cpp, cnr3_common.h) are the authoritative current state. The
disk-uploaded cnr3_cache_manager.h/.cpp and cnr3_common.h are pre-rename
versions and are superseded.]**

**Types:**

```cpp
Cnr3OutputCacheManager      // formerly Cnr3CacheManagerV005
OldCnr3StrictStreamCache    // formerly Cnr3CacheManager
Cnr3OutputCacheStats        // in cnr3_output_cache_manager.h
Cnr3CheckpointSlot          // unchanged
Cnr3HotZone                 // CMS02-B addition
Cnr3CacheSchedulingMode     // CMS02-C addition
Cnr3OwnedFrameRef           // recommended RAII wrapper, not yet implemented;
                               //   explicit ref handling is current acceptable approach
```

**`Cnr3Data` members:**

```cpp
OldCnr3StrictStreamCache old_strict_cache;  // formerly: cache
Cnr3OutputCacheManager   output_cache;      // formerly: cache_manager_v005
```

**Helper function prefixes:**

```cpp
cnr3_output_cache_*     // active prefix for output cache helpers
old_cnr3_strict_cache_* // active prefix for old strict cache helpers
```

**Files:**

```
cnr3_output_cache_manager.h    // formerly cnr3_cache_manager.h
cnr3_output_cache_manager.cpp  // formerly cnr3_cache_manager.cpp
old_cnr3_strict_cache.h        // formerly cnr3_cache.h (approx)
cnr3_common.h                  // updated to use new names
vapoursynth-Cnr3.cpp           // updated to use new names
cnr3_build_config.h            // CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS now defined
```

**Old naming — do not use in new code:**

```cpp
Cnr3CacheManagerV005          // use Cnr3OutputCacheManager
Cnr3CacheManager              // use OldCnr3StrictStreamCache
cache_manager_v005            // use output_cache
cache (in Cnr3Data)           // use old_strict_cache
cnr3_cache_manager_*          // use cnr3_output_cache_*
CNR3_CACHE_MANAGER_DEV_DIAGNOSTICS  // use CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS
v005 in comments              // use CMS05 or current phase reference
```

### 9.2 New Helpers Required (Phases CMS02-F onward)

**G2. Bounded checkpoint search helper (required for CMS02-H):**

`cnr3_output_cache_find_and_pin_checkpoint_in_interval(cache, N, B,
    checkpoint_frame_number)`:

Required before `CMS02-H / SubPhase H2B`. This helper must:

1. Lock `cache_mutex`.
2. Compute `lower_bound = max(0, N - B)`.
3. Scan `checkpoint_pool` in reverse frame-number order (highest first).
4. Find the first checkpoint C such that `lower_bound <= C <= N`.
5. If found: `addFrameRef` is NOT taken (pin_count only); increment
   `slot.pin_count`; set `checkpoint_frame_number = C`; unlock; return true.
6. If not found: unlock; return false without touching any checkpoint.

The existing unbounded helper
`cnr3_output_cache_find_and_pin_nearest_prior_checkpoint()` searches
backward from N with no lower bound. It must not be used inside
`prepare_bounded_recovery_plan()`. The two helpers serve different
purposes:

| Helper | Bounded? | Use case |
|---|---|---|
| `find_and_pin_nearest_prior_checkpoint` | No | General recovery; caller applies own acceptance logic |
| `find_and_pin_checkpoint_in_interval` | Yes | Bounded recovery planning; no out-of-scope pinning |

**H. Cache hit lookup — defensive contract:**

`cnr3_output_cache_find_frame_and_add_ref(cache, frame_number, vsapi)`:

1. Lock `cache_mutex`.
2. Find `frame_number` in `cache_index`. If not found: increment
   `cache_misses`, unlock, return nullptr.
3. Verify the indexed owner pool actually contains `frame_number`. If
   not: increment `cache_index_inconsistency_detected`, log warning,
   unlock, return nullptr.
4. Verify the stored `VSFrame*` is non-null. If null: same as step 3.
5. Call `vsapi->addFrameRef(frame)`. Increment
   `lookup_owned_ref_acquired_total`.
6. Increment `cache_hits`.
7. Unlock `cache_mutex`.
8. Return the caller-owned `VSFrame*`.

Caller must `freeFrame` the returned reference on every exit path (RC5).
Use of `Cnr3OwnedFrameRef` at the call site is strongly recommended.

### 9.3 Failure-Path and Shutdown Discipline

Every failure path returning a VS error must execute cleanup:

1. Any checkpoint pinned during this operation: `unpin_checkpoint` once.
2. Any caller-owned VSFrame references: `freeFrame` once. Use
   `Cnr3OwnedFrameRef` RAII to make this automatic.
3. Any source frame references obtained from VapourSynth: `freeFrame`.
4. Any destination frame allocated but not returned: `freeFrame`.
5. Hot zone state: no rollback needed.
6. Diagnostic counters: still incremented as appropriate.

**Shutdown `clear()` (already implemented and verified):**

1. Acquire `cache_mutex`.
2. Iterate `non_checkpoint_pool`: `freeFrame` each frame, increment
   `cache_freeframe_total`, erase slot.
3. Iterate `checkpoint_pool`: if `pin_count > 0`, log warning (logical
   leak indicator); `freeFrame` each frame, increment
   `cache_freeframe_total`, erase slot.
4. Clear `cache_index`. Reset hot zones to inactive.
5. Run `validate_invariants` to confirm ref-balance.

---

## 10. Known Hazard Addressed by Hot-Zone Lifecycle Rules

**Hazard scenario (retained as canonical test case):**

> 1. Request A is computing output[450].
> 2. It needs output[449] as the predecessor.
> 3. output[449] is present in the non-checkpoint pool.
> 4. A forward jump creates a new hot zone around output[800].
> 5. The old hot zone around output[450] is shifted, merged, or retired.
> 6. Pruning sees output[449] as outside all hot zones and removes it.
> 7. Request A no longer has the predecessor it expected.

**Resolution by CMS06 design:**

- **Step 5 in fmUnordered:** The previous request has completed before
  this `arInitial` fires. Request A is not in flight at the time of the
  jump.

- **Step 5 in fmParallelRequests:** Lazy retirement (pinned-checkpoint
  proxy) prevents premature retirement of zones associated with active
  recovery walks. Sliding can occur, but the rolling predecessor
  reference pattern (Section 4.5.1) ensures Request A's walk already
  holds an owned reference to output[449] before any concurrent pruning
  could fire.

- **Step 6:** Even if a slide moves the zone past output[449] and a
  subsequent prune evicts the cache slot, the walk's owned `addFrameRef`
  reference keeps the underlying VSFrame alive until the walk releases
  it. Pruning removes the cache slot; the VSFrame is destroyed only when
  its reference count reaches zero, which the walk's reference prevents.

- **Runtime verification:** `predecessor_missing_when_expected` is the
  empirical detector. If it ever increments, non-checkpoint pinning
  becomes mandatory before further work (Section 4.4).

---

## 11. Items to Confirm Empirically

**EI1 — Lazy retirement proxy under fmParallelRequests.**
Accept the pinned-checkpoint proxy initially. If zones never retire, add
`active_request_count` per zone for exact retirement eligibility.

**EI2 — `BACK_RADIUS = 50` empirical sufficiency.**
Observe `recovery_frames_computed` and `cache_hits_at_arAllFramesReady`.
Increase if pruning proves too aggressive; decrease if pool stays near
ceiling under normal linear encoding.

**EI3 — Checkpoint retain values `MAX=32`, `MIN=10`.**
Observe `max_checkpoint_pool_size_observed`. Adjust if frequently hitting
the soft trigger during normal linear encoding.

**EI4 — Ceiling abort frequency.**
`cache_ceiling_hard_aborts` should be zero during normal linear encoding.
Any non-zero value during realistic VHS encode tests warrants review of
the byte budget or `CNR3_MAX_HOT_ZONES` constant.

**EI5 — `prune_no_candidate_exists` behaviour.**
Accept "do not evict protected frames" initially. If it increments
significantly during realistic tests, reduce `BACK_RADIUS` or
`CNR3_MAX_HOT_ZONES`, or add a fallback eviction policy.

**EI6 — Non-checkpoint pinning promotion decision (Phase CMS02-I).**
The most important empirical decision in the implementation sequence.
Mandatory criteria in Section 4.4.

**EI7 — Cache-side reference-count balance.**
`cache_addframeref_total - cache_freeframe_total` must equal total live
slots at quiescence and zero at shutdown after `clear()`. Deviation is
a real bug, not a tolerable approximation.

**EI8 — Caller-side reference-count balance.**
`lookup_owned_ref_acquired_total == released + transferred` at quiescent
points. Essential while caller-owned refs are load-bearing under the
deferred-pinning regime.

**EI9 — Duplicate-store frequency.**
`duplicate_store_computed_but_discarded` indicates overlapping recovery
walk computation waste. If high, future active-computation tracking or
duplicate-work suppression may be justified.

---

## 12. Design Compliance Review

### 12.1 Required coding rule

After completing each implementation phase (Section 8) or a coherent
block of phases, perform a design-compliance review of all changed code
paths and all unchanged helper functions invoked by those changed paths.

The review must verify that the resulting execution paths follow CMS06.9,
not older pre-rename or pre-CMS05 assumptions.

### 12.2 Verification checklist

1. **Mutex ownership** is correct at every access to mutable
   cache-manager state.
2. **`_externally_locked` helpers** called only while mutex held.
3. **Public helpers** that lock internally do not call other public
   locking helpers (deadlock risk).
4. **No old prune logic** remains in the active path.
5. **No direct `pool.erase()`** bypasses the single remove helper (RC2).
6. **No direct cache-owned `addFrameRef`** bypasses the single store
   helper (RC1).
7. **Store collision** follows first-in-best-dressed semantics (RC8).
8. **Store failure after `addFrameRef`** rebalances correctly (RC3).
9. **Lookup helper** takes `addFrameRef` atomically under mutex.
10. **Caller-owned lookup references** freed or transferred exactly once
    on every exit path (RC5).
11. **Checkpoint pins** unpinned on every exit path.
12. **Hot-zone state** not rolled back on frame failure.
13. **Cache-side ref-balance invariant** holds (RC7).
14. **Caller-side lookup-ref diagnostics** balance in development mode.
15. **Shutdown `clear()`** releases every cache-owned frame reference
    and clears all indexes (RC6).
16. **No diagnostics write to stdout.**

### 12.3 Review timing

- CMS02-A and CMS02-B may be reviewed together (structures, counters,
  passive diagnostics only).
- **CMS02-D must be reviewed before CMS02-E** (first runtime use of
  new store/prune behaviour).
- **CMS02-F must be reviewed before CMS02-G** (lookup-owned references
  and rolling predecessor correctness).
- All other phases require their own review.

### 12.4 Outcome

Each review produces: **Pass**, **Pass with notes**, or **Fail** (with
specific findings and what was done about them). Brief but specific.

---

## 13. Pending Code Issues

### 13.1 `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS` in `cnr3_build_config.h`

**Status: RESOLVED.**

`cnr3_output_cache_manager.h` references `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`
(used in `CNR3_OUTPUT_CACHE_VALIDATE_AFTER_MUTATION`). The updated
`cnr3_build_config.h` now defines:

```cpp
constexpr bool CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS =
    CNR3_DEV_DIAGNOSTICS;
```

The old constant `CNR3_CACHE_MANAGER_DEV_DIAGNOSTICS` has been removed
from `cnr3_build_config.h` and replaced by
`CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`.

**Action required:** grep the entire source tree for
`CNR3_CACHE_MANAGER_DEV_DIAGNOSTICS`. If any file still references the
old name, update it to `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`.

### 13.2 Stale phase comment in `cnr3_output_cache_manager.h`

**Status: Pending — comment only, no correctness impact.**

Near the bottom of `cnr3_output_cache_manager.h`:

```cpp
// This file contains only the data structures and constants for the future
// CMS05 output-frame cache manager.
//
// Phase 1 intentionally does not change current runtime behaviour.
// The existing strict-streaming cache remains active until later phases wire
// these structures into cnr3_get_frame().
```

This is stale. Phase 3A store/prune wiring is complete; the output cache
is live (non-output-authoritative). Suggested replacement:

```cpp
// CMS06 output-frame cache manager.
//
// Phase CMS02-E complete: output cache stores and prunes real produced
// frames for proving (non-output-authoritative).
// The strict-streaming cache remains the source of returned output.
// Cache-hit reuse, recovery walks, and bounded warm-up recovery are
// not yet wired (Phases CMS02-F through CMS02-H).
```

### 13.3 G-PAR-HZ-ARINITIAL-01 — Hot-zone update at arInitial

**Status: RESOLVED.**

Hot-zone updates must occur at `arInitial`, not `arAllFramesReady`, before
fmParallelRequests or fmParallel work. Under concurrent request modes,
deferring hot-zone update to `arAllFramesReady` can allow pruning decisions
to ignore active request intent.

The current committed code calls `cnr3_output_cache_update_hot_zones()`
from the `arInitial` branch of `cnr3_get_frame()`, before
`requestFrameFilter()`. This is correct and must be preserved.

**Implementation consequence:** Do not move hot-zone updates back to
`arAllFramesReady`. If future scheduling modes require changes to
`arInitial` handling, any replacement must register request activity at
least as early as the current `arInitial` call.

### 13.4 G-PAR-PRED-BOUNDARY-01 — Safe processing boundary before G.10D

**Status: RESOLVED. Satisfied during CMS02-G / SubPhase G10D work.**

`process_cnr3_frame()` currently obtains the recursive predecessor from:

```cpp
const VSFrame* prev_output = d->old_strict_cache.prev_output;
```

That is correct for the strict-streaming path, but unsuitable for actual
local recovery computation. Recovery must compute `output[K]` from an
explicit local predecessor without mutating strict-streaming state.

**Hard requirement:** Before CMS02-G.10D begins, a safe processing boundary
must exist that allows recovery code to compute `output[K]` from:
- `source[K]` (the source frame for K)
- an explicit previous filtered output frame for K−1
- local per-invocation recovery state

without modifying:
- `d->old_strict_cache.prev_output`
- `d->old_strict_cache.next_needed`
- normal strict-streaming output authority

**Preferred approach (not mandated):** Refactor or add a processing entry
point that accepts an explicit predecessor `VSFrame*` parameter, making
recovery computation reusable without touching strict-streaming state. The
coder may choose the exact implementation shape, but any chosen approach
must satisfy the non-mutation and explicit-predecessor requirements before
actual recovered-frame computation begins.

**Implementation consequence:** G.10ABC dry-run work (Section 8) should
design toward this boundary even while not yet computing real frames.
G.10D must not begin until this requirement is explicitly satisfied and
reviewed.

### 13.5 G-DIAG-RECALC-HIST-01 — Recalculation histogram (deferred)

**Status: Deferred — implement after recovery can compute/duplicate work.**

Add a compile-time-only per-instance recalculation histogram showing how
many output frames were computed exactly once, twice, three times, etc.
Count true computation work, not cache returns. This is useful once
recovery is operating under first-in-best-dressed store idempotency, where
duplicate work can occur under concurrent walks.

Not to be combined with G.10ABC implementation work.

### 13.6 G-DIAG-LOG-VOLUME-01 — Long-run diagnostic throttling (deferred)

**Status: Deferred — implement when long-run tests become routine.**

Add compile-time diagnostic verbosity controls so that 50+ and 100+ frame
test runs remain readable in normal operation while detailed proof logs
remain available for the currently active change. A separate interval
constant analogous to `CNR3_MEMORY_DIAG_FRAME_INTERVAL` is the expected
approach.

Not to be combined with G.10ABC implementation work.

### 13.7 Comment/label drift — do not mix with active proof phases

Several code comments and diagnostic labels still use CMS05/CMS05-3A
wording. This is documentation drift only and carries no functional defect.

**Rule:** Do not combine broad CMS05/CMS06 wording cleanup with active
safety-critical proof phases. Cleanup-only wording changes make patch review
harder and increase the chance of accidental logic changes. Handle wording
cleanup as a separate dedicated pass between proof phases.

### 13.8 exact_match — Named Constraint (diagnostic only)

**Status: Active constraint. Must not be used as a return condition.**

`exact_match` is a diagnostic label/value in the recovery
difference-measurement proof path (introduced in
`CMS02-G / SubPhase G10D.6 / recovery-store-sample-difference-measurement`).

Per plane per frame, it evaluates as true (`exact_match=1`) when
`samples_different == 0` — meaning the locally computed recovery output
matches the cached/strict-streaming output exactly.

**Named constraint:** `exact_match` must not be used as a bounded-recovery
return condition. It is a diagnostic observation only. Whether a recovered
frame is returned to VapourSynth must be determined by output-authority
rules, not by sample-level equality measurements, unless a later explicit
quality/tolerance policy decision explicitly changes this.

**Reason:** Using `exact_match` as a return gate would couple output
authority to pixel-level comparison results, which:
- makes the return decision format-dependent;
- would silently break for near-identical but not bit-exact recovery;
- bypasses the intended output-authority transition design.

### 13.9 Duplicate/recompute waste summary — Required near-term implementation

**Status: Near-term required. Raw counters exist; formatted block not yet
implemented.**

The machine-readable output-cache summary already includes:
- `store_attempts`
- `store_successes`
- `store_skipped_already_cached`
- `duplicate_store_computed_but_discarded`

A human-readable formatted duplicate/recompute waste summary block must be
added as a near-term implementation task. The block should appear at shutdown
in `cnr3_free` when `d->debug` is active.

Required content:
- Frames computed exactly once (unique computations): count.
- Frames computed more than once (wasted work): count.
- Total duplicate computation instances: count.
- Percentage of total computations that were wasted: percentage.

This block is diagnostic only. It must not affect output authority or
frame scheduling. It must not be gated behind `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS`
alone — it should be visible whenever `d->debug` is active, since it directly
informs cache efficiency decisions.

### 13.10 Bounded checkpoint search contract — Named design decision

**Status: Settled design decision (CMS06.4). Pending implementation in
CMS02-H / SubPhase H2B.**

**Decision:** For bounded recovery planning, the checkpoint search must be
bounded by the recovery interval `[max(0, N - B), N]`. The helper must
not search outside this interval before pinning.

**Rejected alternative:** Search globally for the nearest prior checkpoint
using the unbounded helper, then check whether the found checkpoint falls
within the recovery interval, and unpin if not (search-then-reject).

**Reason rejected:**
- Creates unnecessary pin/unpin churn on checkpoints known to be out of
  scope before pinning begins.
- May wander into older retained regions or other hot zones.
- Obscures diagnostics with spurious pin activity.
- Creates unnecessary contention under fmParallelRequests and fmParallel.

**Implementation consequence:**
`prepare_bounded_recovery_plan()` must use
`cnr3_output_cache_find_and_pin_checkpoint_in_interval()` (Section 9.2.G2),
not the unbounded `find_and_pin_nearest_prior_checkpoint()` (Section 9.2).
The unbounded helper remains valid for other purposes.

**Cross-references:** Section 4.5.3 (design contract), Section 9.2.G2
(helper specification), Section 8 (CMS02-H / SubPhase H2A and H2B).

### 13.11 Bounded-start honesty — Named durable rule

**Status: Settled design policy (CMS06.6). Durable while bounded recovery
or bounded warm-up remains part of the design.**

When a no-prior-checkpoint bounded warm-up starts at S > 0, the start
frame is a bounded reset/start approximation unless a later phase proves
exact predecessor history. It must not be described as exact full-history
recursion. See Section 4.5.4 for implementation consequences and required
diagnostic fields.

**Override discipline:** Do not depart from this rule silently. Any
intentional departure requires explicit clarification, discussion,
agreement, and documentation of the reason, scope, and expected safety
impact before implementation proceeds.

### 13.12 No parallel pixel/frame algorithms — Named durable rule

**Status: Settled durable rule (CMS06.6).**

Do not create parallel pixel/frame algorithms for recovery, bounded
warm-up, checkpoint recovery, cache-fill, or future
fmUnordered/fmParallelRequests work. Reuse existing frame-processing
boundaries wherever possible.

```text
Make orchestration, ownership, cache, scheduling, and output-authority
transfer the things being proven — not pixel maths.
```

**Implementation consequence:** Do not duplicate blend, chroma, luma,
downsampled-luma, scene-change, frame-copy, or pixel calculation logic
inside VapourSynth lifecycle or cache proof code unless no safe existing
boundary exists. If existing helpers are insufficient, stop and design a
small named processing-layer boundary explicitly. Do not smuggle ad hoc
pixel logic into lifecycle or cache proof code.

**Override discipline:** Do not depart from this rule silently. Any
intentional departure requires explicit clarification, discussion,
agreement, and documentation of the reason, scope, and expected safety
impact before implementation proceeds.

### 13.13 Ownership and release balance — Named durable rule

**Status: Settled durable rule (CMS06.6).**

Every acquired or allocated frame must have a provable owner and a
provable release or transfer path.

**Implementation consequence:**

```text
Every retrieved source frame must be released on every success, failure,
partial-acquire, early-return, and cleanup path.

Every temporary local output frame must be released on every success,
failure, partial-compute, early-return, and cleanup path unless a later
phase explicitly proves and documents transfer of ownership.

Any phase involving frame retrieval, local output allocation, cache
lookup refs, checkpoint pins, or cache-owned refs must include
diagnostics proving final balance at relevant quiescent points.
```

**Override discipline:** Do not depart from this rule silently. Any
intentional departure requires explicit clarification, discussion,
agreement, and documentation of the reason, scope, and expected safety
impact before implementation proceeds.

### 13.14 Output-authority discipline — Named durable rule

**Status: Settled durable rule (CMS06.6).**

Compute, store, return decision, return transfer, and general
output-authority transition must remain separately provable unless
explicit agreement says otherwise.

**Implementation consequence:** A proof-only path must clearly state what
it does and what it does not do. In particular, proof-only diagnostics
should make clear whether the path:

```text
- computes local outputs;
- stores into output_cache;
- returns a recovered/cache output;
- transfers a lookup/local/cache ref to VapourSynth;
- changes output authority;
- mutates old strict-streaming state.
```

Do not combine local compute, cache store, return decision, return
transfer, and general output-authority transition if a failure would
become ambiguous.

**Override discipline:** Do not combine these steps or depart from this
rule silently. Any intentional departure requires explicit clarification,
discussion, agreement, and documentation of the reason, scope, and
expected safety impact before implementation proceeds.

### 13.15 CMS02-J0 — Mandatory forward checkpoint

**Status: Mandatory checkpoint (CMS06.6). Active until completed or
explicitly deferred with documented agreement.**

`CMS02-J0 / pre-fmParallelRequests cleanup and observability review` is a
mandatory checkpoint before `CMS02-J / fmParallelRequests wiring and
proving`. CMS02-J must not start until CMS02-J0 has been evaluated and
performed, or until specific intentional deferrals have been explicitly
documented with reasons, scope, and expected safety impact.

The full 14-item review scope is specified in Section 8 (Phase CMS02-J0).

**Override discipline (checkpoint form):** Do not bypass this checkpoint
silently. Any intentional deferral requires explicit clarification,
discussion, agreement, and documentation of the reason, scope, and
expected safety impact before the dependent phase proceeds.

### 13.16 Compile-time diagnostics direction — Forward design rule

**Status: Strong recommendation now; consolidation is a CMS02-J0
deliverable/requirement (CMS06.6).**

```text
Before CMS02-J0:
    Prefer compile-time gating (constexpr / if constexpr) for new
    diagnostics where practical.

At CMS02-J0:
    Review and consolidate diagnostics into the final
    compile-time/if constexpr model, with safety counters preserved
    unless deliberately gated.
```

Do not design the final consolidated diagnostic model to depend on the
runtime debug flag.

**Counter policy:** Important safety/health counters should remain
non-gated by default unless there is a clear complexity, performance, or
maintainability reason to gate them. High-volume trace printing,
temporary diagnostic maps, verbose per-frame or per-source traces, memory
snapshots, and proof-only heavy summaries are good candidates for
compile-time gating.

**Why not a hard requirement now:** Making this a hard requirement
immediately would invite refactoring churn during active H-phase proof
work, violating the don't-mix-cleanup-with-proof-phases rule
(Section 13.7). CMS02-J0 is the designated consolidation point.

### 13.17 Old strict-state final-goal review — Hard gate

**Status: Hard gate (CMS06.6). Active until old strict-streaming
authority state is retired, redesigned, or proven safe for the final
authority model.**

Before final fmParallelRequests/fmParallel readiness and before final
output-cache authority, review whether the following are obsolete,
hazardous, or must be redesigned:

```text
- old_strict_cache.next_needed;
- old_strict_cache.prev_output;
- process_cnr3_frame(...) compatibility wrapper;
- any path assuming serial output order.
```

These must not silently remain authoritative in a final parallel design.

**H15.5 quarantine note (CMS06.8):** H15.5 does not make `old_strict_cache`
final authority. The selected sequential fast path (Section 4.10) must
continue to prove old strict non-mutation. The fast path now being
authoritative for eligible sequential frames *increases* the need to keep
old strict state quarantined until it can be removed or reduced to
diagnostics-only code.

**Override discipline:** Do not depart from this rule silently. Any
intentional retention or bypass requires explicit clarification,
discussion, agreement, and documentation of the reason, scope, and
expected safety impact before implementation proceeds.

### 13.18 Reserved-predecessor model and frameData ownership — Named durable rule

**Status: Settled durable rule (CMS06.10). Governs H15.6B.1–H15.6B.3 and
any later source-request reduction that depends on a cached predecessor.**

When `arInitial` reduces a sequential fast-path candidate's source request
to source N only because `output_cache[N-1]` is cached, the cached
predecessor must be *reserved by reference*, not merely observed. The
reservation is implemented by acquiring a caller-owned `addFrameRef` on
`output_cache[N-1]` in `arInitial` and carrying it in the per-invocation
`frameData` to `arAllFramesReady` (Section 4.10.1).

**Rule 13.18.1 — Reserve by reference at classification.** Class-B
classification (sequential fast-path eligible, request reduced) is valid
only if `cnr3_output_cache_find_frame_and_add_ref(output_cache, N-1, vsapi)`
returned a frame and that ref is stored in `frameData`. The atomic
find-and-addref also removes any check-then-acquire race within `arInitial`
itself. `find_frame_and_add_ref` must not be called while already holding
`cache_mutex` (it takes the mutex internally).

**Rule 13.18.2 — frameData is a frame owner.** Once `frameData` carries a
reserved predecessor `VSFrame*`, it owns a caller-owned VapourSynth
reference. RC5 (Section 2.2) and the ownership-and-release-balance durable
rule (Section 13.13) apply. The `frameData` destroy/release path must
release a non-null reserved ref with `freeFrame()` and record
`cnr3_output_cache_note_lookup_ref_released()` on every exit path: success,
fallback, `setFilterError`, partial acquisition, compute/store failure,
unexpected-activation fallback, and any early return after `frameData` is
detached. A plain `delete` of the plan object is insufficient and is a
discipline violation.

Release is via a named helper (or the currently named equivalent):

```text
cnr3_output_cache_authority_release_reserved_predecessor_ref(
    Cnr3Data* d,
    Cnr3OutputCacheAuthorityFrameData* frame_data,
    const VSAPI* vsapi,
    const char* reason)

behaviour:
    if frame_data->reserved_predecessor_frame != nullptr:
        vsapi->freeFrame(frame_data->reserved_predecessor_frame)
        cnr3_output_cache_note_lookup_ref_released(...)
        frame_data->reserved_predecessor_frame = nullptr
        // counter attribution: increment reserved_predecessor_released_by_cleanup
        // ONLY when this is a cleanup release. Successful consumption
        // (Rule 13.18.3) increments reserved_predecessor_consumed instead and
        // must not also increment the cleanup counter.
```

The null field is the idempotency guard: the helper is safe to call more
than once, and safe to call after a successful consume has already nulled
the field (it then does nothing). Counter attribution must distinguish
consume from cleanup so the reservation balance invariant (Section 6)
reconciles.

**Rule 13.18.3 — Single-ownership / null-on-consume.** The reserved
predecessor ref is owned by `frameData` until consumed.

```text
- Successful consumption (fast path) releases the ref (or transfers
  ownership as designed), then sets the frameData field to nullptr.
- frameData cleanup releases the ref only if the field is still non-null.
- Exactly one of {consume, cleanup} releases any given reserved ref.
```

This prevents double-release (fast path releases, then cleanup releases the
same ref) and leak (fast path assumes cleanup will release; cleanup assumes
the fast path consumed). It is a formal proof requirement of H15.6B.2.

**Rule 13.18.4 — The held ref, not callback ordering, is the safety
guarantee.** A successfully acquired caller-owned ref keeps the predecessor
VSFrame alive even if its cache slot is pruned or removed before
consumption (Appendix B). Safety must rest on this ownership property, not
on any assumption about same-instance serial callback ordering. This makes
the mechanism mode-independent: correct under fmUnordered today and under
fmParallelRequests/fmParallel later.

**Rule 13.18.5 — Source-reduction eligibility requires a reserved ref.** A
frame is H15.6B.3 source-reduction eligible only if `arInitial`
successfully acquired and stored a reserved predecessor ref for
`output_cache[N-1]`. A prior cache-contains check, or any non-owning
observation that `N-1` exists, is **not** sufficient. This closes the
TOCTOU-prone "contains then reduce" path: the fact that justifies reducing
the request (a held ref) and the fact that guarantees the predecessor's
survival are the same fact.

**Rule 13.18.6 — Reserved refs are part of the existing lookup-ref
universe, not a separate one.** Reserved predecessor refs flow through the
existing caller-side counters, not a parallel accounting scheme:

```text
acquisition  -> increments lookup_owned_ref_acquired_total
release      -> increments lookup_owned_ref_released_total
   (whether the release happens via consume or via cleanup)
```

The reserved predecessor is an input to the computation, not the frame
returned to VapourSynth, so in H15.6B.1 and H15.6B.2 it is **released, not
transferred**. The existing invariant continues to hold at quiescent
points:

```text
lookup_owned_ref_acquired_total ==
    lookup_owned_ref_released_total + lookup_owned_ref_transferred_total
```

**Rule 13.18.7 — Reservation uses lookup-addref, not pinning.** H15.6B
predecessor reservation uses caller-owned lookup-addref ownership. It must
not introduce checkpoint pin or non-checkpoint pin activity for ordinary
cached predecessor frames. Checkpoint pin/unpin remains the mechanism for
checkpoint and recovery anchors only, and its pin/unpin balance proof
remains mandatory there. This avoids the future confusion "should a normal
`N-1` predecessor be pinned?" — it should not; it is referenced.

**Rejected alternative — Option A (reliance on serial callback ordering).**
Relying on the same-instance serial arInitial→arAllFramesReady ordering to
guarantee `N-1` cannot be removed in the gap is correct only under
fmUnordered. It is precisely the kind of serial-output-order assumption
that Section 13.17 (hard gate) and Section 14.6 prohibit, and it would
break silently when CMS02-J introduces concurrent requests. Rejected.
Recorded so a future chat does not reintroduce it as an apparent
simplification.

**Fail-closed branch — demoted to invariant-breach diagnostic.** Before
this rule, the only safe response to a missing predecessor after source
reduction was to fail closed (raise an explicit error rather than fetch
unrequested source frames). With reservation in place, the TOCTOU race is
structurally closed under all modes, so the fail-closed branch must never
be reached in correct operation. If it is reached it indicates a lost owned
ref or a failed `frameData` carry, and the implementation must surface:

```text
reserved_predecessor_expected=1
reserved_predecessor_present=0
reduced_fastpath_predecessor_lost=1
proof_ok=0
```

`reduced_fastpath_predecessor_lost` must read 0 in all H15.6B evidence
(Section 6). A non-zero value is a discipline-failure invariant breach,
not normal operation, and prints a prominent warning regardless of the
diagnostic gate setting.

**Override discipline:** Do not depart from this rule silently. Any
intentional departure (for example, reducing a source request without a
reserved predecessor ref, or relying on callback ordering for predecessor
survival) requires explicit clarification, discussion, agreement, and
documentation of the reason, scope, and expected safety impact before
implementation proceeds.

### 13.19 H17 minimal sparse-hole repair — Deferred optimisation

**Status: Deferred named item (CMS06.11). Recorded to preserve intent.
Must not contaminate H15.6B; not in the active proof sequence.**

The current predecessor-missing fallback (Sections 4.5, 4.5.3, 4.5.4,
proven by H16.3/H16.4) is deliberately correctness-first and conservative.
It may recompute or discard already-cached frames at the lower bound of the
bounded recovery window rather than reusing them.

A future optimised recovery path (provisional label H17) should:

```text
- start from the nearest suitable cached predecessor or checkpoint inside
  the bounded recovery window, rather than always from the window lower bound;
- request only the source frames actually needed to walk forward from there;
- compute and store only the missing output frames plus the requested output;
- skip already-cached frames via fill-holes-only and first-in-best-dressed;
- return through output-cache authority, not old strict state.
```

This is an efficiency improvement, not a correctness change. It is deferred
because correctness-first fallback (H16.3/H16.4) and the H15.6B reservation
work must settle first. H17 must not be started, partially implemented, or
allowed to alter H15.6B scope. When taken up, it requires its own design
entry, proof sub-phases, and Design Compliance Review.

---

## 14. Current Implementation State

**[Ground truth derived from reading uploaded source files. Update this
section at every session boundary.]**

### 14.1 Phase Completion Status

Latest committed phase label: `Complete CMS02-G.10D.7 recovery-return-decision-dry-run`
Latest observed proof edit marker: `CMS02-G10D7-recovery-return-decision-dry-run-v1`
(Final disabled-state CNR3_EDIT_VERSION string not confirmed — verify against
current `cnr3_build_config.h`.)

| Phase / Sub-phase (compact) | Expanded name | Status | Notes |
|---|---|---|---|
| CMS02-A | renames, constants | Partially complete | See Section 14.2 |
| CMS02-B | hot zone structures, passive diagnostics | Complete | |
| CMS02-C | hot zone update helpers | Complete | Hard-wired FmUnordered |
| CMS02-D | hot-zone-aware prune, ceiling | Complete | |
| CMS02-E | store/prune-only runtime proving | Complete | |
| CMS02-F | cache-hit reuse | Substantially implemented | Cache-hit return path implemented; cache misses still strict-streaming; see Section 8 |
| G.7A | source-request-plan-skeleton | Complete | Proof disabled in committed state |
| G.7B | lifecycle-proof | Complete | Proof disabled in committed state |
| G.7C | widened-source-request-proof | Complete | Proof disabled in committed state |
| G.8A | decision-walk-skeleton | Complete | Proof disabled in committed state |
| G.8B | checkpoint-selection-ref-rollover | Complete | Proof disabled in committed state |
| G.8C | pre-store-probe | Complete | Proof disabled in committed state |
| G.8D | would-compute-detection | Complete | Proof disabled in committed state |
| G.9AB | source-frame-set-acquire-release | Complete | Proof disabled in committed state |
| G.10ABC | dry-run-compute-orchestration | Complete | No real frames; no output authority change |
| G.10D.1 | local-single-frame-compute-proof | Complete | Proof disabled in committed state |
| G.10D.2 | local-bounded-walk-compute-proof | Complete | Proof disabled in committed state |
| G.10D.3 | diagnostics-cleanup-proof | Complete | Proof disabled in committed state |
| G.10D.4 | proof-scaffold-cleanup-review | Complete | Proof disabled in committed state |
| G.10D.5 | local-bounded-walk-store-proof | Complete | Proof disabled in committed state |
| G.10D.6 | recovery-store-sample-difference-measurement | Complete | `exact_match` diagnostic proven |
| G.10D.7 | recovery-return-decision-dry-run | Complete | `actual_returned_recovered_output=0`; dry-run only |
| G.10D.8 | output-authority-transition-readiness-review | Complete | Readiness reviewed; not yet transferred |
| G.10D.9+ | (next sub-phase) | **Next** | First actual recovered-frame return to VapourSynth |
| H2A | bounded-checkpoint-search-contract-review | Superseded | Obligation carried by H16.1 |
| H2B | bounded-checkpoint-search-helper-proof | Superseded | Obligation carried by H16.2 |
| H4 | bounded-warmup-source-frame-set-request-acquire-release | Complete / PASS | Evidence in Section 14.7 |
| H5 | bounded-warmup-local-compute-proof | Complete / PASS | Evidence in Section 14.7; H5.1 zero-start, H5.2 bounded-start |
| H6 | bounded-warmup-store-proof | Complete / PASS | First-in-best-dressed store proven |
| H7 | bounded-warmup-return-decision-dry-run | Complete / PASS | Return-decision shape only |
| H8 | bounded-warmup-return-transfer-proof | Complete / PASS | Lookup-ref transfer/return proven |
| H9 | bounded-warmup-authority-integration-proof | Complete / PASS | Output-cache authority integrated |
| H10 | old-strict-state-bypass-proof | Complete / PASS | After plan-selection fix |
| H11 | old-strict-quarantine-proof | Complete / PASS | Old strict not authority, not mutated |
| H13 | old-strict-streaming-gate-quarantine-proof | Complete / PASS | next_needed gate does not reject selected path |
| H14.1–H14.5 | selected output-cache authority normalisation | Complete / PASS | Naming normalised |
| H15.1 | output-cache authority normal-path scaffold | Complete / PASS | No behavioural regression |
| H15.2 | sequential predecessor-cache reuse probe | Complete / PASS | Cached N−1 available; refs clean |
| H15.3 | sequential fast-path dry run | Complete / PASS | Eligibility/reuse dry-run |
| H15.4 | sequential fast-path compute/store proof | Complete / PASS | Compute/store via cached N−1 + source N |
| H15.5 | sequential fast-path return-transfer proof | Complete / PASS | Fast-path return active; evidence in Section 14.8 |
| H15.6A | arInitial request classification probe | **Next** | No behaviour change; classify A/B/C/D |
| H15.6B.1 | arInitial predecessor reservation lifecycle proof | Pending | frameData owns reserved ref; no reduction; no consumption |
| H15.6B.2 | reserved-predecessor fast-path consumption proof | Pending H15.6B.1 | Consume carried ref; single-ownership/null-on-consume; no reduction |
| H15.6B.3 | active sequential source-request reduction | Pending H15.6B.2 and H16.3 | Reduce class-B to source N only; relies on reserved predecessor |
| H16.1 | bounded-checkpoint-search-contract-closeout | Pending | Carries former H2A obligation |
| H16.2 | bounded-checkpoint-search-helper-proof | Pending | Carries former H2B obligation |
| H16.3 | predecessor-missing fallback return-transfer proof | Pending | Key fallback coverage; gates H15.6B.3 |
| H16.4 | out-of-order fallback validation | Pending | Fast-path vs fallback selection |
| CMS02-I | pinning decision | Not started | |
| CMS02-J0 | pre-fmParallelRequests cleanup/observability review | Mandatory checkpoint | Must precede CMS02-J; see Section 13.15 |
| CMS02-J | fmParallelRequests | Not started | Requires CMS02-J0; arInitial hot-zone prerequisite already satisfied |

### 14.2 Rename and Build Config Completion Status

| Item | Status | Notes |
|---|---|---|
| `Cnr3CacheManagerV005` → `Cnr3OutputCacheManager` | Complete | In active files |
| `Cnr3CacheManager` → `OldCnr3StrictStreamCache` | Complete | In active files |
| `cache_manager_v005` → `output_cache` in Cnr3Data | Complete | In active files |
| `cache` → `old_strict_cache` in Cnr3Data | Complete | In active files |
| `cnr3_cache_manager_*` → `cnr3_output_cache_*` helpers | Complete | |
| `old_cnr3_strict_cache_*` prefix | In use | |
| `cnr3_cache_manager.h/.cpp` → `cnr3_output_cache_manager.h/.cpp` | Complete | |
| `cnr3_build_config.h` — `CNR3_OUTPUT_CACHE_DEV_DIAGNOSTICS` | Complete | Old `CNR3_CACHE_MANAGER_DEV_DIAGNOSTICS` removed |
| Stale phase comment in `cnr3_output_cache_manager.h` | **Pending** | Comment only — see Section 13.2 |
| Disk-uploaded `cnr3_common.h` | Old version | Uses old names; superseded by current active version |
| Disk-uploaded `cnr3_cache_manager.h/.cpp` | Old version | Superseded by `cnr3_output_cache_manager.h/.cpp` |

### 14.3 What Is Implemented and Wired (Live)

**Output authority (partial shift — cache hits only):**
- Cache hits: `arAllFramesReady` first checks `output_cache` via
  `cnr3_output_cache_find_frame_and_add_ref()`. If found, calls
  `cnr3_output_cache_note_lookup_ref_transferred()`, logs `CACHE-HIT-RETURN`,
  and returns the cached frame to VapourSynth.
- Cache misses: fall through to source-frame retrieval and the
  strict-streaming/new-computation path, including the
  `old_strict_cache.next_needed` check.
- Recovered outputs: not yet returned from output_cache; recovery
  scaffolding through G10D.8 is proof-only and disabled in normal
  committed state.

Do not describe full output-cache authority as achieved until recovered
outputs are computed, stored, returned, and proven in a future sub-phase.

- 8/16-bit recursive chroma blend with scene-change detection.
- Luma downsampling and sharing between U/V planes.
- `OldCnr3StrictStreamCache` — active, returns output frames to
  VapourSynth. This is the current source of output authority.
- `Cnr3OutputCacheManager` — owned by `Cnr3Data`, store/prune wired
  in `cnr3_get_frame()` after the strict-streaming path produces each
  frame.
- `cnr3_output_cache_update_hot_zones()` called in `arInitial` (correct;
  see Section 14.4 — resolved).
- `cnr3_output_cache_find_frame_and_add_ref()` called at start of `arAllFramesReady`;
  cache hits returned via `cnr3_output_cache_note_lookup_ref_transferred()`.
- `cnr3_output_cache_store_frame()` and
  `cnr3_output_cache_prune_after_store()` called after each successful
  frame production.
- `cnr3_output_cache_set_ceiling()` called in `cnr3_create()`.
- Debug snapshot printed after each store/prune (gated on `d->debug`).
- `cnr3_output_cache_clear()` called in `cnr3_free()`.
- Memory diagnostics wired at create/free points.
- `validate_invariants` called inside store/remove/prune helpers when
  `CNR3_OUTPUT_CACHE_VALIDATE_AFTER_MUTATION` is true.

### 14.4 Hot Zone Update Placement

**Status: RESOLVED. Earlier CMS06.1 deviation note is superseded.**

The current committed code calls `cnr3_output_cache_update_hot_zones()`
from the `arInitial` branch of `cnr3_get_frame()`, before
`requestFrameFilter()` and source-request-plan handling. This is correct.

**Do not move hot-zone updates back to `arAllFramesReady`.** The `arInitial`
placement is a hard safety prerequisite for fmParallelRequests and fmParallel:
under concurrent request modes, deferring zone registration to
`arAllFramesReady` can allow pruning to ignore active request intent.

The CMS02-J prerequisite for moving this call is therefore already satisfied.
See named item G-PAR-HZ-ARINITIAL-01 (Section 13.3).
See also G-PAR-PRED-BOUNDARY-01 (Section 13.4) — resolved during G10D work.

### 14.5 What Is Not Yet Implemented or Complete

- Full output-cache authority for cache misses — misses still use
  strict-streaming computation path.
- Recovered-frame return to VapourSynth (Phase CMS02-G / SubPhase G10D.9+).
  Proof scaffolding through G10D.8 is complete but all proof paths disabled;
  `actual_returned_recovered_output=0` in dry-run.
- Bounded warm-up store, return, and authority transfer (CMS02-H
  SubPhases H6+). H4 source lifecycle and H5 local compute are proven;
  store/return/authority remain staged future work.
- Non-checkpoint pinning (Phase CMS02-I, deferred).
- fmParallelRequests wiring (Phase CMS02-J).
- `Cnr3OwnedFrameRef` RAII wrapper (recommended, not yet implemented;
  explicit ref handling is acceptable interim while invariant is clean).
- Human-readable duplicate/recompute waste summary block (Section 13.9 —
  near-term required; raw counters exist).
- Recalculation histogram (Section 13.5 — deferred).
- Long-run diagnostic throttling (Section 13.6 — deferred).

### 14.6 Output Authority

**Current state (partial shift):**
- Cache hits are now served from `output_cache` via the CACHE-HIT-RETURN
  path. Output authority has partially shifted for frames already cached.
- Cache misses still use the strict-streaming computation path including
  `old_strict_cache.next_needed` and `old_strict_cache.prev_output`.
- Recovered outputs are not yet returned from `output_cache`; the
  recovery scaffolding through G10D.8 is proof-only and disabled.

**fmParallel warning:** `old_strict_cache.next_needed` and
`old_strict_cache.prev_output` are not final fmParallel output authority.
Any design or code that introduces ordering assumptions tied to these
fields blocks future fmParallel migration. They must eventually be
replaced by fully output-cache-authoritative mechanisms.

**Next authority transition:** Completing
`CMS02-G / SubPhase G10D.9+ / first-actual-recovered-frame-return`
and its Design Compliance Review will transfer output authority for
recovered frames from the strict-streaming path to `output_cache`.

### 14.7 Preserved Proof Evidence — CMS02-H / SubPhases H4 and H5

Evidence preserved verbatim per the non-regression principle: status
words alone are insufficient for future safety review.

#### CMS02-H / SubPhase H4 / bounded-warmup-source-frame-set-request-acquire-release
**Status: Complete / PASS**

Purpose: proved request/acquire/release of the conservative bounded
warm-up source frame set without compute, store, return, output-authority
change, or old strict-state mutation.

```text
Enabled proof evidence:
    frames_checked=20
    plans_created=20
    plans_destroyed=20
    source_frames_requested_total=57
    source_frames_retrieved_total=57
    source_frames_released_total=57
    source_frame_release_balance=0
    source_frame_count_max=3
    partial_acquire_failures=0
    source_frame_release_balance_errors=0
    proof_failures=0

Negative-authority evidence:
    would_compute_warmup_outputs=0
    would_store_warmup_outputs=0
    would_return_warmup_output=0
    output_authoritative=0
    mutates_old_strict=0

Disabled committed/smoke state:
    H4 proof gate disabled.
    No H4 proof trace lines in disabled smoke.
    Final cache/ref cleanup clean.

Final edit marker:
    CMS02-H4-bounded-warmup-source-frame-set-request-acquire-release-v1-PASSED

Disabled-smoke cleanup evidence:
    non_checkpoint_count=0
    checkpoint_count=0
    total_cached_frame_count=0
    has_pinned_checkpoints=0
    total_pin_count=0
    invariants_ok=1
    integrity_errors=0
    validation_failures=0
    ref_balance_errors=0
    addframeref_total=5
    freeframe_total=5
    balance=0
    lookup_ref_balance=0
    clear_successes=1
```

#### CMS02-H / SubPhase H5 / bounded-warmup-local-compute-proof
**Status: Complete / PASS**

Purpose: proved local bounded warm-up computation using the H4
source-frame lifecycle and the existing explicit-predecessor
frame-processing boundary. H5.1 proved zero-start local rolling compute
(0..N); H5.2 proved S > 0 bounded-start reset/start semantics.

```text
Enabled proof evidence:
    frames_checked=20
    plans_seen=20
    source_frames_retrieved_total=57
    source_frames_released_total=57
    source_frame_release_balance=0
    source_frame_release_balance_errors=0
    start_frame_zero_count=3
    start_frame_nonzero_count=17
    local_start_reset_copies=20
    local_recursive_computes=37
    local_outputs_allocated=57
    local_outputs_released=57
    local_output_release_balance=0
    local_output_release_balance_errors=0
    partial_acquire_failures=0
    compute_failures=0
    proof_failures=0
    would_store_warmup_outputs=0
    would_return_warmup_output=0
    output_authoritative=0
    mutates_old_strict=0

Final edit marker:
    CMS02-H5-bounded-warmup-local-compute-proof-v1-PASSED

Disabled-state smoke:
    H5 proof gate restored to false.
    Final cache/ref cleanup clean:
        non_checkpoint_count=0
        checkpoint_count=0
        total_cached_frame_count=0
        invariants_ok=1
        integrity_errors=0
        validation_failures=0
        ref_balance_errors=0
        addframeref_total=5
        freeframe_total=5
        balance=0
        lookup_ref_balance=0
        clear_successes=1
```

**Evidence cross-check (arithmetic consistency):**
`local_start_reset_copies=20` + `local_recursive_computes=37` = 57 =
`local_outputs_allocated`, consistent with 20 plans each starting with a
reset copy and walking forward. Source balance 57/57/0 matches the H4
conservative window arithmetic: 1 + 2 + (18 × 3) = 57.

### 14.8 Preserved Proof Evidence — CMS02-H / SubPhase H15.5

Sequential fast-path return-transfer proof. This is the first proof where
eligible sequential frames actually return through the fast path rather
than merely proving or dry-running eligibility.

```text
20-frame sequential validation completed.
Frame 0 fell back to OUTPUT-CACHE-AUTHORITY-NORMAL-PATH-RETURN.
Frames 1..19 emitted OUTPUT-CACHE-AUTHORITY-SEQUENTIAL-FAST-PATH-RETURN.

Representative eligible-frame fields:
    predecessor_lookup_attempted=1
    predecessor_cache_hit=1
    current_source_acquired=1
    local_output_allocated=1
    process_ok=1
    store_attempted=1
    store_ok=1
    returned_lookup_attempted=1
    returned_lookup_success=1
    returned_lookup_ref_transferred=1
    predecessor_lookup_ref_released=1
    current_source_released=1
    local_output_released=1
    returned_fast_path_output=1
    output_authoritative=1
    mutates_old_strict=0
    proof_ok=1

Pre-cleanup summary shape:
    total_cached_frame_count=20
    addframeref_total=20
    freeframe_total=0
    balance=20
    lookup_ref_acquired=39
    lookup_ref_released=19
    lookup_ref_transferred=20
    lookup_ref_balance=0
    store_attempts=20
    store_successes=20
    duplicate_skipped_already_cached=0
    duplicate_computed_but_discarded=0

After output_cache clear:
    total_cached_frame_count=0
    invariants_ok=1
    integrity_errors=0
    validation_failures=0
    ref_balance_errors=0
    addframeref_total=20
    freeframe_total=20
    balance=0
    lookup_ref_balance=0
    clear_successes=1
    clear_failures=0
```

**Evidence cross-check (arithmetic consistency):** Lookup-ref acquires =
39 = (19 fast-path frames × 2 acquires: predecessor + returned) +
(frame 0 × 1 returned acquire). Releases = 19 = 19 predecessor releases
(frame 0 has no predecessor). Transfers = 20 = one returned-frame transfer
per frame. lookup_ref_balance = 39 − 19 − 20 = 0. Cache balance pre-clear
= 20 addFrameRef − 0 freeFrame = 20 (the 20 cached frames); after clear,
20 − 20 = 0. All balances reconcile.

---

## Appendix A — Sliding vs. Extend-Only: Discussion and Decision

*(Full discussion in CMS05 Appendix A. Summary retained here.)*

**Background:** CMS02 "never shrink" rule contradicted linear pruning
examples. CMS03 introduced mode-specific split (sliding in fmUnordered,
extend-only in fmParallelRequests) as an overcorrection. CMS04/CMS05
adopted sliding in both modes.

**Key reasoning:** In fmParallelRequests with 16–32 threads and jitter
~6, concurrent request spread is ~22–38 frames. `BACK_RADIUS=50` always
covers all in-flight predecessor needs under normal sequential operation.
The pathological stall case produces more recompute (checkpoint recovery),
not incorrect output. Detectable via `predecessor_missing_when_expected`.

**Decision:** Sliding in both modes. Only retirement is mode-specific.
The `update_hot_zones` helper needs no mode parameter.

**Maintainer caveats:**
- If `predecessor_missing_when_expected` ever increments in production,
  revisit: promote to non-checkpoint pinning, or reintroduce extend-only
  zones in fmParallelRequests.
- The rolling predecessor pattern is load-bearing. If broken, all safety
  arguments collapse.
- Sliding is "good enough given other mechanisms," not "always best."

---

## Appendix B — Reference-Count Discipline: Discussion and Decision

*(Full discussion in CMS05 Appendix B. Summary retained here.)*

**Background:** Concern raised that cache slot eviction could leave
dangling `addFrameRef` calls causing runaway VS memory consumption.

**Analysis:** Design is robust if RC1–RC8 are followed. Five specific
leak classes identified and closed by the rules. Sliding does not worsen
this — it exercises the remove path more, which finds discipline bugs
faster.

**Key insight:** When a walk holds a caller-owned ref and the cache slot
is evicted, the VSFrame stays alive (caller's ref keeps it). The slot
is removed; the VSFrame is destroyed only when all refs reach zero.
No leak. This is the load-bearing safety property.

**Decision:** Promoted to first-class Goal 5 with named Section 2.2.
Rules RC1–RC8, diagnostic counters, RAII wrapper, and shutdown protocol
are the supporting mechanisms.

**Maintainer caveats:**
- Any new code path calling `addFrameRef`/`freeFrame` outside the single
  store/remove helpers is a discipline violation.
- Any `pool.erase()` or `cache_index.erase()` outside the remove helper
  is a violation.
- Ref-balance failure at shutdown is a real bug.
- If non-checkpoint pinning is added, same discipline applies.

---

## Appendix C — Implementation Process Notes and Rationale

*(Full content in CMS05 Appendix C. Subsection list retained here.)*

- **C.1:** First-in-best-dressed store race — narrative and rationale.
- **C.2:** RAII wrapper instrumentation strategy — three options, Option
  3 (explicit call-site instrumentation) recommended for first
  implementation.
- **C.3:** Naming history and rationale — why v005 was replaced, what
  the names mean.
- **C.4:** Why design-compliance review matters — the highest risk is an
  old helper remaining in the call path with old assumptions.
- **C.5:** Phase timing examples — which phases can be batched, which
  cannot.
- **C.6:** Guiding principle — "prefer the safest, clearest, most
  maintainable implementation."

---

## Appendix D — Code Review and Simulation Plan

See companion document `cnr3_code_review_plan_v5_1.md` (version CMS05.1).
Note: the review plan predates CMS02-G proof work; it remains valid as
a post-implementation review target but will need updating to cover
G.10ABC and G.10D+ phases when those are complete.

The companion document specifies:

- **Static analysis** — 15 review items covering spec compliance, RC
  rule compliance per function, error path completeness, mutex
  correctness, hot zone lifecycle, first-in-best-dressed store,
  final-frame ownership transfer, rolling predecessor pattern, pruning
  correctness, shutdown completeness, instrumentation coverage,
  `validate_invariants` coverage, data structure usage,
  fmUnordered/fmParallelRequests transition safety, and RAII wrapper
  correctness.

- **Monte Carlo simulations** — Three sub-scenarios (fmUnordered,
  fmParallelRequests, fmParallel informational), each comprising 50
  short runs (200 frames, 6 threads, 0–6 frame jitter) plus one long
  run (10,000 frames). CSV output for visualisation in Excel.
  Metrics verified: pool sizes, hot zone behaviour, pruning correctness,
  ref-count balance, predecessor miss rate, duplicate store frequency.

- **Design-compliance review** per Section 12 of this spec.

- **Session structure** — two sessions recommended (analysis then
  decision/remediation).

- **Model recommendation** — Opus 4.7 for both sessions.

