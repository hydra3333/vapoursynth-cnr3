| Row | Sleep | Threads | N/2 | Runtime | FPS | Source requested | Frames computed | Duplicates | Holes | Recalc count | Span mean | Span max | Retry sleeps | Plans dumped | Kept holes | Invariants | Ownership |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 50msT0 | 50 | 24 | 12 | 23.73 | 126.42 | 5061 | 5027 | 2027 | 2061 | 2027 | 1.687 | 16 | 8967 | 8967 | 2061 | 0 | 0 |
| 50msT8 | 50 | 8 | 4 | 27.87 | 107.64 | 4894 | 4892 | 1892 | 1894 | 1892 | 1.632 | 3 | 3525 | 3525 | 1894 | 0 | 0 |
